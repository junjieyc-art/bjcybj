export interface CaseData {
  id: string
  title: string
  category: string
  categoryColor: string
  description: string
  fullDescription: string
  image: string
  services: string[]
  results: string[]
  duration: string
  year: string
  client?: string
  challenge?: string
  solution?: string
  process?: Array<{
    step: string
    description: string
  }>
}

const casesData: CaseData[] = [
  {
    id: "fashion-brand",
    title: "高端时尚品牌全案设计",
    category: "时尚品牌",
    categoryColor: "bg-blue-500/90",
    description: "为知名时尚品牌打造完整的品牌形象体系，提升品牌价值认知",
    fullDescription:
      "通过深入的市场调研和品牌定位分析，为该时尚品牌重新设计了完整的视觉识别系统，包括LOGO、VI手册、包装设计、店面形象等，成功提升了品牌在高端市场的认知度和影响力。项目涵盖了从品牌策略制定到视觉系统落地的全流程服务，帮助客户在竞争激烈的时尚市场中建立了独特的品牌形象。",
    image: "/fashion-brand-campaign.png",
    services: ["品牌策略", "视觉设计", "包装设计", "店面设计"],
    results: ["品牌认知度提升45%", "销售额增长30%", "社交媒体关注度翻倍"],
    duration: "6个月",
    year: "2023",
    client: "知名时尚品牌",
    challenge: "在竞争激烈的时尚市场中建立独特的品牌形象，提升品牌价值认知",
    solution: "通过深入的市场调研和品牌定位分析，重新设计完整的视觉识别系统",
  },
  {
    id: "tech-startup",
    title: "科技创新企业品牌升级",
    category: "科技创新",
    categoryColor: "bg-purple-500/90",
    description: "助力科技创新企业完成品牌形象升级，突出技术实力和创新能力",
    fullDescription:
      "为一家AI技术公司进行全面的品牌升级，从品牌定位到视觉系统，再到数字化营销策略，帮助企业在竞争激烈的科技市场中建立独特的品牌形象。通过现代化的设计语言和创新的传播方式，成功塑造了专业、可信、前沿的品牌形象。",
    image: "/tech-startup-branding.png",
    services: ["品牌重塑", "数字营销", "网站设计", "内容营销"],
    results: ["融资成功率提升60%", "媒体曝光增加200%", "客户询盘增长80%"],
    duration: "4个月",
    year: "2023",
    client: "AI技术公司",
    challenge: "在科技市场中建立独特的品牌形象，突出技术实力和创新能力",
    solution: "全面的品牌升级，从品牌定位到视觉系统，再到数字化营销策略",
  },
  {
    id: "restaurant-brand",
    title: "高端餐饮品牌策划",
    category: "餐饮服务",
    categoryColor: "bg-green-500/90",
    description: "为高端餐饮品牌打造独特的品牌体验和视觉形象",
    fullDescription:
      "从品牌故事构建到空间设计，为这家高端餐厅创造了独特的品牌体验。通过精心设计的视觉元素和营销策略，成功建立了品牌在目标客群中的知名度。项目包含了完整的品牌体验设计，从视觉识别到空间氛围营造。",
    image: "/restaurant-branding.png",
    services: ["品牌策略", "空间设计", "菜单设计", "营销推广"],
    results: ["客流量增长50%", "客单价提升25%", "复购率达到70%"],
    duration: "3个月",
    year: "2024",
    client: "高端餐厅",
    challenge: "在餐饮市场中打造独特的品牌体验和视觉形象",
    solution: "从品牌故事构建到空间设计，创造独特的品牌体验",
  },
  {
    id: "education-platform",
    title: "在线教育平台设计",
    category: "教育培训",
    categoryColor: "bg-yellow-500/90",
    description: "为在线教育平台设计用户友好的界面和完整的品牌体系",
    fullDescription:
      "为在线教育平台进行全面的用户体验设计和品牌形象塑造，包括平台界面设计、课程包装、营销物料等，显著提升了用户体验和品牌认知。通过深入的用户研究和体验设计，创造了直观易用的学习平台。",
    image: "/education-training-brand.png",
    services: ["UI/UX设计", "品牌设计", "营销物料", "用户体验优化"],
    results: ["用户注册率提升40%", "课程完成率增长35%", "用户满意度达95%"],
    duration: "5个月",
    year: "2023",
    client: "在线教育平台",
    challenge: "设计用户友好的界面和完整的品牌体系",
    solution: "全面的用户体验设计和品牌形象塑造",
  },
  {
    id: "fintech-rebrand",
    title: "金融科技品牌重塑",
    category: "金融服务",
    categoryColor: "bg-indigo-500/90",
    description: "为金融科技公司进行品牌重塑，提升市场竞争力",
    fullDescription:
      "帮助一家金融科技公司完成品牌重塑，从品牌定位、视觉识别到数字化营销，全面提升品牌在金融科技领域的专业形象和市场影响力。通过现代化的设计语言和专业的传播策略，成功建立了可信赖的品牌形象。",
    image: "/financial-services-branding.png",
    services: ["品牌重塑", "视觉设计", "数字营销", "公关传播"],
    results: ["品牌信任度提升55%", "用户增长率达120%", "市场份额增长40%"],
    duration: "8个月",
    year: "2022",
    client: "金融科技公司",
    challenge: "在金融科技领域建立专业形象和市场影响力",
    solution: "全面的品牌重塑，从品牌定位、视觉识别到数字化营销",
  },
  {
    id: "ecommerce-visual",
    title: "电商平台品牌视觉系统",
    category: "电商平台",
    categoryColor: "bg-red-500/90",
    description: "为大型电商平台打造统一的品牌视觉识别系统",
    fullDescription:
      "为大型电商平台设计完整的品牌视觉系统，包括品牌标识、界面设计、营销物料、包装设计等，确保品牌在各个触点的一致性表达。通过系统化的设计方法，建立了完整的品牌视觉规范。",
    image: "/ecommerce-brand-identity.png",
    services: ["视觉识别", "界面设计", "包装设计", "营销物料"],
    results: ["品牌一致性提升90%", "用户体验评分提升30%", "转化率增长25%"],
    duration: "7个月",
    year: "2023",
    client: "大型电商平台",
    challenge: "打造统一的品牌视觉识别系统",
    solution: "完整的品牌视觉系统设计，确保各个触点的一致性表达",
  },
  {
    id: "healthcare-brand",
    title: "医疗品牌形象设计",
    category: "医疗健康",
    categoryColor: "bg-teal-500/90",
    description: "为医疗机构设计专业可信的品牌形象",
    fullDescription:
      "为医疗机构打造专业、可信、温暖的品牌形象，通过精心设计的视觉元素和传播策略，提升患者对医疗服务的信任度和满意度。项目涵盖了从品牌策略到视觉实施的全流程服务。",
    image: "/healthcare-brand-design.png",
    services: ["品牌策略", "视觉设计", "空间设计", "数字营销"],
    results: ["患者满意度提升40%", "预约量增长60%", "品牌知名度翻倍"],
    duration: "4个月",
    year: "2024",
    client: "医疗机构",
    challenge: "设计专业可信的品牌形象",
    solution: "打造专业、可信、温暖的品牌形象",
  },
  {
    id: "culture-brand",
    title: "文化品牌视觉策划",
    category: "文化娱乐",
    categoryColor: "bg-pink-500/90",
    description: "为文化娱乐品牌打造独特的视觉形象和传播策略",
    fullDescription:
      "为文化娱乐品牌设计富有创意和文化内涵的视觉形象，通过多元化的传播渠道和创新的营销方式，成功建立品牌在文化领域的影响力。项目融合了传统文化元素与现代设计理念。",
    image: "/entertainment-culture-brand.png",
    services: ["创意策划", "视觉设计", "活动策划", "社交媒体"],
    results: ["社交媒体粉丝增长300%", "活动参与度提升80%", "媒体报道增加150%"],
    duration: "6个月",
    year: "2023",
    client: "文化娱乐品牌",
    challenge: "打造独特的视觉形象和传播策略",
    solution: "富有创意和文化内涵的视觉形象设计",
  },
  {
    id: "luxury-auto",
    title: "豪华汽车品牌营销",
    category: "汽车行业",
    categoryColor: "bg-slate-500/90",
    description: "为豪华汽车品牌打造高端营销策略和品牌体验",
    fullDescription:
      "为豪华汽车品牌制定全方位的营销策略，从品牌定位到体验设计，通过精准的目标客群分析和创新的营销手段，成功提升品牌在高端市场的地位。项目注重品牌体验的每一个细节。",
    image: "/luxury-car-campaign.png",
    services: ["品牌策略", "体验设计", "数字营销", "活动策划"],
    results: ["销售额增长45%", "品牌认知度提升50%", "客户满意度达98%"],
    duration: "10个月",
    year: "2022",
    client: "豪华汽车品牌",
    challenge: "在高端市场建立品牌地位",
    solution: "全方位的营销策略和品牌体验设计",
  },
  {
    id: "sports-brand",
    title: "运动品牌全案策划",
    category: "体育运动",
    categoryColor: "bg-orange-500/90",
    description: "为运动品牌打造年轻化的品牌形象和营销策略",
    fullDescription:
      "为运动品牌进行全面的品牌升级，从视觉识别到营销传播，通过年轻化的设计语言和创新的营销方式，成功吸引了更多年轻消费者的关注。项目融合了运动文化与时尚元素。",
    image: "/young-athletes-campaign.png",
    services: ["品牌升级", "视觉设计", "社交营销", "KOL合作"],
    results: ["年轻用户增长200%", "社交媒体互动率提升150%", "销售额增长35%"],
    duration: "5个月",
    year: "2024",
    client: "运动品牌",
    challenge: "打造年轻化的品牌形象",
    solution: "年轻化的设计语言和创新的营销方式",
  },
  {
    id: "beauty-brand",
    title: "美妆品牌数字化营销",
    category: "美妆护肤",
    categoryColor: "bg-rose-500/90",
    description: "为美妆品牌打造全方位的数字化营销解决方案",
    fullDescription:
      "为美妆品牌制定数字化营销策略，通过精准的用户画像分析、创新的内容营销和多平台整合推广，成功建立品牌在美妆市场的竞争优势。项目注重数字化渠道的整合运营。",
    image: "/beauty-campaign.png",
    services: ["数字营销", "内容创作", "KOL合作", "电商运营"],
    results: ["线上销售增长180%", "粉丝增长500%", "转化率提升60%"],
    duration: "6个月",
    year: "2023",
    client: "美妆品牌",
    challenge: "建立数字化营销竞争优势",
    solution: "全方位的数字化营销解决方案",
  },
  {
    id: "hotel-brand",
    title: "精品酒店品牌设计",
    category: "酒店旅游",
    categoryColor: "bg-emerald-500/90",
    description: "为精品酒店打造独特的品牌体验和视觉形象",
    fullDescription:
      "为精品酒店设计完整的品牌体验系统，从品牌故事到空间设计，通过独特的设计语言和服务理念，成功打造了具有强烈品牌识别度的酒店品牌。项目涵盖了品牌体验的各个触点。",
    image: "/boutique-hotel-interior.png",
    services: ["品牌策略", "空间设计", "体验设计", "营销推广"],
    results: ["入住率提升70%", "客户评分达4.8分", "复购率增长85%"],
    duration: "8个月",
    year: "2022",
    client: "精品酒店",
    challenge: "打造独特的品牌体验和视觉形象",
    solution: "完整的品牌体验系统设计",
  },
]

export default casesData
