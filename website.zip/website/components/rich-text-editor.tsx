"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  List,
  ListOrdered,
  Link,
  Undo,
  Redo,
} from "lucide-react"

interface RichTextEditorProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  className?: string
}

export function RichTextEditor({ value, onChange, placeholder, className = "" }: RichTextEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null)
  const [isLinkModalOpen, setIsLinkModalOpen] = useState(false)
  const [linkUrl, setLinkUrl] = useState("")

  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== value) {
      editorRef.current.innerHTML = value
    }
  }, [value])

  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value)
    updateContent()
  }

  const updateContent = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // 处理快捷键
    if (e.ctrlKey || e.metaKey) {
      switch (e.key) {
        case "b":
          e.preventDefault()
          execCommand("bold")
          break
        case "i":
          e.preventDefault()
          execCommand("italic")
          break
        case "u":
          e.preventDefault()
          execCommand("underline")
          break
        case "z":
          e.preventDefault()
          if (e.shiftKey) {
            execCommand("redo")
          } else {
            execCommand("undo")
          }
          break
      }
    }
  }

  const insertLink = () => {
    if (linkUrl) {
      execCommand("createLink", linkUrl)
      setLinkUrl("")
      setIsLinkModalOpen(false)
    }
  }

  const formatBlock = (tag: string) => {
    execCommand("formatBlock", tag)
  }

  return (
    <div
      className={`border-2 border-gray-600 rounded-lg overflow-hidden focus-within:border-fuchsia-400 transition-colors ${className}`}
    >
      {/* 工具栏 */}
      <div className="bg-gray-800/50 border-b border-gray-600 p-2 flex flex-wrap gap-1">
        {/* 文本格式 */}
        <div className="flex gap-1 border-r border-gray-600 pr-2 mr-2">
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-gray-700"
            onClick={() => execCommand("bold")}
            title="粗体 (Ctrl+B)"
          >
            <Bold className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-gray-700"
            onClick={() => execCommand("italic")}
            title="斜体 (Ctrl+I)"
          >
            <Italic className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-gray-700"
            onClick={() => execCommand("underline")}
            title="下划线 (Ctrl+U)"
          >
            <Underline className="w-4 h-4" />
          </Button>
        </div>

        {/* 标题 */}
        <div className="flex gap-1 border-r border-gray-600 pr-2 mr-2">
          <select
            className="h-8 px-2 bg-gray-700 text-gray-300 text-sm rounded border border-gray-600 focus:border-fuchsia-400 focus:outline-none"
            onChange={(e) => formatBlock(e.target.value)}
            defaultValue=""
          >
            <option value="">正文</option>
            <option value="h1">标题 1</option>
            <option value="h2">标题 2</option>
            <option value="h3">标题 3</option>
            <option value="h4">标题 4</option>
          </select>
        </div>

        {/* 对齐 */}
        <div className="flex gap-1 border-r border-gray-600 pr-2 mr-2">
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-gray-700"
            onClick={() => execCommand("justifyLeft")}
            title="左对齐"
          >
            <AlignLeft className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-gray-700"
            onClick={() => execCommand("justifyCenter")}
            title="居中对齐"
          >
            <AlignCenter className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-gray-700"
            onClick={() => execCommand("justifyRight")}
            title="右对齐"
          >
            <AlignRight className="w-4 h-4" />
          </Button>
        </div>

        {/* 列表 */}
        <div className="flex gap-1 border-r border-gray-600 pr-2 mr-2">
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-gray-700"
            onClick={() => execCommand("insertUnorderedList")}
            title="无序列表"
          >
            <List className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-gray-700"
            onClick={() => execCommand("insertOrderedList")}
            title="有序列表"
          >
            <ListOrdered className="w-4 h-4" />
          </Button>
        </div>

        {/* 链接 */}
        <div className="flex gap-1 border-r border-gray-600 pr-2 mr-2">
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-gray-700"
            onClick={() => setIsLinkModalOpen(true)}
            title="插入链接"
          >
            <Link className="w-4 h-4" />
          </Button>
        </div>

        {/* 撤销重做 */}
        <div className="flex gap-1">
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-gray-700"
            onClick={() => execCommand("undo")}
            title="撤销 (Ctrl+Z)"
          >
            <Undo className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-gray-700"
            onClick={() => execCommand("redo")}
            title="重做 (Ctrl+Shift+Z)"
          >
            <Redo className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* 编辑区域 */}
      <div
        ref={editorRef}
        contentEditable
        className="p-4 min-h-[200px] text-gray-300 focus:outline-none"
        style={{
          wordBreak: "break-word",
          lineHeight: "1.6",
        }}
        onInput={updateContent}
        onKeyDown={handleKeyDown}
        dangerouslySetInnerHTML={{ __html: value }}
        data-placeholder={placeholder}
      />

      {/* 链接插入模态框 */}
      {isLinkModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg border border-gray-600 w-96">
            <h3 className="text-white text-lg font-semibold mb-4">插入链接</h3>
            <input
              type="url"
              value={linkUrl}
              onChange={(e) => setLinkUrl(e.target.value)}
              placeholder="请输入链接地址"
              className="w-full p-3 bg-gray-700 text-white border border-gray-600 rounded focus:border-fuchsia-400 focus:outline-none mb-4"
              autoFocus
            />
            <div className="flex gap-3 justify-end">
              <Button
                variant="ghost"
                onClick={() => {
                  setIsLinkModalOpen(false)
                  setLinkUrl("")
                }}
                className="text-gray-300 hover:text-white"
              >
                取消
              </Button>
              <Button
                onClick={insertLink}
                className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent"
              >
                插入
              </Button>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        [contenteditable]:empty:before {
          content: attr(data-placeholder);
          color: #6b7280;
          pointer-events: none;
        }
        [contenteditable] h1 { font-size: 2rem; font-weight: bold; margin: 1rem 0; }
        [contenteditable] h2 { font-size: 1.5rem; font-weight: bold; margin: 0.8rem 0; }
        [contenteditable] h3 { font-size: 1.25rem; font-weight: bold; margin: 0.6rem 0; }
        [contenteditable] h4 { font-size: 1.1rem; font-weight: bold; margin: 0.4rem 0; }
        [contenteditable] ul, [contenteditable] ol { margin: 1rem 0; padding-left: 2rem; }
        [contenteditable] li { margin: 0.25rem 0; }
        [contenteditable] a { color: #a855f7; text-decoration: underline; }
        [contenteditable] strong { font-weight: bold; }
        [contenteditable] em { font-style: italic; }
        [contenteditable] u { text-decoration: underline; }
      `}</style>
    </div>
  )
}
