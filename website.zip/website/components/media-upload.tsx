"use client"

import type React from "react"
import { useState, useRef, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Upload,
  X,
  File,
  ImageIcon,
  Video,
  FileText,
  Download,
  Play,
  Crop,
  FileArchiveIcon as Compress,
  Eye,
  Settings,
  Music,
  Archive,
  Code,
} from "lucide-react"

interface MediaFile {
  id: string
  name: string
  size: number
  type: string
  url: string
  preview?: string
  thumbnail?: string
  duration?: number
  dimensions?: { width: number; height: number }
  compressed?: boolean
  metadata?: {
    [key: string]: any
  }
}

interface MediaUploadProps {
  onFilesChange: (files: MediaFile[]) => void
  acceptedTypes?: string[]
  maxSize?: number // MB
  maxFiles?: number
  existingFiles?: MediaFile[]
  className?: string
  enableCompression?: boolean
  enableCropping?: boolean
  quality?: number
}

export function MediaUpload({
  onFilesChange,
  acceptedTypes = ["image/*", "video/*", "audio/*", ".pdf", ".doc", ".docx", ".ppt", ".pptx", ".zip", ".rar"],
  maxSize = 100,
  maxFiles = 20,
  existingFiles = [],
  className = "",
  enableCompression = true,
  enableCropping = true,
  quality = 0.8,
}: MediaUploadProps) {
  const [files, setFiles] = useState<MediaFile[]>(existingFiles)
  const [isDragOver, setIsDragOver] = useState(false)
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({})
  const [processingFiles, setProcessingFiles] = useState<Set<string>>(new Set())
  const [previewFile, setPreviewFile] = useState<MediaFile | null>(null)
  const [showPreview, setShowPreview] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const getFileIcon = (type: string) => {
    if (type.startsWith("image/")) return <ImageIcon className="w-6 h-6" />
    if (type.startsWith("video/")) return <Video className="w-6 h-6" />
    if (type.startsWith("audio/")) return <Music className="w-6 h-6" />
    if (type.includes("pdf") || type.includes("document")) return <FileText className="w-6 h-6" />
    if (type.includes("zip") || type.includes("rar") || type.includes("archive")) return <Archive className="w-6 h-6" />
    if (type.includes("code") || type.includes("text")) return <Code className="w-6 h-6" />
    return <File className="w-6 h-6" />
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const compressImage = (file: File, quality = 0.8): Promise<File> => {
    return new Promise((resolve) => {
      const canvas = document.createElement("canvas")
      const ctx = canvas.getContext("2d")
      const img = new Image()

      img.onload = () => {
        // 计算压缩后的尺寸
        let { width, height } = img
        const maxWidth = 1920
        const maxHeight = 1080

        if (width > maxWidth || height > maxHeight) {
          const ratio = Math.min(maxWidth / width, maxHeight / height)
          width *= ratio
          height *= ratio
        }

        canvas.width = width
        canvas.height = height

        ctx?.drawImage(img, 0, 0, width, height)

        canvas.toBlob(
          (blob) => {
            if (blob) {
              const compressedFile = new File([blob], file.name, {
                type: file.type,
                lastModified: Date.now(),
              })
              resolve(compressedFile)
            } else {
              resolve(file)
            }
          },
          file.type,
          quality,
        )
      }

      img.src = URL.createObjectURL(file)
    })
  }

  const extractMediaMetadata = (file: File): Promise<any> => {
    return new Promise((resolve) => {
      if (file.type.startsWith("image/")) {
        const img = new Image()
        img.onload = () => {
          resolve({
            width: img.width,
            height: img.height,
            aspectRatio: (img.width / img.height).toFixed(2),
          })
        }
        img.src = URL.createObjectURL(file)
      } else if (file.type.startsWith("video/")) {
        const video = document.createElement("video")
        video.onloadedmetadata = () => {
          resolve({
            width: video.videoWidth,
            height: video.videoHeight,
            duration: video.duration,
            aspectRatio: (video.videoWidth / video.videoHeight).toFixed(2),
          })
        }
        video.src = URL.createObjectURL(file)
      } else if (file.type.startsWith("audio/")) {
        const audio = document.createElement("audio")
        audio.onloadedmetadata = () => {
          resolve({
            duration: audio.duration,
          })
        }
        audio.src = URL.createObjectURL(file)
      } else {
        resolve({})
      }
    })
  }

  const processFile = async (file: File): Promise<MediaFile> => {
    const fileId = Math.random().toString(36).substr(2, 9)

    setProcessingFiles((prev) => new Set(prev).add(fileId))

    try {
      let processedFile = file

      // 图片压缩
      if (enableCompression && file.type.startsWith("image/") && file.size > 1024 * 1024) {
        processedFile = await compressImage(file, quality)
      }

      // 提取元数据
      const metadata = await extractMediaMetadata(processedFile)

      // 创建预览
      let preview: string | undefined
      let thumbnail: string | undefined

      if (processedFile.type.startsWith("image/")) {
        preview = URL.createObjectURL(processedFile)
        thumbnail = preview
      } else if (processedFile.type.startsWith("video/")) {
        // 为视频创建缩略图
        const video = document.createElement("video")
        const canvas = document.createElement("canvas")
        const ctx = canvas.getContext("2d")

        await new Promise<void>((resolve) => {
          video.onloadeddata = () => {
            canvas.width = video.videoWidth
            canvas.height = video.videoHeight
            ctx?.drawImage(video, 0, 0)
            thumbnail = canvas.toDataURL()
            resolve()
          }
          video.src = URL.createObjectURL(processedFile)
          video.currentTime = 1 // 获取第1秒的帧
        })

        preview = URL.createObjectURL(processedFile)
      }

      const mediaFile: MediaFile = {
        id: fileId,
        name: processedFile.name,
        size: processedFile.size,
        type: processedFile.type,
        url: URL.createObjectURL(processedFile),
        preview,
        thumbnail,
        duration: metadata.duration,
        dimensions: metadata.width ? { width: metadata.width, height: metadata.height } : undefined,
        compressed: processedFile.size < file.size,
        metadata,
      }

      return mediaFile
    } finally {
      setProcessingFiles((prev) => {
        const newSet = new Set(prev)
        newSet.delete(fileId)
        return newSet
      })
    }
  }

  const simulateUpload = (mediaFile: MediaFile): Promise<MediaFile> => {
    return new Promise((resolve) => {
      let progress = 0
      const interval = setInterval(() => {
        progress += Math.random() * 25 + 5
        if (progress >= 100) {
          progress = 100
          clearInterval(interval)

          setUploadProgress((prev) => {
            const newProgress = { ...prev }
            delete newProgress[mediaFile.id]
            return newProgress
          })

          resolve(mediaFile)
        } else {
          setUploadProgress((prev) => ({ ...prev, [mediaFile.id]: progress }))
        }
      }, 150)
    })
  }

  const handleFiles = useCallback(
    async (fileList: FileList) => {
      const newFiles = Array.from(fileList)

      // 检查文件数量限制
      if (files.length + newFiles.length > maxFiles) {
        alert(`最多只能上传 ${maxFiles} 个文件`)
        return
      }

      // 检查文件大小和类型
      const validFiles = newFiles.filter((file) => {
        if (file.size > maxSize * 1024 * 1024) {
          alert(`文件 ${file.name} 超过 ${maxSize}MB 限制`)
          return false
        }

        const isValidType = acceptedTypes.some((type) => {
          if (type.startsWith(".")) {
            return file.name.toLowerCase().endsWith(type.toLowerCase())
          }
          return file.type.match(type.replace("*", ".*"))
        })

        if (!isValidType) {
          alert(`文件 ${file.name} 类型不支持`)
          return false
        }

        return true
      })

      // 处理和上传文件
      const processPromises = validFiles.map(processFile)
      const processedFiles = await Promise.all(processPromises)

      const uploadPromises = processedFiles.map(simulateUpload)
      const uploadedFiles = await Promise.all(uploadPromises)

      const updatedFiles = [...files, ...uploadedFiles]
      setFiles(updatedFiles)
      onFilesChange(updatedFiles)
    },
    [files, maxFiles, maxSize, acceptedTypes, onFilesChange, enableCompression, quality],
  )

  // ... existing drag and drop handlers ...
  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragOver(false)

      const droppedFiles = e.dataTransfer.files
      if (droppedFiles.length > 0) {
        handleFiles(droppedFiles)
      }
    },
    [handleFiles],
  )

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)
  }, [])

  const handleFileSelect = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const selectedFiles = e.target.files
      if (selectedFiles && selectedFiles.length > 0) {
        handleFiles(selectedFiles)
      }
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    },
    [handleFiles],
  )

  const removeFile = (fileId: string) => {
    const updatedFiles = files.filter((file) => file.id !== fileId)
    setFiles(updatedFiles)
    onFilesChange(updatedFiles)
  }

  const openFileDialog = () => {
    fileInputRef.current?.click()
  }

  const openPreview = (file: MediaFile) => {
    setPreviewFile(file)
    setShowPreview(true)
  }

  return (
    <div className={`space-y-4 ${className}`}>
      {/* 上传区域 */}
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-all duration-300 cursor-pointer ${
          isDragOver ? "border-fuchsia-400 bg-fuchsia-400/10" : "border-gray-600 hover:border-gray-500 bg-gray-900/30"
        }`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={openFileDialog}
      >
        <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-white mb-2">上传媒体文件</h3>
        <p className="text-gray-400 mb-4">拖拽文件到此处，或点击选择文件</p>
        <div className="text-sm text-gray-500 space-y-1">
          <p>支持图片、视频、音频、文档等格式</p>
          <p>
            单个文件最大 {maxSize}MB，最多 {maxFiles} 个文件
          </p>
          {enableCompression && <p className="text-fuchsia-400">✨ 自动压缩优化</p>}
        </div>
        <Button
          type="button"
          className="mt-4 border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300"
          onClick={(e) => {
            e.stopPropagation()
            openFileDialog()
          }}
        >
          选择文件
        </Button>
      </div>

      {/* 隐藏的文件输入 */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept={acceptedTypes.join(",")}
        onChange={handleFileSelect}
        className="hidden"
      />

      {/* 文件列表 */}
      {files.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-lg font-semibold text-white">已上传文件 ({files.length})</h4>
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <span>总大小: {formatFileSize(files.reduce((sum, file) => sum + file.size, 0))}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {files.map((file) => (
              <Card
                key={file.id}
                className="bg-gray-900/30 border-gray-800/50 hover:border-fuchsia-400/30 transition-all duration-300"
              >
                <CardContent className="p-4">
                  {/* 媒体预览区域 */}
                  <div className="aspect-video bg-gray-800 rounded-lg mb-3 flex items-center justify-center overflow-hidden relative group">
                    {file.thumbnail || file.preview ? (
                      <div className="relative w-full h-full">
                        <img
                          src={file.thumbnail || file.preview}
                          alt={file.name}
                          className="w-full h-full object-cover"
                        />
                        {file.type.startsWith("video/") && (
                          <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                            <Play className="w-8 h-8 text-white" />
                          </div>
                        )}
                        {file.duration && (
                          <Badge className="absolute bottom-2 right-2 bg-black/70 text-white text-xs">
                            {formatDuration(file.duration)}
                          </Badge>
                        )}
                      </div>
                    ) : (
                      <div className="text-gray-400 text-center">
                        {getFileIcon(file.type)}
                        <p className="text-xs mt-2">{file.type.split("/")[1]?.toUpperCase()}</p>
                      </div>
                    )}

                    {/* 悬停操作按钮 */}
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-white hover:text-fuchsia-400 hover:bg-white/20"
                        onClick={() => openPreview(file)}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-white hover:text-blue-400 hover:bg-white/20"
                        onClick={() => window.open(file.url, "_blank")}
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {/* 文件信息 */}
                  <div className="space-y-2">
                    <h5 className="text-white font-medium truncate text-sm">{file.name}</h5>

                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <span>{formatFileSize(file.size)}</span>
                      {file.dimensions && (
                        <span>
                          {file.dimensions.width}×{file.dimensions.height}
                        </span>
                      )}
                    </div>

                    {/* 状态标识 */}
                    <div className="flex items-center gap-1">
                      {file.compressed && (
                        <Badge variant="outline" className="border-green-500/30 text-green-400 text-xs">
                          <Compress className="w-3 h-3 mr-1" />
                          已压缩
                        </Badge>
                      )}
                      {processingFiles.has(file.id) && (
                        <Badge variant="outline" className="border-blue-500/30 text-blue-400 text-xs">
                          <Settings className="w-3 h-3 mr-1 animate-spin" />
                          处理中
                        </Badge>
                      )}
                    </div>

                    {/* 上传进度 */}
                    {uploadProgress[file.id] !== undefined && (
                      <div className="space-y-1">
                        <div className="w-full bg-gray-700 rounded-full h-1.5">
                          <div
                            className="bg-fuchsia-400 h-1.5 rounded-full transition-all duration-300"
                            style={{ width: `${uploadProgress[file.id]}%` }}
                          />
                        </div>
                        <p className="text-xs text-gray-400">上传中... {Math.round(uploadProgress[file.id])}%</p>
                      </div>
                    )}

                    {/* 操作按钮 */}
                    <div className="flex items-center justify-between pt-2">
                      <div className="flex items-center gap-1">
                        {file.type.startsWith("image/") && enableCropping && (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-gray-400 hover:text-yellow-400 hover:bg-yellow-400/10 p-1"
                            title="裁剪"
                          >
                            <Crop className="w-3 h-3" />
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-gray-400 hover:text-blue-400 hover:bg-blue-400/10 p-1"
                          onClick={() => openPreview(file)}
                          title="预览"
                        >
                          <Eye className="w-3 h-3" />
                        </Button>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-red-400 hover:text-red-300 hover:bg-red-400/10 p-1"
                        onClick={() => removeFile(file.id)}
                        title="删除"
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* 媒体预览模态框 */}
      {showPreview && previewFile && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-lg border border-gray-700 max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-gray-700">
              <h3 className="text-white font-medium truncate">{previewFile.name}</h3>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setShowPreview(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            <div className="p-4">
              {previewFile.type.startsWith("image/") && (
                <img
                  src={previewFile.preview || "/placeholder.svg"}
                  alt={previewFile.name}
                  className="w-full h-auto max-h-[60vh] object-contain rounded"
                />
              )}
              {previewFile.type.startsWith("video/") && (
                <video src={previewFile.preview} controls className="w-full h-auto max-h-[60vh] rounded" />
              )}
              {previewFile.type.startsWith("audio/") && (
                <div className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <Music className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <audio src={previewFile.preview} controls className="mb-4" />
                    <p className="text-gray-300">{previewFile.name}</p>
                  </div>
                </div>
              )}

              {/* 文件信息 */}
              <div className="mt-4 p-3 bg-gray-800/50 rounded border border-gray-700">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">大小:</span>
                    <span className="text-white ml-2">{formatFileSize(previewFile.size)}</span>
                  </div>
                  {previewFile.dimensions && (
                    <div>
                      <span className="text-gray-400">尺寸:</span>
                      <span className="text-white ml-2">
                        {previewFile.dimensions.width}×{previewFile.dimensions.height}
                      </span>
                    </div>
                  )}
                  {previewFile.duration && (
                    <div>
                      <span className="text-gray-400">时长:</span>
                      <span className="text-white ml-2">{formatDuration(previewFile.duration)}</span>
                    </div>
                  )}
                  <div>
                    <span className="text-gray-400">类型:</span>
                    <span className="text-white ml-2">{previewFile.type}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
