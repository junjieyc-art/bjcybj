"use client"

import type React from "react"

import { useState, useRef, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Upload, X, File, ImageIcon, Video, FileText, Download } from "lucide-react"
import { storage } from "@/lib/storage"

interface UploadedFile {
  id: string
  name: string
  size: number
  type: string
  url: string
  preview?: string
}

interface FileUploadProps {
  onFilesChange: (files: UploadedFile[]) => void
  acceptedTypes?: string[]
  maxSize?: number // MB
  maxFiles?: number
  existingFiles?: UploadedFile[]
  className?: string
}

export function FileUpload({
  onFilesChange,
  acceptedTypes = ["image/*", "video/*", ".pdf", ".doc", ".docx", ".ppt", ".pptx"],
  maxSize = 50,
  maxFiles = 10,
  existingFiles = [],
  className = "",
}: FileUploadProps) {
  const [files, setFiles] = useState<UploadedFile[]>(existingFiles)
  const [isDragOver, setIsDragOver] = useState(false)
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({})
  const [uploading, setUploading] = useState<{ [key: string]: boolean }>({})
  const fileInputRef = useRef<HTMLInputElement>(null)

  const getFileIcon = (type: string) => {
    if (type.startsWith("image/")) return <ImageIcon className="w-6 h-6" />
    if (type.startsWith("video/")) return <Video className="w-6 h-6" />
    if (type.includes("pdf") || type.includes("document")) return <FileText className="w-6 h-6" />
    return <File className="w-6 h-6" />
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const uploadFile = async (file: File): Promise<UploadedFile | null> => {
    const fileId = Math.random().toString(36).substr(2, 9)

    try {
      setUploading((prev) => ({ ...prev, [fileId]: true }))
      setUploadProgress((prev) => ({ ...prev, [fileId]: 0 }))

      const progressInterval = setInterval(() => {
        setUploadProgress((prev) => {
          const currentProgress = prev[fileId] || 0
          if (currentProgress < 90) {
            return { ...prev, [fileId]: currentProgress + Math.random() * 20 }
          }
          return prev
        })
      }, 200)

      const result = await storage.uploadFile(file)

      clearInterval(progressInterval)

      if (!result.success || !result.url || !result.metadata) {
        throw new Error(result.error || "Upload failed")
      }

      setUploadProgress((prev) => ({ ...prev, [fileId]: 100 }))

      const preview = file.type.startsWith("image/") ? URL.createObjectURL(file) : undefined

      const uploadedFile: UploadedFile = {
        id: fileId,
        name: result.metadata.name,
        size: result.metadata.size,
        type: result.metadata.type,
        url: result.url,
        preview,
      }

      setTimeout(() => {
        setUploadProgress((prev) => {
          const newProgress = { ...prev }
          delete newProgress[fileId]
          return newProgress
        })
        setUploading((prev) => {
          const newUploading = { ...prev }
          delete newUploading[fileId]
          return newUploading
        })
      }, 1000)

      return uploadedFile
    } catch (error) {
      console.error("Upload error:", error)
      setUploadProgress((prev) => {
        const newProgress = { ...prev }
        delete newProgress[fileId]
        return newProgress
      })
      setUploading((prev) => {
        const newUploading = { ...prev }
        delete newUploading[fileId]
        return newUploading
      })

      alert(`上传失败: ${error instanceof Error ? error.message : "未知错误"}`)
      return null
    }
  }

  const handleFiles = useCallback(
    async (fileList: FileList) => {
      const newFiles = Array.from(fileList)

      if (files.length + newFiles.length > maxFiles) {
        alert(`最多只能上传 ${maxFiles} 个文件`)
        return
      }

      const validFiles = newFiles.filter((file) => {
        if (!storage.constructor.isValidFileSize(file, maxSize)) {
          alert(`文件 ${file.name} 超过 ${maxSize}MB 限制`)
          return false
        }

        if (!storage.constructor.isValidFileType(file)) {
          alert(`文件 ${file.name} 类型不支持`)
          return false
        }

        return true
      })

      const uploadPromises = validFiles.map(uploadFile)
      const uploadResults = await Promise.all(uploadPromises)

      const successfulUploads = uploadResults.filter((result): result is UploadedFile => result !== null)

      const updatedFiles = [...files, ...successfulUploads]
      setFiles(updatedFiles)
      onFilesChange(updatedFiles)
    },
    [files, maxFiles, maxSize, acceptedTypes, onFilesChange],
  )

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragOver(false)

      const droppedFiles = e.dataTransfer.files
      if (droppedFiles.length > 0) {
        handleFiles(droppedFiles)
      }
    },
    [handleFiles],
  )

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)
  }, [])

  const handleFileSelect = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const selectedFiles = e.target.files
      if (selectedFiles && selectedFiles.length > 0) {
        handleFiles(selectedFiles)
      }
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    },
    [handleFiles],
  )

  const removeFile = async (fileId: string) => {
    const fileToRemove = files.find((f) => f.id === fileId)
    if (fileToRemove) {
      try {
        const filename = fileToRemove.url.split("/").pop()
        if (filename) {
          await storage.deleteFile(filename)
        }
      } catch (error) {
        console.error("Delete error:", error)
      }
    }

    const updatedFiles = files.filter((file) => file.id !== fileId)
    setFiles(updatedFiles)
    onFilesChange(updatedFiles)
  }

  const openFileDialog = () => {
    fileInputRef.current?.click()
  }

  return (
    <div className={`space-y-4 ${className}`}>
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-all duration-300 cursor-pointer ${
          isDragOver ? "border-fuchsia-400 bg-fuchsia-400/10" : "border-gray-600 hover:border-gray-500 bg-gray-900/30"
        }`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={openFileDialog}
      >
        <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-white mb-2">上传文件</h3>
        <p className="text-gray-400 mb-4">拖拽文件到此处，或点击选择文件</p>
        <p className="text-sm text-gray-500">支持图片、视频、文档等格式，单个文件最大 {maxSize}MB</p>
        <Button
          type="button"
          className="mt-4 border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300"
          onClick={(e) => {
            e.stopPropagation()
            openFileDialog()
          }}
        >
          选择文件
        </Button>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept={acceptedTypes.join(",")}
        onChange={handleFileSelect}
        className="hidden"
      />

      {files.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-lg font-semibold text-white">已上传文件 ({files.length})</h4>
          <div className="grid grid-cols-1 gap-3">
            {files.map((file) => (
              <Card key={file.id} className="bg-gray-900/30 border-gray-800/50">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="flex-shrink-0">
                      {file.preview ? (
                        <img
                          src={file.preview || "/placeholder.svg"}
                          alt={file.name}
                          className="w-12 h-12 object-cover rounded"
                        />
                      ) : (
                        <div className="w-12 h-12 bg-gray-700 rounded flex items-center justify-center text-gray-400">
                          {getFileIcon(file.type)}
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <h5 className="text-white font-medium truncate">{file.name}</h5>
                      <p className="text-sm text-gray-400">{formatFileSize(file.size)}</p>

                      {uploadProgress[file.id] !== undefined && (
                        <div className="mt-2">
                          <div className="w-full bg-gray-700 rounded-full h-2">
                            <div
                              className="bg-fuchsia-400 h-2 rounded-full transition-all duration-300"
                              style={{ width: `${uploadProgress[file.id]}%` }}
                            />
                          </div>
                          <p className="text-xs text-gray-400 mt-1">上传中... {Math.round(uploadProgress[file.id])}%</p>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-gray-400 hover:text-white"
                        onClick={() => window.open(file.url, "_blank")}
                        title="预览/下载"
                        disabled={uploading[file.id]}
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-red-400 hover:text-red-300 hover:bg-red-400/10"
                        onClick={() => removeFile(file.id)}
                        title="删除"
                        disabled={uploading[file.id]}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
