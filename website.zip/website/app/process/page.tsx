"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function ProcessPage() {
  return (
    <div className="min-h-screen bg-gray-950 relative">
      {/* 背景装饰效果 */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-500/8 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-cyan-500/6 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-fuchsia-500/4 rounded-full blur-3xl"></div>
      </div>

      {/* 导航栏 */}
      <nav className="sticky top-0 z-50 bg-gray-950/70 backdrop-blur-xl supports-[backdrop-filter]:bg-gray-950/60 border-b border-gray-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="/services" className="text-gray-200 hover:text-white transition-colors">
                核心服务
              </a>
              <a href="/cases" className="text-gray-200 hover:text-white transition-colors">
                精选案例
              </a>
              <a href="/team" className="text-gray-200 hover:text-white transition-colors">
                专业团队
              </a>
              <a href="/about" className="text-gray-200 hover:text-white transition-colors">
                关于我们
              </a>
              <a href="/contact" className="text-gray-200 hover:text-white transition-colors">
                联系我们
              </a>
            </div>
            <Button className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300">
              免费咨询
            </Button>
          </div>
        </div>
      </nav>

      {/* 英雄区域 */}
      <section className="relative bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-[url('/abstract-geometric-pattern.png')] opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <div className="text-sm text-violet-300 mb-4 tracking-wider uppercase">专业合作流程</div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 font-serif">
              <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">
                科学化项目管理
              </span>
            </h1>
            <p className="text-xl text-gray-200 mb-12 max-w-3xl mx-auto leading-relaxed">
              我们采用标准化的项目管理流程，确保每个项目都能高效执行，按时交付，超越客户期望
            </p>
          </div>
        </div>
      </section>

      {/* 合作流程步骤 */}
      <section className="py-20 bg-gray-950/50 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">合作流程</h2>
            <p className="text-lg text-gray-300">从初步接触到项目交付，我们为您提供全程专业服务</p>
          </div>

          <div className="relative">
            {/* 连接线 */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-violet-500 via-fuchsia-500 to-cyan-500 opacity-30 hidden lg:block"></div>

            <div className="space-y-16">
              {/* 步骤1：需求沟通 */}
              <div className="flex flex-col lg:flex-row items-center gap-8">
                <div className="lg:w-1/2 lg:pr-12">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-violet-500 to-violet-600 rounded-full flex items-center justify-center text-white font-bold text-lg mr-4">
                      01
                    </div>
                    <h3 className="text-2xl font-bold text-white">需求沟通</h3>
                  </div>
                  <p className="text-gray-300 mb-6 leading-relaxed">
                    深入了解您的品牌背景、目标受众、市场定位和项目需求，通过详细的沟通确保我们完全理解您的期望和目标。
                  </p>
                  <ul className="space-y-2 text-gray-400">
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-violet-400 rounded-full mr-3"></div>
                      品牌现状分析
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-violet-400 rounded-full mr-3"></div>
                      目标受众研究
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-violet-400 rounded-full mr-3"></div>
                      项目需求梳理
                    </li>
                  </ul>
                </div>
                <div className="lg:w-1/2 lg:pl-12">
                  <Card className="bg-gray-900/50 border-gray-800/50 overflow-hidden">
                    <CardContent className="p-0">
                      <img src="/business-meeting-discussion.png" alt="需求沟通" className="w-full h-64 object-cover" />
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* 步骤2：方案策划 */}
              <div className="flex flex-col lg:flex-row-reverse items-center gap-8">
                <div className="lg:w-1/2 lg:pl-12">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-fuchsia-500 to-fuchsia-600 rounded-full flex items-center justify-center text-white font-bold text-lg mr-4">
                      02
                    </div>
                    <h3 className="text-2xl font-bold text-white">方案策划</h3>
                  </div>
                  <p className="text-gray-300 mb-6 leading-relaxed">
                    基于前期沟通的结果，我们的专业团队将制定详细的项目方案，包括创意策略、执行计划和时间安排。
                  </p>
                  <ul className="space-y-2 text-gray-400">
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-fuchsia-400 rounded-full mr-3"></div>
                      创意策略制定
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-fuchsia-400 rounded-full mr-3"></div>
                      执行方案规划
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-fuchsia-400 rounded-full mr-3"></div>
                      项目时间安排
                    </li>
                  </ul>
                </div>
                <div className="lg:w-1/2 lg:pr-12">
                  <Card className="bg-gray-900/50 border-gray-800/50 overflow-hidden">
                    <CardContent className="p-0">
                      <img src="/creative-brainstorming-session.png" alt="方案策划" className="w-full h-64 object-cover" />
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* 步骤3：合同签署 */}
              <div className="flex flex-col lg:flex-row items-center gap-8">
                <div className="lg:w-1/2 lg:pr-12">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-cyan-600 rounded-full flex items-center justify-center text-white font-bold text-lg mr-4">
                      03
                    </div>
                    <h3 className="text-2xl font-bold text-white">合同签署</h3>
                  </div>
                  <p className="text-gray-300 mb-6 leading-relaxed">
                    确认项目方案和报价后，我们将与您签署正式合同，明确双方的权利义务，确保项目顺利进行。
                  </p>
                  <ul className="space-y-2 text-gray-400">
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full mr-3"></div>
                      方案确认
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full mr-3"></div>
                      合同条款协商
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full mr-3"></div>
                      正式签约
                    </li>
                  </ul>
                </div>
                <div className="lg:w-1/2 lg:pl-12">
                  <Card className="bg-gray-900/50 border-gray-800/50 overflow-hidden">
                    <CardContent className="p-0">
                      <img src="/placeholder-z2s3n.png" alt="合同签署" className="w-full h-64 object-cover" />
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* 步骤4：项目执行 */}
              <div className="flex flex-col lg:flex-row-reverse items-center gap-8">
                <div className="lg:w-1/2 lg:pl-12">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-violet-500 to-fuchsia-500 rounded-full flex items-center justify-center text-white font-bold text-lg mr-4">
                      04
                    </div>
                    <h3 className="text-2xl font-bold text-white">项目执行</h3>
                  </div>
                  <p className="text-gray-300 mb-6 leading-relaxed">
                    项目正式启动后，我们的专业团队将按照既定方案进行执行，定期向您汇报项目进展，确保项目按时推进。
                  </p>
                  <ul className="space-y-2 text-gray-400">
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-violet-400 rounded-full mr-3"></div>
                      项目启动会议
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-violet-400 rounded-full mr-3"></div>
                      阶段性成果交付
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-violet-400 rounded-full mr-3"></div>
                      定期进度汇报
                    </li>
                  </ul>
                </div>
                <div className="lg:w-1/2 lg:pr-12">
                  <Card className="bg-gray-900/50 border-gray-800/50 overflow-hidden">
                    <CardContent className="p-0">
                      <img src="/team-collaboration-project.png" alt="项目执行" className="w-full h-64 object-cover" />
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* 步骤5：成果交付 */}
              <div className="flex flex-col lg:flex-row items-center gap-8">
                <div className="lg:w-1/2 lg:pr-12">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-fuchsia-500 to-cyan-500 rounded-full flex items-center justify-center text-white font-bold text-lg mr-4">
                      05
                    </div>
                    <h3 className="text-2xl font-bold text-white">成果交付</h3>
                  </div>
                  <p className="text-gray-300 mb-6 leading-relaxed">
                    项目完成后，我们将向您交付所有项目成果，包括设计文件、营销素材、使用指南等，确保您能够顺利使用。
                  </p>
                  <ul className="space-y-2 text-gray-400">
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full mr-3"></div>
                      最终成果展示
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full mr-3"></div>
                      文件资料交付
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full mr-3"></div>
                      使用培训指导
                    </li>
                  </ul>
                </div>
                <div className="lg:w-1/2 lg:pl-12">
                  <Card className="bg-gray-900/50 border-gray-800/50 overflow-hidden">
                    <CardContent className="p-0">
                      <img src="/project-delivery-presentation-success.png" alt="成果交付" className="w-full h-64 object-cover" />
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* 步骤6：售后服务 */}
              <div className="flex flex-col lg:flex-row-reverse items-center gap-8">
                <div className="lg:w-1/2 lg:pl-12">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-violet-500 rounded-full flex items-center justify-center text-white font-bold text-lg mr-4">
                      06
                    </div>
                    <h3 className="text-2xl font-bold text-white">售后服务</h3>
                  </div>
                  <p className="text-gray-300 mb-6 leading-relaxed">
                    项目交付后，我们提供完善的售后服务支持，包括技术支持、优化建议和后续合作机会，确保长期合作关系。
                  </p>
                  <ul className="space-y-2 text-gray-400">
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-fuchsia-400 rounded-full mr-3"></div>
                      技术支持服务
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-fuchsia-400 rounded-full mr-3"></div>
                      效果跟踪分析
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-fuchsia-400 rounded-full mr-3"></div>
                      持续优化建议
                    </li>
                  </ul>
                </div>
                <div className="lg:w-1/2 lg:pr-12">
                  <Card className="bg-gray-900/50 border-gray-800/50 overflow-hidden">
                    <CardContent className="p-0">
                      <img src="/after-sales-support.png" alt="售后服务" className="w-full h-64 object-cover" />
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 项目管理优势 */}
      <section className="py-20 bg-gray-950 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">项目管理优势</h2>
            <p className="text-lg text-gray-300">专业的项目管理体系，确保每个项目都能高质量交付</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-gray-900/30 border-gray-800/50 hover:shadow-lg transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-violet-500 to-violet-600 rounded-full flex items-center justify-center mx-auto mb-6">
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M6 6V5a3 3 0 013-3h2a3 3 0 013 3v1h2a2 2 0 012 2v3.57A22.952 22.952 0 0110 13a22.95 22.95 0 01-8-1.43V8a2 2 0 012-2h2zm2-1a1 1 0 011-1h2a1 1 0 011 1v1H8V5zm1 5a1 1 0 011-1h.01a1 1 0 110 2H10a1 1 0 01-1-1z"
                      clipRule="evenodd"
                    />
                    <path d="M2 13.692V16a2 2 0 002 2h12a2 2 0 002-2v-2.308A24.974 24.974 0 0110 15c-2.796 0-5.487-.46-8-1.308z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">专业团队</h3>
                <p className="text-gray-400">经验丰富的项目经理和专业团队，确保项目高效执行</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-900/30 border-gray-800/50 hover:shadow-lg transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-fuchsia-500 to-fuchsia-600 rounded-full flex items-center justify-center mx-auto mb-6">
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">质量保证</h3>
                <p className="text-gray-400">严格的质量控制体系，确保每个交付物都达到最高标准</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-900/30 border-gray-800/50 hover:shadow-lg transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-cyan-500 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-6">
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">按时交付</h3>
                <p className="text-gray-400">科学的时间管理和进度控制，确保项目按时完成交付</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA区域 */}
      <section className="py-20 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-violet-500/20 rounded-full blur-3xl"></div>
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-cyan-500/20 rounded-full blur-3xl"></div>
        </div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 font-serif text-white">准备开始您的项目？</h2>
          <p className="text-xl mb-8 text-gray-300">让我们一起打造属于您的品牌故事，创造更大的商业价值</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300"
              onClick={() => (window.location.href = "/contact")}
            >
              立即咨询
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-violet-400 text-violet-400 hover:bg-violet-400 hover:text-white bg-transparent transition-all duration-300"
              onClick={() => (window.location.href = "/cases")}
            >
              查看案例
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-950 text-gray-300 py-12 border-t border-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <div className="text-2xl font-bold font-serif bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">
                创意传媒
              </div>
            </div>
            <div className="text-gray-500 text-sm">Copyright © 2024 创意传媒, All rights reserved.</div>
          </div>
        </div>
      </footer>
    </div>
  )
}
