"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useState } from "react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    service: "",
    budget: "",
    message: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
    // 这里可以添加表单提交逻辑
  }

  const contactInfo = [
    {
      title: "电话咨询",
      content: "400-888-9999",
      description: "工作日 9:00-18:00",
      icon: "📞",
      color: "from-violet-400 to-violet-600",
    },
    {
      title: "邮箱联系",
      content: "info@company.com",
      description: "24小时内回复",
      icon: "✉️",
      color: "from-fuchsia-400 to-fuchsia-600",
    },
    {
      title: "公司地址",
      content: "北京市朝阳区创意园区",
      description: "欢迎预约参观",
      icon: "📍",
      color: "from-cyan-400 to-cyan-600",
    },
    {
      title: "工作时间",
      content: "周一至周五 9:00-18:00",
      description: "周末及节假日休息",
      icon: "🕒",
      color: "from-emerald-400 to-emerald-600",
    },
  ]

  const services = [
    "品牌策略",
    "视觉设计",
    "数字营销",
    "活动策划",
    "内容营销",
    "社交媒体",
    "影视制作",
    "公关传播",
    "其他服务",
  ]

  const budgetRanges = ["10万以下", "10-30万", "30-50万", "50-100万", "100万以上", "待商议"]

  const faqs = [
    {
      question: "你们的服务流程是怎样的？",
      answer:
        "我们的服务流程包括：需求沟通 → 方案制定 → 合同签署 → 项目执行 → 成果交付 → 后续服务。每个环节都有专人负责，确保项目顺利进行。",
    },
    {
      question: "项目周期一般需要多长时间？",
      answer:
        "项目周期根据服务内容和复杂程度而定。一般来说，品牌设计项目需要2-4周，营销推广项目需要1-3个月，具体时间会在项目启动前确定。",
    },
    {
      question: "如何保证项目质量？",
      answer:
        "我们有完善的质量管控体系，包括多轮内部评审、客户确认机制、专业团队把关等。同时提供修改服务，确保最终成果符合客户期望。",
    },
    {
      question: "费用如何计算？",
      answer:
        "我们根据项目的具体需求、服务内容、项目周期等因素进行报价。提供透明的价格体系，无隐藏费用。可以先沟通需求，我们会提供详细的报价方案。",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-950 relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-500/8 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-cyan-500/6 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-fuchsia-500/4 rounded-full blur-3xl"></div>
      </div>

      <nav className="sticky top-0 z-50 bg-gray-950/70 backdrop-blur-xl supports-[backdrop-filter]:bg-gray-950/60 border-b border-gray-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-gray-200 hover:text-white transition-colors">
                首页
              </a>
              <a href="/services" className="text-gray-200 hover:text-white transition-colors">
                核心服务
              </a>
              <a href="/cases" className="text-gray-200 hover:text-white transition-colors">
                精选案例
              </a>
              <a href="/team" className="text-gray-200 hover:text-white transition-colors">
                专业团队
              </a>
              <a href="/about" className="text-gray-200 hover:text-white transition-colors">
                关于我们
              </a>
              <a href="/contact" className="text-white font-medium">
                联系我们
              </a>
            </div>
            <Button className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300">
              免费咨询
            </Button>
          </div>
        </div>
      </nav>

      <section className="relative bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 py-20 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <div className="text-sm text-violet-300 mb-4 tracking-wider uppercase">Contact Us</div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 font-serif">
              <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">
                联系我们
              </span>
            </h1>
            <p className="text-xl text-gray-200 mb-12 max-w-3xl mx-auto leading-relaxed">
              准备开始您的品牌之旅？我们期待与您合作，共同创造令人惊艳的品牌体验
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950/50 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {contactInfo.map((info, index) => (
              <Card
                key={index}
                className="group hover:shadow-xl transition-all duration-300 border-gray-800/50 overflow-hidden bg-gray-900/30"
              >
                <CardContent className="p-6 text-center">
                  <div
                    className={`w-16 h-16 bg-gradient-to-br ${info.color} rounded-full mx-auto mb-4 flex items-center justify-center text-2xl`}
                  >
                    {info.icon}
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">{info.title}</h3>
                  <p className="text-fuchsia-400 font-semibold mb-1">{info.content}</p>
                  <p className="text-gray-400 text-sm">{info.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
            <div className="lg:col-span-2">
              <div className="mb-8">
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">项目咨询</h2>
                <p className="text-lg text-gray-300">
                  请填写以下信息，我们会在24小时内与您取得联系，为您提供专业的咨询服务
                </p>
              </div>

              <Card className="bg-gray-900/30 border-gray-800/50">
                <CardContent className="p-8">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-white mb-2">姓名 *</label>
                        <input
                          type="text"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          required
                          className="w-full px-4 py-3 bg-gray-800/50 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-fuchsia-400 focus:border-transparent"
                          placeholder="请输入您的姓名"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-white mb-2">邮箱 *</label>
                        <input
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          required
                          className="w-full px-4 py-3 bg-gray-800/50 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-fuchsia-400 focus:border-transparent"
                          placeholder="请输入您的邮箱"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-white mb-2">电话</label>
                        <input
                          type="tel"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 bg-gray-800/50 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-fuchsia-400 focus:border-transparent"
                          placeholder="请输入您的电话"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-white mb-2">公司名称</label>
                        <input
                          type="text"
                          name="company"
                          value={formData.company}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 bg-gray-800/50 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-fuchsia-400 focus:border-transparent"
                          placeholder="请输入您的公司名称"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-white mb-2">服务需求</label>
                        <select
                          name="service"
                          value={formData.service}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 bg-gray-800/50 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-fuchsia-400 focus:border-transparent"
                        >
                          <option value="">请选择服务类型</option>
                          {services.map((service) => (
                            <option key={service} value={service}>
                              {service}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-white mb-2">预算范围</label>
                        <select
                          name="budget"
                          value={formData.budget}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 bg-gray-800/50 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-fuchsia-400 focus:border-transparent"
                        >
                          <option value="">请选择预算范围</option>
                          {budgetRanges.map((budget) => (
                            <option key={budget} value={budget}>
                              {budget}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-white mb-2">项目描述 *</label>
                      <textarea
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        required
                        rows={6}
                        className="w-full px-4 py-3 bg-gray-800/50 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-fuchsia-400 focus:border-transparent resize-none"
                        placeholder="请详细描述您的项目需求、目标、时间要求等信息..."
                      />
                    </div>

                    <Button
                      type="submit"
                      size="lg"
                      className="w-full border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300 py-4 text-lg"
                    >
                      提交咨询
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-white mb-6 font-serif">快速联系</h3>
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="w-32 h-32 bg-white rounded-2xl p-3 mb-4 mx-auto shadow-lg">
                      <img src="/wechat-business-qr.png" alt="微信二维码" className="w-full h-full object-contain" />
                    </div>
                    <h4 className="text-base font-semibold text-white mb-2">微信咨询</h4>
                    <p className="text-gray-400 text-xs">扫码添加微信，获取专业咨询</p>
                  </div>

                  <div className="text-center">
                    <div className="w-32 h-32 bg-white rounded-2xl p-3 mb-4 mx-auto shadow-lg">
                      <img src="/placeholder-0wjxd.png" alt="企业微信二维码" className="w-full h-full object-contain" />
                    </div>
                    <h4 className="text-base font-semibold text-white mb-2">企业微信</h4>
                    <p className="text-gray-400 text-xs">扫码联系企业微信，快速响应</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-white mb-6 font-serif">社交媒体</h3>
                <div className="flex space-x-4">
                  <div className="w-12 h-12 bg-gray-800/50 rounded-full flex items-center justify-center hover:bg-gray-700/50 transition-colors cursor-pointer border border-gray-700/50">
                    <svg className="w-6 h-6 text-gray-300" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z" />
                    </svg>
                  </div>
                  <div className="w-12 h-12 bg-gray-800/50 rounded-full flex items-center justify-center hover:bg-gray-700/50 transition-colors cursor-pointer border border-gray-700/50">
                    <svg className="w-6 h-6 text-gray-300" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                    </svg>
                  </div>
                  <div className="w-12 h-12 bg-gray-800/50 rounded-full flex items-center justify-center hover:bg-gray-700/50 transition-colors cursor-pointer border border-gray-700/50">
                    <svg className="w-6 h-6 text-gray-300" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.174-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.402.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.357-.629-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24.009 12.017 24c6.624 0 11.99-5.367 11.99-11.987C24.007 5.367 18.641.001 12.017.001z" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950/50 relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">常见问题</h2>
            <p className="text-lg text-gray-300">解答您可能关心的问题</p>
          </div>

          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <Card
                key={index}
                className="bg-gray-900/30 border-gray-800/50 hover:bg-gray-900/50 transition-all duration-300"
              >
                <CardContent className="p-6">
                  <h3 className="text-lg font-bold text-white mb-3">{faq.question}</h3>
                  <p className="text-gray-300 leading-relaxed">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950 relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 font-serif">还有其他问题？</h2>
          <p className="text-xl text-gray-300 mb-8">我们的专业团队随时为您提供帮助</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300 px-8 py-4 text-lg"
              onClick={() => alert("在线客服功能即将上线，请通过微信或电话联系我们")}
            >
              在线客服
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-violet-400 text-violet-400 hover:bg-violet-400 hover:text-white px-8 py-4 text-lg bg-transparent transition-all duration-300"
              onClick={() => alert("请通过电话 400-888-9999 预约会面时间")}
            >
              预约会面
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
