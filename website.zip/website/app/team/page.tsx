"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function TeamPage() {
  const teamMembers = [
    {
      id: "zhang-minghua",
      name: "张明华",
      position: "创意总监",
      positionEn: "Creative Director",
      department: "创意部门",
      experience: "15年",
      image: "/professional-male-executive.png",
      color: "from-cyan-400 to-cyan-600",
      badgeColor: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
      description: "15年品牌策划经验，曾服务过多家知名企业，擅长品牌战略规划和创意执行",
      fullBio:
        "张明华拥有15年的品牌策划和创意管理经验，曾在多家4A广告公司担任创意总监职务。他擅长品牌战略规划、创意概念开发和团队管理，成功为超过100个品牌提供了专业的创意服务。他的作品多次获得国内外广告奖项，在行业内享有很高的声誉。",
      skills: ["品牌策略", "创意管理", "团队领导", "项目管理"],
      achievements: ["获得金投赏创意奖3次", "服务Fortune 500企业20+", "团队管理经验10年", "成功案例100+"],
      education: "清华大学美术学院 视觉传达设计硕士",
      contact: {
        email: "zhang.minghua@company.com",
        linkedin: "zhang-minghua-creative",
      },
    },
    {
      id: "li-yajing",
      name: "李雅静",
      position: "设计总监",
      positionEn: "Design Director",
      department: "设计部门",
      experience: "12年",
      image: "/professional-female-designer.png",
      color: "from-violet-400 to-violet-600",
      badgeColor: "bg-violet-500/20 text-violet-300 border-violet-500/30",
      description: "国际4A广告公司出身，在视觉传达和品牌设计领域有着丰富的实战经验",
      fullBio:
        "李雅静毕业于中央美术学院，拥有12年的设计经验。她曾在奥美、麦肯等国际4A广告公司工作，负责多个国际品牌的视觉设计项目。她精通品牌视觉识别系统设计、包装设计和数字媒体设计，作品风格独特，深受客户好评。",
      skills: ["视觉设计", "品牌识别", "包装设计", "数字媒体"],
      achievements: ["红点设计奖获得者", "IF设计奖入围", "服务国际品牌50+", "设计作品被收录设计年鉴"],
      education: "中央美术学院 视觉传达设计学士",
      contact: {
        email: "li.yajing@company.com",
        linkedin: "li-yajing-design",
      },
    },
    {
      id: "wang-zhiyuan",
      name: "王志远",
      position: "营销总监",
      positionEn: "Marketing Director",
      department: "营销部门",
      experience: "10年",
      image: "/professional-male-marketing-director.png",
      color: "from-fuchsia-400 to-fuchsia-600",
      badgeColor: "bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-500/30",
      description: "数字营销专家，精通全媒体整合营销，曾操盘多个千万级营销项目",
      fullBio:
        "王志远是资深的数字营销专家，拥有10年的营销实战经验。他精通全媒体整合营销、数据分析和用户增长策略，曾成功操盘多个千万级营销项目。他对新媒体营销趋势有着敏锐的洞察力，善于将创意与数据相结合，为客户创造最大的营销价值。",
      skills: ["数字营销", "数据分析", "用户增长", "媒体策划"],
      achievements: ["操盘千万级项目10+", "ROI提升平均200%", "获得营销创新奖", "培养营销人才30+"],
      education: "北京大学 市场营销硕士",
      contact: {
        email: "wang.zhiyuan@company.com",
        linkedin: "wang-zhiyuan-marketing",
      },
    },
    {
      id: "chen-xiaoli",
      name: "陈小丽",
      position: "客户总监",
      positionEn: "Account Director",
      department: "客户服务",
      experience: "8年",
      image: "/professional-female-account-director.png",
      color: "from-emerald-400 to-emerald-600",
      badgeColor: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
      description: "资深客户服务专家，擅长客户关系管理和项目协调，客户满意度始终保持在95%以上",
      fullBio:
        "陈小丽拥有8年的客户服务和项目管理经验，她擅长客户需求分析、项目流程管理和团队协调。她服务过的客户涵盖各个行业，从初创企业到大型集团，都能提供专业的服务。她的客户满意度始终保持在95%以上，是团队中不可或缺的重要成员。",
      skills: ["客户管理", "项目协调", "需求分析", "团队协作"],
      achievements: ["客户满意度95%+", "服务客户200+", "项目成功率98%", "客户续约率85%"],
      education: "复旦大学 工商管理学士",
      contact: {
        email: "chen.xiaoli@company.com",
        linkedin: "chen-xiaoli-account",
      },
    },
    {
      id: "liu-haoran",
      name: "刘浩然",
      position: "技术总监",
      positionEn: "Technical Director",
      department: "技术部门",
      experience: "9年",
      image: "/professional-male-tech-director.png",
      color: "from-blue-400 to-blue-600",
      badgeColor: "bg-blue-500/20 text-blue-300 border-blue-500/30",
      description: "全栈技术专家，精通前端开发、后端架构和数据分析，为品牌数字化转型提供技术支持",
      fullBio:
        "刘浩然是经验丰富的全栈技术专家，拥有9年的技术开发和团队管理经验。他精通现代前端框架、后端架构设计和数据分析技术，曾主导多个大型数字化项目的技术实施。他善于将技术与创意相结合，为客户提供创新的数字化解决方案。",
      skills: ["全栈开发", "系统架构", "数据分析", "技术管理"],
      achievements: ["主导项目50+", "技术专利3项", "开源贡献者", "技术团队leader"],
      education: "北京理工大学 计算机科学硕士",
      contact: {
        email: "liu.haoran@company.com",
        linkedin: "liu-haoran-tech",
      },
    },
    {
      id: "zhao-meilin",
      name: "赵美琳",
      position: "内容总监",
      positionEn: "Content Director",
      department: "内容部门",
      experience: "7年",
      image: "/professional-female-content-director.png",
      color: "from-rose-400 to-rose-600",
      badgeColor: "bg-rose-500/20 text-rose-300 border-rose-500/30",
      description: "资深内容策划专家，擅长品牌故事构建和内容营销策略，创作的内容多次获得行业认可",
      fullBio:
        "赵美琳是资深的内容策划和创作专家，拥有7年的内容营销经验。她擅长品牌故事构建、内容策略规划和多媒体内容创作。她创作的内容作品多次在行业内获得认可，帮助众多品牌建立了独特的内容形象和用户粘性。",
      skills: ["内容策划", "文案创作", "故事构建", "多媒体制作"],
      achievements: ["内容阅读量1000万+", "获得内容营销奖", "爆款内容创作者", "KOL合作专家"],
      education: "中国传媒大学 新闻传播学硕士",
      contact: {
        email: "zhao.meilin@company.com",
        linkedin: "zhao-meilin-content",
      },
    },
  ]

  const departments = [
    {
      name: "创意部门",
      description: "负责品牌创意策略、概念开发和创意执行",
      members: teamMembers.filter((member) => member.department === "创意部门").length,
      color: "bg-cyan-500/10 border-cyan-500/30",
    },
    {
      name: "设计部门",
      description: "专注于视觉设计、品牌识别和用户体验",
      members: teamMembers.filter((member) => member.department === "设计部门").length,
      color: "bg-violet-500/10 border-violet-500/30",
    },
    {
      name: "营销部门",
      description: "制定营销策略、执行推广活动和数据分析",
      members: teamMembers.filter((member) => member.department === "营销部门").length,
      color: "bg-fuchsia-500/10 border-fuchsia-500/30",
    },
    {
      name: "客户服务",
      description: "客户关系管理、项目协调和服务质量保障",
      members: teamMembers.filter((member) => member.department === "客户服务").length,
      color: "bg-emerald-500/10 border-emerald-500/30",
    },
    {
      name: "技术部门",
      description: "技术开发、系统架构和数字化解决方案",
      members: teamMembers.filter((member) => member.department === "技术部门").length,
      color: "bg-blue-500/10 border-blue-500/30",
    },
    {
      name: "内容部门",
      description: "内容策划、文案创作和多媒体制作",
      members: teamMembers.filter((member) => member.department === "内容部门").length,
      color: "bg-rose-500/10 border-rose-500/30",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-950 relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-500/8 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-cyan-500/6 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-fuchsia-500/4 rounded-full blur-3xl"></div>
      </div>

      <nav className="sticky top-0 z-50 bg-gray-950/70 backdrop-blur-xl supports-[backdrop-filter]:bg-gray-950/60 border-b border-gray-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-gray-200 hover:text-white transition-colors">
                首页
              </a>
              <a href="/services" className="text-gray-200 hover:text-white transition-colors">
                核心服务
              </a>
              <a href="/cases" className="text-gray-200 hover:text-white transition-colors">
                精选案例
              </a>
              <a href="/team" className="text-white font-medium">
                专业团队
              </a>
              <a href="/about" className="text-gray-200 hover:text-white transition-colors">
                关于我们
              </a>
              <a href="/contact" className="text-gray-200 hover:text-white transition-colors">
                联系我们
              </a>
            </div>
            <Button className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300">
              免费咨询
            </Button>
          </div>
        </div>
      </nav>

      <section className="relative bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 py-20 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <div className="text-sm text-violet-300 mb-4 tracking-wider uppercase">Professional Team</div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 font-serif">
              <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">
                专业团队
              </span>
            </h1>
            <p className="text-xl text-gray-200 mb-12 max-w-3xl mx-auto leading-relaxed">
              汇聚行业顶尖人才，用专业和创意为品牌赋能，每一位成员都是各自领域的专家
            </p>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-950/50 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">团队架构</h2>
            <p className="text-lg text-gray-300">专业分工，协作共赢</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {departments.map((dept) => (
              <Card
                key={dept.name}
                className={`border ${dept.color} bg-gray-900/30 hover:bg-gray-900/50 transition-all duration-300`}
              >
                <CardContent className="p-6 text-center">
                  <h3 className="text-xl font-bold text-white mb-3">{dept.name}</h3>
                  <p className="text-gray-300 mb-4 text-sm leading-relaxed">{dept.description}</p>
                  <div className="text-2xl font-bold text-fuchsia-400">{dept.members} 人</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">核心成员</h2>
            <p className="text-lg text-gray-300">认识我们的专业团队</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {teamMembers.map((member) => (
              <Card
                key={member.id}
                className="group hover:shadow-xl transition-all duration-300 border-gray-800/50 overflow-hidden bg-gray-900/30"
              >
                <CardContent className="p-8">
                  <div className="flex items-start space-x-6">
                    <div
                      className={`w-24 h-24 bg-gradient-to-br ${member.color} rounded-full flex items-center justify-center flex-shrink-0`}
                    >
                      <img
                        src={member.image || "/placeholder.svg"}
                        alt={member.name}
                        className="w-full h-full rounded-full object-cover"
                      />
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-2xl font-bold text-white font-serif">{member.name}</h3>
                        <Badge className={member.badgeColor}>{member.experience}经验</Badge>
                      </div>

                      <div className="mb-3">
                        <div className="text-lg font-semibold text-fuchsia-400">{member.position}</div>
                        <div className="text-sm text-gray-400">{member.positionEn}</div>
                      </div>

                      <p className="text-gray-300 mb-4 leading-relaxed text-sm">{member.fullBio}</p>

                      <div className="mb-4">
                        <h4 className="text-sm font-semibold text-white mb-2">核心技能</h4>
                        <div className="flex flex-wrap gap-2">
                          {member.skills.map((skill, idx) => (
                            <Badge key={idx} variant="outline" className="border-gray-600 text-gray-300 text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="mb-4">
                        <h4 className="text-sm font-semibold text-white mb-2">主要成就</h4>
                        <ul className="text-xs text-gray-400 space-y-1">
                          {member.achievements.slice(0, 3).map((achievement, idx) => (
                            <li key={idx} className="flex items-center">
                              <div className="w-1 h-1 bg-fuchsia-400 rounded-full mr-2"></div>
                              {achievement}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="text-xs text-gray-500">
                        <div className="mb-1">教育背景: {member.education}</div>
                        <div>邮箱: {member.contact.email}</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950/50 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">团队文化</h2>
            <p className="text-lg text-gray-300">我们的价值观和工作理念</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-violet-400 to-violet-600 rounded-full mx-auto mb-6 flex items-center justify-center">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9 12l2 2 4-4m6 2a9 9 0 11-16 0 9 9 0 0116 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-white mb-4">专业至上</h3>
              <p className="text-gray-300 leading-relaxed">我们坚持专业标准，不断学习和提升，为客户提供最优质的服务</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-fuchsia-400 to-fuchsia-600 rounded-full mx-auto mb-6 flex items-center justify-center">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-white mb-4">团队协作</h3>
              <p className="text-gray-300 leading-relaxed">我们相信团队的力量，通过协作创造出超越个人能力的优秀作品</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-cyan-400 to-cyan-600 rounded-full mx-auto mb-6 flex items-center justify-center">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-white mb-4">追求卓越</h3>
              <p className="text-gray-300 leading-relaxed">
                我们追求卓越的品质，每一个项目都力求做到最好，超越客户期望
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950 relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 font-serif">想要加入我们的团队？</h2>
          <p className="text-xl text-gray-300 mb-8">我们一直在寻找有才华、有激情的专业人士加入我们的团队</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300 px-8 py-4 text-lg"
              onClick={() => (window.location.href = "/contact")}
            >
              查看职位
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-violet-400 text-violet-400 hover:bg-violet-400 hover:text-white px-8 py-4 text-lg bg-transparent transition-all duration-300"
              onClick={() => (window.location.href = "/contact")}
            >
              联系我们
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
