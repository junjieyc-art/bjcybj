"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { RichTextEditor } from "@/components/rich-text-editor"
import { FileUpload } from "@/components/file-upload"
import {
  Clock,
  Users,
  CheckCircle,
  Edit,
  Save,
  X,
  Plus,
  Loader2,
  Check,
  AlertCircle,
  Eye,
  EyeOff,
  Keyboard,
  HelpCircle,
  Target,
  Lightbulb,
} from "lucide-react"
import { notFound } from "next/navigation"
import casesData from "@/data/casesData" // Declare casesData variable

interface CaseDetailPageProps {
  params: {
    id: string
  }
}

interface UploadedFile {
  id: string
  name: string
  size: number
  type: string
  url: string
  preview?: string
}

type SaveStatus = "idle" | "saving" | "success" | "error"

export default function CaseDetailPage({ params }: CaseDetailPageProps) {
  const [isEditMode, setIsEditMode] = useState(false)
  const [editedData, setEditedData] = useState<any>(null)
  const [caseFiles, setCaseFiles] = useState<UploadedFile[]>([])
  const [showFileUpload, setShowFileUpload] = useState(false)
  const [saveStatus, setSaveStatus] = useState<SaveStatus>("idle")
  const [saveMessage, setSaveMessage] = useState("")
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false)
  const [showPreview, setShowPreview] = useState(false)
  const [showShortcuts, setShowShortcuts] = useState(false)
  const [editingField, setEditingField] = useState<string | null>(null)
  const [showEditHelp, setShowEditHelp] = useState(false)

  const caseData = casesData.find((c) => c.id === params.id)

  if (!caseData) {
    notFound()
  }

  const currentData = editedData || caseData

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isEditMode) return

      // Ctrl/Cmd + S 保存
      if ((e.ctrlKey || e.metaKey) && e.key === "s") {
        e.preventDefault()
        handleSave()
      }

      // Ctrl/Cmd + P 预览
      if ((e.ctrlKey || e.metaKey) && e.key === "p") {
        e.preventDefault()
        setShowPreview(!showPreview)
      }

      // Escape 取消编辑
      if (e.key === "Escape") {
        e.preventDefault()
        handleCancel()
      }

      // Ctrl/Cmd + ? 显示快捷键
      if ((e.ctrlKey || e.metaKey) && e.key === "/") {
        e.preventDefault()
        setShowShortcuts(!showShortcuts)
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [isEditMode, showPreview, showShortcuts])

  const autoSave = useCallback(async () => {
    if (!hasUnsavedChanges || !editedData) return

    try {
      setSaveStatus("saving")
      const response = await fetch(`/api/cases/${params.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          caseData: editedData,
          files: caseFiles,
        }),
      })

      if (response.ok) {
        setSaveStatus("success")
        setSaveMessage("自动保存成功")
        setHasUnsavedChanges(false)

        // 保存到本地存储作为备份
        localStorage.setItem(
          `case_${params.id}_backup`,
          JSON.stringify({
            caseData: editedData,
            files: caseFiles,
            timestamp: Date.now(),
          }),
        )
      } else {
        throw new Error("自动保存失败")
      }
    } catch (error) {
      setSaveStatus("error")
      setSaveMessage("自动保存失败")
      console.error("[v0] Auto-save error:", error)
    }

    // 清除状态消息
    setTimeout(() => {
      setSaveStatus("idle")
      setSaveMessage("")
    }, 3000)
  }, [hasUnsavedChanges, editedData, caseFiles, params.id])

  useEffect(() => {
    if (!isEditMode) return

    const autoSaveInterval = setInterval(autoSave, 30000) // 每30秒自动保存

    return () => clearInterval(autoSaveInterval)
  }, [isEditMode, autoSave])

  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (hasUnsavedChanges) {
        e.preventDefault()
        e.returnValue = "您有未保存的更改，确定要离开吗？"
      }
    }

    window.addEventListener("beforeunload", handleBeforeUnload)
    return () => window.removeEventListener("beforeunload", handleBeforeUnload)
  }, [hasUnsavedChanges])

  useEffect(() => {
    const backupKey = `case_${params.id}_backup`
    const backup = localStorage.getItem(backupKey)

    if (backup) {
      try {
        const { caseData: backupData, files: backupFiles, timestamp } = JSON.parse(backup)
        const backupAge = Date.now() - timestamp

        // 如果备份不超过1小时，询问是否恢复
        if (backupAge < 3600000) {
          const shouldRestore = window.confirm(
            "检测到未保存的更改，是否恢复？\n" + `备份时间: ${new Date(timestamp).toLocaleString()}`,
          )

          if (shouldRestore) {
            setEditedData(backupData)
            setCaseFiles(backupFiles || [])
            setHasUnsavedChanges(true)
          } else {
            localStorage.removeItem(backupKey)
          }
        } else {
          localStorage.removeItem(backupKey)
        }
      } catch (error) {
        console.error("[v0] Error restoring backup:", error)
        localStorage.removeItem(backupKey)
      }
    }
  }, [params.id])

  const handleEditToggle = () => {
    if (!isEditMode) {
      setEditedData({ ...caseData })
      setShowEditHelp(true)
      setTimeout(() => setShowEditHelp(false), 3000)
    }
    setIsEditMode(!isEditMode)
  }

  const handleSave = async () => {
    if (!editedData) return

    try {
      setSaveStatus("saving")
      setSaveMessage("正在保存...")

      const response = await fetch(`/api/cases/${params.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          caseData: editedData,
          files: caseFiles,
        }),
      })

      const result = await response.json()

      if (response.ok) {
        setSaveStatus("success")
        setSaveMessage("保存成功！")
        setHasUnsavedChanges(false)
        setIsEditMode(false)

        // 清除本地备份
        localStorage.removeItem(`case_${params.id}_backup`)

        console.log("[v0] Save successful:", result)
      } else {
        throw new Error(result.error || "保存失败")
      }
    } catch (error) {
      setSaveStatus("error")
      setSaveMessage(error instanceof Error ? error.message : "保存失败，请重试")
      console.error("[v0] Save error:", error)
    }

    // 清除状态消息
    setTimeout(() => {
      setSaveStatus("idle")
      setSaveMessage("")
    }, 3000)
  }

  const handleCancel = () => {
    if (hasUnsavedChanges) {
      const shouldDiscard = window.confirm("您有未保存的更改，确定要取消吗？")
      if (!shouldDiscard) return
    }

    setEditedData(null)
    setIsEditMode(false)
    setShowFileUpload(false)
    setHasUnsavedChanges(false)

    // 清除本地备份
    localStorage.removeItem(`case_${params.id}_backup`)
  }

  const handleTextChange = (field: string, value: string) => {
    setEditedData((prev: any) => ({
      ...prev,
      [field]: value,
    }))
    setHasUnsavedChanges(true)
  }

  const handleRichTextChange = (field: string, value: string) => {
    setEditedData((prev: any) => ({
      ...prev,
      [field]: value,
    }))
    setHasUnsavedChanges(true)
  }

  const handleFilesChange = (files: UploadedFile[]) => {
    setCaseFiles(files)
    setHasUnsavedChanges(true)
  }

  const getSaveStatusIcon = () => {
    switch (saveStatus) {
      case "saving":
        return <Loader2 className="w-4 h-4 animate-spin" />
      case "success":
        return <Check className="w-4 h-4" />
      case "error":
        return <AlertCircle className="w-4 h-4" />
      default:
        return <Save className="w-4 h-4" />
    }
  }

  const getSaveStatusColor = () => {
    switch (saveStatus) {
      case "saving":
        return "border-blue-400 text-blue-400 hover:bg-blue-400"
      case "success":
        return "border-green-400 text-green-400 hover:bg-green-400"
      case "error":
        return "border-red-400 text-red-400 hover:bg-red-400"
      default:
        return "border-green-400 text-green-400 hover:bg-green-400"
    }
  }

  return (
    <div className="min-h-screen bg-gray-950 relative">
      {isEditMode && (
        <div className="fixed inset-0 pointer-events-none z-10">
          <div className="absolute inset-0 bg-fuchsia-500/5 backdrop-blur-[0.5px]"></div>
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-fuchsia-500 via-violet-500 to-cyan-500"></div>
        </div>
      )}

      {showEditHelp && isEditMode && (
        <div className="fixed top-20 right-4 z-50 bg-gray-800/95 backdrop-blur-xl border border-fuchsia-400/30 rounded-lg p-4 max-w-sm animate-in slide-in-from-right-5">
          <div className="flex items-start gap-3">
            <HelpCircle className="w-5 h-5 text-fuchsia-400 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-white font-medium mb-2">编辑模式已启用</h4>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>• 点击字段直接编辑</li>
                <li>• Ctrl+S 快速保存</li>
                <li>• Ctrl+P 预览效果</li>
                <li>• ESC 退出编辑</li>
              </ul>
            </div>
            <Button
              size="sm"
              variant="ghost"
              className="text-gray-400 hover:text-white p-1"
              onClick={() => setShowEditHelp(false)}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {showShortcuts && isEditMode && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg border border-gray-600 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white text-lg font-semibold flex items-center gap-2">
                <Keyboard className="w-5 h-5" />
                快捷键
              </h3>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setShowShortcuts(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-300">保存</span>
                <kbd className="bg-gray-700 px-2 py-1 rounded text-gray-200">Ctrl + S</kbd>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">预览</span>
                <kbd className="bg-gray-700 px-2 py-1 rounded text-gray-200">Ctrl + P</kbd>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">退出编辑</span>
                <kbd className="bg-gray-700 px-2 py-1 rounded text-gray-200">ESC</kbd>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">显示快捷键</span>
                <kbd className="bg-gray-700 px-2 py-1 rounded text-gray-200">Ctrl + /</kbd>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ... existing background decorations ... */}

      <nav className="sticky top-0 z-50 bg-gray-950/70 backdrop-blur-xl supports-[backdrop-filter]:bg-gray-950/60 border-b border-gray-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
              {isEditMode && (
                <div className="ml-4 flex items-center gap-2 px-3 py-1 bg-fuchsia-500/20 border border-fuchsia-400/30 rounded-full">
                  <Edit className="w-4 h-4 text-fuchsia-400" />
                  <span className="text-sm text-fuchsia-400 font-medium">编辑模式</span>
                </div>
              )}
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-gray-200 hover:text-white transition-colors">
                首页
              </a>
              <a href="/services" className="text-gray-200 hover:text-white transition-colors">
                核心服务
              </a>
              <a href="/cases" className="text-white font-medium">
                精选案例
              </a>
              <a href="/team" className="text-gray-200 hover:text-white transition-colors">
                专业团队
              </a>
              <a href="/about" className="text-gray-200 hover:text-white transition-colors">
                关于我们
              </a>
              <a href="/contact" className="text-gray-200 hover:text-white transition-colors">
                联系我们
              </a>
            </div>
            <div className="flex items-center gap-3">
              {saveMessage && (
                <div className="flex items-center gap-2 text-sm animate-in fade-in-0 duration-300">
                  {getSaveStatusIcon()}
                  <span
                    className={`${saveStatus === "success" ? "text-green-400" : saveStatus === "error" ? "text-red-400" : "text-blue-400"}`}
                  >
                    {saveMessage}
                  </span>
                </div>
              )}

              {hasUnsavedChanges && saveStatus === "idle" && (
                <div className="flex items-center gap-2 text-sm text-yellow-400 animate-pulse">
                  <AlertCircle className="w-4 h-4" />
                  <span>有未保存的更改</span>
                </div>
              )}

              {isEditMode ? (
                <>
                  <Button
                    onClick={() => setShowPreview(!showPreview)}
                    className="border-2 border-violet-400 text-violet-400 hover:bg-violet-400 hover:text-white bg-transparent transition-all duration-300"
                    size="sm"
                    title="预览效果 (Ctrl+P)"
                  >
                    {showPreview ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>

                  <Button
                    onClick={() => setShowShortcuts(true)}
                    className="border-2 border-gray-500 text-gray-400 hover:bg-gray-500 hover:text-white bg-transparent transition-all duration-300"
                    size="sm"
                    title="快捷键 (Ctrl+/)"
                  >
                    <Keyboard className="w-4 h-4" />
                  </Button>

                  <Button
                    onClick={handleSave}
                    disabled={saveStatus === "saving"}
                    className={`border-2 ${getSaveStatusColor()} hover:text-white bg-transparent transition-all duration-300 ${saveStatus === "saving" ? "animate-pulse" : ""}`}
                    size="sm"
                    title="保存 (Ctrl+S)"
                  >
                    {getSaveStatusIcon()}
                    <span className="ml-2">{saveStatus === "saving" ? "保存中..." : "保存"}</span>
                  </Button>
                  <Button
                    onClick={handleCancel}
                    className="border-2 border-red-400 text-red-400 hover:bg-red-400 hover:text-white bg-transparent transition-all duration-300"
                    size="sm"
                    title="取消 (ESC)"
                  >
                    <X className="w-4 h-4 mr-2" />
                    取消
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    onClick={handleEditToggle}
                    className="border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-gray-900 bg-transparent transition-all duration-300"
                    size="sm"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    编辑
                  </Button>
                  <Button className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300">
                    免费咨询
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* 案例头部 */}
      <section className="relative py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center gap-4 mb-6">
                <Badge className={`${currentData.categoryColor} text-white px-4 py-2`}>{currentData.category}</Badge>
                <Badge variant="outline" className="border-gray-600 text-gray-300 px-4 py-2">
                  {currentData.year}
                </Badge>
              </div>
              {isEditMode ? (
                <div className="relative group">
                  <input
                    type="text"
                    value={currentData.title}
                    onChange={(e) => handleTextChange("title", e.target.value)}
                    onFocus={() => setEditingField("title")}
                    onBlur={() => setEditingField(null)}
                    className={`text-4xl md:text-5xl font-bold text-white mb-6 font-serif leading-tight bg-transparent border-2 rounded-lg p-3 w-full focus:outline-none transition-all duration-300 ${
                      editingField === "title"
                        ? "border-fuchsia-400 bg-fuchsia-500/10 shadow-lg shadow-fuchsia-500/20"
                        : "border-gray-600 hover:border-gray-500"
                    }`}
                    placeholder="输入案例标题..."
                  />
                  {editingField === "title" && (
                    <div className="absolute -top-8 left-0 text-xs text-fuchsia-400 animate-in fade-in-0 duration-200">
                      正在编辑标题
                    </div>
                  )}
                </div>
              ) : (
                <h1
                  className={`text-4xl md:text-5xl font-bold text-white mb-6 font-serif leading-tight transition-all duration-300 ${
                    showPreview ? "opacity-50" : ""
                  }`}
                >
                  {currentData.title}
                </h1>
              )}

              {isEditMode ? (
                <div className="relative group">
                  <RichTextEditor
                    value={currentData.fullDescription}
                    onChange={(value) => handleRichTextChange("fullDescription", value)}
                    placeholder="请输入项目详细描述..."
                    className={`mb-8 transition-all duration-300 ${
                      editingField === "description" ? "ring-2 ring-fuchsia-400 ring-opacity-50" : ""
                    }`}
                  />
                </div>
              ) : (
                <div
                  className={`text-xl text-gray-300 mb-8 leading-relaxed transition-all duration-300 ${
                    showPreview ? "opacity-50" : ""
                  }`}
                  dangerouslySetInnerHTML={{ __html: currentData.fullDescription }}
                />
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div
                  className={`flex items-center text-gray-300 p-4 bg-gray-900/30 rounded-lg border border-gray-800/50 transition-all duration-300 ${
                    isEditMode ? "hover:border-fuchsia-400/30 hover:bg-fuchsia-500/5" : ""
                  }`}
                >
                  <Clock className="w-5 h-5 mr-3 text-fuchsia-400" />
                  <div>
                    <div className="text-sm text-gray-400">项目周期</div>
                    {isEditMode ? (
                      <input
                        type="text"
                        value={currentData.duration}
                        onChange={(e) => handleTextChange("duration", e.target.value)}
                        onFocus={() => setEditingField("duration")}
                        onBlur={() => setEditingField(null)}
                        className={`font-semibold bg-transparent border rounded px-2 py-1 text-sm focus:outline-none transition-all duration-300 ${
                          editingField === "duration"
                            ? "border-fuchsia-400 bg-fuchsia-500/10"
                            : "border-gray-600 hover:border-gray-500"
                        }`}
                        placeholder="项目周期"
                      />
                    ) : (
                      <div className="font-semibold">{currentData.duration}</div>
                    )}
                  </div>
                </div>
                <div
                  className={`flex items-center text-gray-300 p-4 bg-gray-900/30 rounded-lg border border-gray-800/50 transition-all duration-300 ${
                    isEditMode ? "hover:border-fuchsia-400/30 hover:bg-fuchsia-500/5" : ""
                  }`}
                >
                  <Users className="w-5 h-5 mr-3 text-violet-400" />
                  <div>
                    <div className="text-sm text-gray-400">客户</div>
                    {isEditMode ? (
                      <input
                        type="text"
                        value={currentData.client}
                        onChange={(e) => handleTextChange("client", e.target.value)}
                        onFocus={() => setEditingField("client")}
                        onBlur={() => setEditingField(null)}
                        className={`font-semibold bg-transparent border rounded px-2 py-1 text-sm focus:outline-none transition-all duration-300 ${
                          editingField === "client"
                            ? "border-fuchsia-400 bg-fuchsia-500/10"
                            : "border-gray-600 hover:border-gray-500"
                        }`}
                        placeholder="客户名称"
                      />
                    ) : (
                      <div className="font-semibold">{currentData.client}</div>
                    )}
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div
                className={`aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl relative group transition-all duration-300 ${
                  isEditMode ? "ring-2 ring-fuchsia-400/20 hover:ring-fuchsia-400/40" : ""
                }`}
              >
                <img
                  src={currentData.image || "/placeholder.svg"}
                  alt={currentData.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                {isEditMode && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-300 cursor-pointer">
                    <div className="text-white text-center">
                      <Edit className="w-8 h-8 mx-auto mb-2" />
                      <p className="text-sm">点击上传图片</p>
                    </div>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              {/* ... existing decorative elements ... */}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950/30 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <Card className="bg-gray-900/30 border-gray-800/50 p-8">
              <div className="flex items-center mb-6">
                <Target className="w-6 h-6 text-red-400 mr-3" />
                <h3 className="text-2xl font-bold text-white font-serif">项目挑战</h3>
              </div>
              {isEditMode ? (
                <RichTextEditor
                  value={currentData.challenge || ""}
                  onChange={(value) => handleRichTextChange("challenge", value)}
                  placeholder="描述项目面临的主要挑战..."
                />
              ) : (
                <p className="text-gray-300 leading-relaxed">{currentData.challenge || "暂无挑战描述"}</p>
              )}
            </Card>

            <Card className="bg-gray-900/30 border-gray-800/50 p-8">
              <div className="flex items-center mb-6">
                <Lightbulb className="w-6 h-6 text-yellow-400 mr-3" />
                <h3 className="text-2xl font-bold text-white font-serif">解决方案</h3>
              </div>
              {isEditMode ? (
                <RichTextEditor
                  value={currentData.solution || ""}
                  onChange={(value) => handleRichTextChange("solution", value)}
                  placeholder="描述项目的解决方案..."
                />
              ) : (
                <p className="text-gray-300 leading-relaxed">{currentData.solution || "暂无解决方案描述"}</p>
              )}
            </Card>
          </div>
        </div>
      </section>

      {isEditMode && (
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl md:text-4xl font-bold text-white font-serif">案例文件</h2>
              <Button
                onClick={() => setShowFileUpload(!showFileUpload)}
                className={`border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300 ${
                  showFileUpload ? "bg-fuchsia-400/10" : ""
                }`}
              >
                <Plus className="w-4 h-4 mr-2" />
                {showFileUpload ? "隐藏上传" : "添加文件"}
              </Button>
            </div>

            {showFileUpload && (
              <div className="mb-8 animate-in slide-in-from-top-5 duration-300">
                <FileUpload
                  onFilesChange={handleFilesChange}
                  existingFiles={caseFiles}
                  maxFiles={20}
                  maxSize={100}
                  acceptedTypes={["image/*", "video/*", ".pdf", ".doc", ".docx", ".ppt", ".pptx", ".zip", ".rar"]}
                />
              </div>
            )}

            {caseFiles.length > 0 && !showFileUpload && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {caseFiles.map((file, index) => (
                  <Card
                    key={file.id}
                    className="bg-gray-900/30 border-gray-800/50 hover:border-fuchsia-400/30 transition-all duration-300 animate-in fade-in-0 duration-300"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <CardContent className="p-6">
                      <div className="aspect-video bg-gray-800 rounded-lg mb-4 flex items-center justify-center overflow-hidden">
                        {file.preview ? (
                          <img
                            src={file.preview || "/placeholder.svg"}
                            alt={file.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="text-gray-400">
                            {file.type.startsWith("video/") ? (
                              <video src={file.url} className="w-full h-full object-cover" controls />
                            ) : (
                              <div className="text-center">
                                <CheckCircle className="w-12 h-12 mx-auto mb-2" />
                                <p className="text-sm">{file.type.split("/")[1]?.toUpperCase() || "文件"}</p>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                      <h4 className="text-white font-medium truncate mb-2">{file.name}</h4>
                      <p className="text-sm text-gray-400">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </section>
      )}

      {/* ... existing sections with enhanced editing experience ... */}
    </div>
  )
}
