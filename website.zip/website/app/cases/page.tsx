"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import casesData from "@/data/casesData"

export default function CasesPage() {
  const cases = casesData

  const categories = [
    "全部",
    "时尚品牌",
    "科技创新",
    "餐饮服务",
    "教育培训",
    "金融服务",
    "电商平台",
    "医疗健康",
    "文化娱乐",
    "汽车行业",
    "体育运动",
    "美妆护肤",
    "酒店旅游",
  ]

  return (
    <div className="min-h-screen bg-gray-950 relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-500/8 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-cyan-500/6 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-fuchsia-500/4 rounded-full blur-3xl"></div>
      </div>

      <nav className="sticky top-0 z-50 bg-gray-950/70 backdrop-blur-xl supports-[backdrop-filter]:bg-gray-950/60 border-b border-gray-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-gray-200 hover:text-white transition-colors">
                首页
              </a>
              <a href="/services" className="text-gray-200 hover:text-white transition-colors">
                核心服务
              </a>
              <a href="/cases" className="text-white font-medium">
                精选案例
              </a>
              <a href="/team" className="text-gray-200 hover:text-white transition-colors">
                专业团队
              </a>
              <a href="/about" className="text-gray-200 hover:text-white transition-colors">
                关于我们
              </a>
              <a href="/contact" className="text-gray-200 hover:text-white transition-colors">
                联系我们
              </a>
            </div>
            <Button className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300">
              免费咨询
            </Button>
          </div>
        </div>
      </nav>

      <section className="relative bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 py-20 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <div className="text-sm text-violet-300 mb-4 tracking-wider uppercase">Success Stories</div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 font-serif">
              <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">
                精选案例
              </span>
            </h1>
            <p className="text-xl text-gray-200 mb-12 max-w-3xl mx-auto leading-relaxed">
              每一个成功案例都是我们专业实力的体现，见证品牌从构想到成功的完整历程
            </p>
          </div>
        </div>
      </section>

      <section className="py-8 bg-gray-950/50 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category, index) => (
              <Button
                key={category}
                variant="outline"
                size="sm"
                className={`border-gray-600 text-gray-300 hover:bg-fuchsia-400 hover:text-white hover:border-fuchsia-400 transition-all duration-300 ${
                  index === 0 ? "bg-fuchsia-400 text-white border-fuchsia-400" : "bg-transparent"
                }`}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {cases.map((caseItem) => (
              <Card
                key={caseItem.id}
                className="group hover:shadow-xl transition-all duration-300 border-gray-800/50 overflow-hidden bg-gray-900/30"
              >
                <div className="relative h-64 overflow-hidden">
                  <div
                    className="absolute inset-0 bg-cover bg-center group-hover:scale-105 transition-transform duration-300"
                    style={{ backgroundImage: `url(${caseItem.image})` }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <div className="absolute top-4 left-4">
                    <Badge className={`${caseItem.categoryColor} text-white hover:opacity-90`}>
                      {caseItem.category}
                    </Badge>
                  </div>
                  <div className="absolute top-4 right-4">
                    <Badge variant="outline" className="border-white/30 text-white bg-black/20 backdrop-blur-sm">
                      {caseItem.year}
                    </Badge>
                  </div>
                </div>

                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-white mb-3 font-serif group-hover:text-fuchsia-400 transition-colors">
                    {caseItem.title}
                  </h3>
                  <p className="text-gray-300 mb-4 leading-relaxed text-sm">{caseItem.description}</p>

                  <div className="mb-4">
                    <h4 className="text-sm font-semibold text-white mb-2">服务内容</h4>
                    <div className="flex flex-wrap gap-1">
                      {caseItem.services.slice(0, 3).map((service, idx) => (
                        <Badge key={idx} variant="outline" className="border-gray-600 text-gray-300 text-xs">
                          {service}
                        </Badge>
                      ))}
                      {caseItem.services.length > 3 && (
                        <Badge variant="outline" className="border-gray-600 text-gray-300 text-xs">
                          +{caseItem.services.length - 3}
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="mb-4">
                    <h4 className="text-sm font-semibold text-white mb-2">项目成果</h4>
                    <ul className="text-xs text-gray-400 space-y-1">
                      {caseItem.results.slice(0, 2).map((result, idx) => (
                        <li key={idx} className="flex items-center">
                          <div className="w-1 h-1 bg-fuchsia-400 rounded-full mr-2"></div>
                          {result}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">项目周期: {caseItem.duration}</span>
                    <Button
                      variant="ghost"
                      className="text-fuchsia-400 hover:text-fuchsia-300 hover:bg-fuchsia-400/10 p-0 text-sm"
                      onClick={() => (window.location.href = `/cases/${caseItem.id}`)}
                    >
                      查看详情 →
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950/50 relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 font-serif">让我们一起创造下一个成功案例</h2>
          <p className="text-xl text-gray-300 mb-8">无论您的项目规模大小，我们都将为您提供专业的品牌解决方案</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300 px-8 py-4 text-lg"
              onClick={() => (window.location.href = "/contact")}
            >
              开始合作
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-violet-400 text-violet-400 hover:bg-violet-400 hover:text-white px-8 py-4 text-lg bg-transparent transition-all duration-300"
              onClick={() => (window.location.href = "/services")}
            >
              了解服务
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
