"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { MediaUpload } from "@/components/media-upload"

export default function AboutDetailsPage() {
  const [isEditing, setIsEditing] = useState(false)
  const [content, setContent] = useState({
    title: "关于我们的故事",
    subtitle: "Our Story",
    description: "深入了解我们的发展历程、企业文化和核心价值观",
    sections: [
      {
        id: "history",
        title: "发展历程",
        content:
          "自2015年成立以来，我们始终专注于为客户提供最优质的创意服务。从最初的3人小团队，发展到如今拥有50+专业人才的创意机构，我们见证了无数品牌的成长与蜕变。",
        image: "/company-development-timeline.png",
      },
      {
        id: "culture",
        title: "企业文化",
        content:
          "我们相信创意的力量能够改变世界。在这里，每一个想法都被尊重，每一份创意都被珍视。我们倡导开放、包容、创新的工作氛围，让每位团队成员都能发挥最大的潜能。",
        image: "/creative-team-workspace.png",
      },
      {
        id: "values",
        title: "核心价值观",
        content:
          "诚信为本、创新驱动、客户至上、团队协作。这不仅是我们的价值观，更是我们每天工作的指导原则。我们始终坚持以客户需求为导向，用专业的服务和创新的思维为客户创造价值。",
        image: "/core-values-presentation.png",
      },
    ],
  })

  const handleSave = () => {
    // 这里可以添加保存到后端的逻辑
    console.log("[v0] 保存内容:", content)
    setIsEditing(false)
  }

  return (
    <div className="min-h-screen bg-gray-950 relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-500/8 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-cyan-500/6 rounded-full blur-3xl"></div>
      </div>

      <nav className="sticky top-0 z-50 bg-gray-950/70 backdrop-blur-xl supports-[backdrop-filter]:bg-gray-950/60 border-b border-gray-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-gray-200 hover:text-white transition-colors">
                首页
              </a>
              <a href="/services" className="text-gray-200 hover:text-white transition-colors">
                核心服务
              </a>
              <a href="/cases" className="text-gray-200 hover:text-white transition-colors">
                精选案例
              </a>
              <a href="/team" className="text-gray-200 hover:text-white transition-colors">
                专业团队
              </a>
              <a href="/about" className="text-white font-medium">
                关于我们
              </a>
              <a href="/contact" className="text-gray-200 hover:text-white transition-colors">
                联系我们
              </a>
            </div>
            <div className="flex items-center space-x-4">
              {isEditing ? (
                <>
                  <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700">
                    保存
                  </Button>
                  <Button onClick={() => setIsEditing(false)} variant="outline">
                    取消
                  </Button>
                </>
              ) : (
                <Button
                  onClick={() => setIsEditing(true)}
                  className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent"
                >
                  编辑内容
                </Button>
              )}
            </div>
          </div>
        </div>
      </nav>

      <section className="relative bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 py-20 overflow-hidden">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            {isEditing ? (
              <div className="space-y-4">
                <Input
                  value={content.subtitle}
                  onChange={(e) => setContent({ ...content, subtitle: e.target.value })}
                  className="text-center bg-gray-800 border-gray-700"
                  placeholder="副标题"
                />
                <Input
                  value={content.title}
                  onChange={(e) => setContent({ ...content, title: e.target.value })}
                  className="text-center text-2xl bg-gray-800 border-gray-700"
                  placeholder="主标题"
                />
                <Textarea
                  value={content.description}
                  onChange={(e) => setContent({ ...content, description: e.target.value })}
                  className="text-center bg-gray-800 border-gray-700"
                  placeholder="描述"
                />
              </div>
            ) : (
              <>
                <div className="text-sm text-violet-300 mb-4 tracking-wider uppercase">{content.subtitle}</div>
                <h1 className="text-4xl md:text-6xl font-bold mb-6 font-serif">
                  <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">
                    {content.title}
                  </span>
                </h1>
                <p className="text-xl text-gray-200 mb-12 max-w-3xl mx-auto leading-relaxed">{content.description}</p>
              </>
            )}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950/50 relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-12">
            {content.sections.map((section, index) => (
              <Card key={section.id} className="border-gray-800/50 bg-gray-900/30 overflow-hidden">
                <CardContent className="p-8">
                  {isEditing ? (
                    <div className="space-y-6">
                      <Input
                        value={section.title}
                        onChange={(e) => {
                          const newSections = [...content.sections]
                          newSections[index].title = e.target.value
                          setContent({ ...content, sections: newSections })
                        }}
                        className="text-xl font-bold bg-gray-800 border-gray-700"
                        placeholder="标题"
                      />
                      <Textarea
                        value={section.content}
                        onChange={(e) => {
                          const newSections = [...content.sections]
                          newSections[index].content = e.target.value
                          setContent({ ...content, sections: newSections })
                        }}
                        className="min-h-32 bg-gray-800 border-gray-700"
                        placeholder="内容"
                      />
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">图片</label>
                        <MediaUpload
                          onUpload={(files) => {
                            if (files.length > 0) {
                              const newSections = [...content.sections]
                              newSections[index].image = files[0].url
                              setContent({ ...content, sections: newSections })
                            }
                          }}
                          accept="image/*"
                          maxFiles={1}
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                      <div className={index % 2 === 0 ? "order-1" : "order-2"}>
                        <h3 className="text-2xl font-bold text-white mb-4 font-serif">{section.title}</h3>
                        <p className="text-gray-300 leading-relaxed">{section.content}</p>
                      </div>
                      <div className={index % 2 === 0 ? "order-2" : "order-1"}>
                        <div
                          className="h-64 bg-cover bg-center rounded-lg"
                          style={{ backgroundImage: `url(${section.image})` }}
                        />
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950 relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 font-serif">想要了解更多？</h2>
          <p className="text-xl text-gray-300 mb-8">欢迎联系我们，让我们为您介绍更多关于我们的故事</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/contact"
              className="inline-flex items-center justify-center px-8 py-4 text-lg border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300 rounded-md font-medium"
            >
              联系我们
            </a>
            <a
              href="/team"
              className="inline-flex items-center justify-center px-8 py-4 text-lg border-2 border-violet-400 text-violet-400 hover:bg-violet-400 hover:text-white bg-transparent transition-all duration-300 rounded-md font-medium"
            >
              认识团队
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
