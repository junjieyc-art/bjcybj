"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function AboutPage() {
  const milestones = [
    {
      year: "2016",
      title: "公司成立",
      description: "创意传媒正式成立，专注于为中小企业提供品牌设计服务",
      icon: "🚀",
    },
    {
      year: "2018",
      title: "业务拓展",
      description: "扩展服务范围，增加数字营销和活动策划业务",
      icon: "📈",
    },
    {
      year: "2020",
      title: "团队壮大",
      description: "团队规模扩大至30人，服务客户超过100家",
      icon: "👥",
    },
    {
      year: "2022",
      title: "技术升级",
      description: "引入AI技术和数据分析，提升服务效率和质量",
      icon: "🤖",
    },
    {
      year: "2024",
      title: "行业领先",
      description: "成为行业知名品牌，累计服务客户超过500家",
      icon: "🏆",
    },
  ]

  const values = [
    {
      title: "创新驱动",
      description: "我们始终保持对新技术、新趋势的敏感度，用创新思维解决客户问题",
      icon: "💡",
      color: "from-violet-400 to-violet-600",
    },
    {
      title: "客户至上",
      description: "客户的成功就是我们的成功，我们致力于为每一位客户创造最大价值",
      icon: "🎯",
      color: "from-fuchsia-400 to-fuchsia-600",
    },
    {
      title: "品质保证",
      description: "我们对每一个项目都精益求精，确保交付的作品达到最高标准",
      icon: "⭐",
      color: "from-cyan-400 to-cyan-600",
    },
    {
      title: "团队协作",
      description: "我们相信团队的力量，通过协作创造出超越个人能力的优秀作品",
      icon: "🤝",
      color: "from-emerald-400 to-emerald-600",
    },
  ]

  const advantages = [
    {
      title: "专业团队",
      description: "汇聚行业顶尖人才，平均从业经验10年以上",
      number: "30+",
      label: "专业人员",
    },
    {
      title: "丰富经验",
      description: "8年行业深耕，累计服务500+企业客户",
      number: "500+",
      label: "服务客户",
    },
    {
      title: "成功案例",
      description: "200+成功案例，涵盖各行各业",
      number: "200+",
      label: "成功案例",
    },
    {
      title: "客户满意",
      description: "98%的客户满意度，85%的客户选择续约合作",
      number: "98%",
      label: "满意度",
    },
  ]

  const partners = [
    { name: "华为", logo: "/abstract-petal-design.png" },
    { name: "腾讯", logo: "/tencent-logo.png" },
    { name: "阿里巴巴", logo: "/alibaba-logo.png" },
    { name: "百度", logo: "/baidu-logo.png" },
    { name: "京东", logo: "/generic-initials-logo.png" },
    { name: "小米", logo: "/xiaomi-logo.png" },
    { name: "字节跳动", logo: "/bytedance-logo.png" },
    { name: "美团", logo: "/meituan-logo.png" },
  ]

  return (
    <div className="min-h-screen bg-gray-950 relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-500/8 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-cyan-500/6 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-fuchsia-500/4 rounded-full blur-3xl"></div>
      </div>

      <nav className="sticky top-0 z-50 bg-gray-950/70 backdrop-blur-xl supports-[backdrop-filter]:bg-gray-950/60 border-b border-gray-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-gray-200 hover:text-white transition-colors">
                首页
              </a>
              <a href="/services" className="text-gray-200 hover:text-white transition-colors">
                核心服务
              </a>
              <a href="/cases" className="text-gray-200 hover:text-white transition-colors">
                精选案例
              </a>
              <a href="/team" className="text-gray-200 hover:text-white transition-colors">
                专业团队
              </a>
              <a href="/about" className="text-white font-medium">
                关于我们
              </a>
              <a href="/contact" className="text-gray-200 hover:text-white transition-colors">
                联系我们
              </a>
            </div>
            <Button className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300">
              免费咨询
            </Button>
          </div>
        </div>
      </nav>

      <section className="relative bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 py-20 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <div className="text-sm text-violet-300 mb-4 tracking-wider uppercase">About Us</div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 font-serif">
              <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">
                关于我们
              </span>
            </h1>
            <p className="text-xl text-gray-200 mb-12 max-w-3xl mx-auto leading-relaxed">
              专业的品牌全案广告传媒公司，8年来专注于为企业提供创意策略、品牌设计、数字营销等全方位服务
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950/50 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 font-serif">我们的故事</h2>
              <div className="space-y-6 text-gray-300 leading-relaxed">
                <p>
                  创意传媒成立于2016年，是一家专注于品牌全案服务的广告传媒公司。我们从一个小团队开始，凭借对创意的执着追求和对客户需求的深度理解，逐步发展成为行业内备受认可的专业机构。
                </p>
                <p>
                  8年来，我们始终坚持"创意无界，品牌有力"的理念，为超过500家企业提供了专业的品牌服务。从初创企业到大型集团，从传统行业到新兴科技，我们的足迹遍布各个领域。
                </p>
                <p>
                  我们相信，每一个品牌都有其独特的故事和价值。我们的使命就是通过专业的创意和策略，帮助品牌找到属于自己的声音，在市场中脱颖而出。
                </p>
              </div>
              <div className="mt-8">
                <Button
                  size="lg"
                  className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300"
                  onClick={() => (window.location.href = "/about/details")}
                >
                  了解更多
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square bg-gradient-to-br from-violet-500/20 via-fuchsia-500/20 to-cyan-500/20 rounded-2xl p-8 backdrop-blur-sm border border-gray-800/50">
                <div className="h-full bg-gray-900/50 rounded-xl flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-6xl mb-4">🎨</div>
                    <h3 className="text-2xl font-bold text-white mb-2">创意无界</h3>
                    <p className="text-gray-300">用创意连接品牌与用户</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">发展历程</h2>
            <p className="text-lg text-gray-300">见证我们的成长足迹</p>
          </div>

          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-gradient-to-b from-violet-400 via-fuchsia-400 to-cyan-400"></div>
            <div className="space-y-12">
              {milestones.map((milestone, index) => (
                <div
                  key={milestone.year}
                  className={`flex items-center ${index % 2 === 0 ? "flex-row" : "flex-row-reverse"}`}
                >
                  <div className={`w-1/2 ${index % 2 === 0 ? "pr-8 text-right" : "pl-8 text-left"}`}>
                    <Card className="bg-gray-900/30 border-gray-800/50 hover:bg-gray-900/50 transition-all duration-300">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-3">
                          <Badge className="bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-500/30">
                            {milestone.year}
                          </Badge>
                          <div className="text-2xl">{milestone.icon}</div>
                        </div>
                        <h3 className="text-xl font-bold text-white mb-2">{milestone.title}</h3>
                        <p className="text-gray-300 text-sm leading-relaxed">{milestone.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                  <div className="relative z-10">
                    <div className="w-4 h-4 bg-fuchsia-400 rounded-full border-4 border-gray-950"></div>
                  </div>
                  <div className="w-1/2"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">企业文化</h2>
            <p className="text-lg text-gray-300">我们的核心价值观</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card
                key={index}
                className="group hover:shadow-xl transition-all duration-300 border-gray-800/50 overflow-hidden bg-gray-900/30"
              >
                <CardContent className="p-8 text-center">
                  <div
                    className={`w-16 h-16 bg-gradient-to-br ${value.color} rounded-full mx-auto mb-6 flex items-center justify-center text-2xl`}
                  >
                    {value.icon}
                  </div>
                  <h3 className="text-xl font-bold text-white mb-4">{value.title}</h3>
                  <p className="text-gray-300 leading-relaxed text-sm">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">我们的优势</h2>
            <p className="text-lg text-gray-300">数据说话，实力见证</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {advantages.map((advantage, index) => (
              <div key={index} className="text-center">
                <div className="bg-gray-900/30 border border-gray-800/50 rounded-2xl p-8 hover:bg-gray-900/50 transition-all duration-300">
                  <div className="text-4xl md:text-5xl font-bold text-fuchsia-400 mb-2">{advantage.number}</div>
                  <div className="text-sm text-gray-400 mb-4">{advantage.label}</div>
                  <h3 className="text-xl font-bold text-white mb-3">{advantage.title}</h3>
                  <p className="text-gray-300 text-sm leading-relaxed">{advantage.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950/50 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">合作伙伴</h2>
            <p className="text-lg text-gray-300">与行业领先企业携手共进</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-8">
            {partners.map((partner, index) => (
              <div
                key={index}
                className="bg-gray-900/30 border border-gray-800/50 rounded-xl p-4 hover:bg-gray-900/50 transition-all duration-300 flex items-center justify-center"
              >
                <img
                  src={partner.logo || "/placeholder.svg"}
                  alt={partner.name}
                  className="max-w-full max-h-12 object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 font-serif">我们的使命</h2>
              <div className="space-y-6 text-gray-300 leading-relaxed">
                <p className="text-xl">
                  <span className="text-fuchsia-400 font-semibold">使命：</span>
                  通过创意和策略，帮助每一个品牌找到属于自己的声音，在市场中脱颖而出。
                </p>
                <p className="text-xl">
                  <span className="text-violet-400 font-semibold">愿景：</span>
                  成为中国最具影响力的品牌全案服务机构，引领行业发展方向。
                </p>
                <p className="text-xl">
                  <span className="text-cyan-400 font-semibold">价值观：</span>
                  创新驱动、客户至上、品质保证、团队协作。
                </p>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-video bg-gradient-to-br from-violet-500/20 via-fuchsia-500/20 to-cyan-500/20 rounded-2xl p-8 backdrop-blur-sm border border-gray-800/50">
                <div className="h-full bg-gray-900/50 rounded-xl flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-6xl mb-4">🎯</div>
                    <h3 className="text-2xl font-bold text-white mb-2">品牌有力</h3>
                    <p className="text-gray-300">让每个品牌都有自己的力量</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950/50 relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 font-serif">准备开始合作？</h2>
          <p className="text-xl text-gray-300 mb-8">让我们一起创造属于您品牌的精彩故事</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300 px-8 py-4 text-lg"
              onClick={() => (window.location.href = "/contact")}
            >
              开始合作
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-violet-400 text-violet-400 hover:bg-violet-400 hover:text-white px-8 py-4 text-lg bg-transparent transition-all duration-300"
              onClick={() => (window.location.href = "/contact")}
            >
              联系我们
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
