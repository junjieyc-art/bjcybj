"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Settings, Save, ArrowLeft, Globe, Palette, Database, Shield, Image, Check, AlertCircle } from "lucide-react"

export default function AdminSettingsPage() {
  const [activeTab, setActiveTab] = useState("general")
  const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "success" | "error">("idle")
  const [settings, setSettings] = useState({
    // 基本设置
    siteName: "创意传媒",
    siteDescription: "专业的品牌全案广告传媒公司",
    contactEmail: "info@company.com",
    contactPhone: "400-888-9999",
    address: "北京市朝阳区创意园区",

    // 媒体设置
    maxFileSize: 100,
    allowedFileTypes: ["image/*", "video/*", "audio/*", ".pdf", ".doc", ".docx"],
    imageQuality: 85,
    enableCompression: true,

    // 系统设置
    enableNotifications: true,
    autoSave: true,
    backupFrequency: "daily",

    // 主题设置
    primaryColor: "#e879f9",
    secondaryColor: "#06b6d4",
    darkMode: true,
  })

  const tabs = [
    { id: "general", name: "基本设置", icon: Globe },
    { id: "media", name: "媒体设置", icon: Image },
    { id: "system", name: "系统设置", icon: Database },
    { id: "theme", name: "主题设置", icon: Palette },
    { id: "security", name: "安全设置", icon: Shield },
  ]

  const handleSave = async () => {
    setSaveStatus("saving")

    // 模拟保存
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setSaveStatus("success")
    setTimeout(() => setSaveStatus("idle"), 3000)
  }

  const handleInputChange = (field: string, value: any) => {
    setSettings((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const getSaveStatusIcon = () => {
    switch (saveStatus) {
      case "saving":
        return <Settings className="w-4 h-4 animate-spin" />
      case "success":
        return <Check className="w-4 h-4" />
      case "error":
        return <AlertCircle className="w-4 h-4" />
      default:
        return <Save className="w-4 h-4" />
    }
  }

  const getSaveStatusColor = () => {
    switch (saveStatus) {
      case "saving":
        return "border-blue-400 text-blue-400 hover:bg-blue-400"
      case "success":
        return "border-green-400 text-green-400 hover:bg-green-400"
      case "error":
        return "border-red-400 text-red-400 hover:bg-red-400"
      default:
        return "border-green-400 text-green-400 hover:bg-green-400"
    }
  }

  return (
    <div className="min-h-screen bg-gray-950 relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-orange-500/5 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-purple-500/4 rounded-full blur-3xl"></div>
      </div>

      <nav className="sticky top-0 z-50 bg-gray-950/90 backdrop-blur-xl border-b border-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-6">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
              <div className="flex items-center gap-2 px-3 py-1 bg-orange-500/20 border border-orange-400/30 rounded-full">
                <Settings className="w-4 h-4 text-orange-400" />
                <span className="text-sm text-orange-400 font-medium">系统设置</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Button
                onClick={handleSave}
                disabled={saveStatus === "saving"}
                className={`border-2 ${getSaveStatusColor()} hover:text-white bg-transparent transition-all duration-300`}
              >
                {getSaveStatusIcon()}
                <span className="ml-2">{saveStatus === "saving" ? "保存中..." : "保存设置"}</span>
              </Button>
              <Button
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
                onClick={() => (window.location.href = "/admin")}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                返回仪表板
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">系统设置</h1>
          <p className="text-gray-400">管理网站配置和系统参数</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* 设置导航 */}
          <div className="lg:col-span-1">
            <Card className="bg-gray-900/30 border-gray-800/50">
              <CardContent className="p-4">
                <nav className="space-y-2">
                  {tabs.map((tab) => {
                    const Icon = tab.icon
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-all duration-300 ${
                          activeTab === tab.id
                            ? "bg-fuchsia-500/20 text-fuchsia-400 border border-fuchsia-400/30"
                            : "text-gray-300 hover:bg-gray-800/50 hover:text-white"
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        <span className="text-sm font-medium">{tab.name}</span>
                      </button>
                    )
                  })}
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* 设置内容 */}
          <div className="lg:col-span-3">
            {activeTab === "general" && (
              <Card className="bg-gray-900/30 border-gray-800/50">
                <CardHeader>
                  <CardTitle className="text-white font-serif flex items-center gap-2">
                    <Globe className="w-5 h-5" />
                    基本设置
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">网站名称</label>
                      <Input
                        value={settings.siteName}
                        onChange={(e) => handleInputChange("siteName", e.target.value)}
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">联系邮箱</label>
                      <Input
                        value={settings.contactEmail}
                        onChange={(e) => handleInputChange("contactEmail", e.target.value)}
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">网站描述</label>
                    <textarea
                      value={settings.siteDescription}
                      onChange={(e) => handleInputChange("siteDescription", e.target.value)}
                      rows={3}
                      className="w-full px-3 py-2 bg-gray-800/50 border border-gray-700 rounded-md text-white focus:border-fuchsia-400 focus:outline-none resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">联系电话</label>
                      <Input
                        value={settings.contactPhone}
                        onChange={(e) => handleInputChange("contactPhone", e.target.value)}
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">公司地址</label>
                      <Input
                        value={settings.address}
                        onChange={(e) => handleInputChange("address", e.target.value)}
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === "media" && (
              <Card className="bg-gray-900/30 border-gray-800/50">
                <CardHeader>
                  <CardTitle className="text-white font-serif flex items-center gap-2">
                    <Image className="w-5 h-5" />
                    媒体设置
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">最大文件大小 (MB)</label>
                      <Input
                        type="number"
                        value={settings.maxFileSize}
                        onChange={(e) => handleInputChange("maxFileSize", Number.parseInt(e.target.value))}
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">图片质量 (%)</label>
                      <Input
                        type="number"
                        min="1"
                        max="100"
                        value={settings.imageQuality}
                        onChange={(e) => handleInputChange("imageQuality", Number.parseInt(e.target.value))}
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-3">允许的文件类型</label>
                    <div className="flex flex-wrap gap-2">
                      {settings.allowedFileTypes.map((type, index) => (
                        <Badge key={index} variant="outline" className="border-gray-600 text-gray-300">
                          {type}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-gray-800/30 rounded-lg border border-gray-700">
                    <div>
                      <h4 className="text-white font-medium">启用图片压缩</h4>
                      <p className="text-gray-400 text-sm">自动压缩上传的图片以节省存储空间</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.enableCompression}
                      onChange={(e) => handleInputChange("enableCompression", e.target.checked)}
                      className="w-4 h-4 text-fuchsia-400 bg-gray-800 border-gray-600 rounded focus:ring-fuchsia-400"
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === "system" && (
              <Card className="bg-gray-900/30 border-gray-800/50">
                <CardHeader>
                  <CardTitle className="text-white font-serif flex items-center gap-2">
                    <Database className="w-5 h-5" />
                    系统设置
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-800/30 rounded-lg border border-gray-700">
                      <div>
                        <h4 className="text-white font-medium">启用通知</h4>
                        <p className="text-gray-400 text-sm">接收系统通知和更新提醒</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={settings.enableNotifications}
                        onChange={(e) => handleInputChange("enableNotifications", e.target.checked)}
                        className="w-4 h-4 text-fuchsia-400 bg-gray-800 border-gray-600 rounded focus:ring-fuchsia-400"
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-800/30 rounded-lg border border-gray-700">
                      <div>
                        <h4 className="text-white font-medium">自动保存</h4>
                        <p className="text-gray-400 text-sm">编辑时自动保存内容</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={settings.autoSave}
                        onChange={(e) => handleInputChange("autoSave", e.target.checked)}
                        className="w-4 h-4 text-fuchsia-400 bg-gray-800 border-gray-600 rounded focus:ring-fuchsia-400"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">备份频率</label>
                    <select
                      value={settings.backupFrequency}
                      onChange={(e) => handleInputChange("backupFrequency", e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800/50 border border-gray-700 rounded-md text-white focus:border-fuchsia-400 focus:outline-none"
                    >
                      <option value="hourly">每小时</option>
                      <option value="daily">每天</option>
                      <option value="weekly">每周</option>
                      <option value="monthly">每月</option>
                    </select>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === "theme" && (
              <Card className="bg-gray-900/30 border-gray-800/50">
                <CardHeader>
                  <CardTitle className="text-white font-serif flex items-center gap-2">
                    <Palette className="w-5 h-5" />
                    主题设置
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">主色调</label>
                      <div className="flex items-center gap-3">
                        <input
                          type="color"
                          value={settings.primaryColor}
                          onChange={(e) => handleInputChange("primaryColor", e.target.value)}
                          className="w-12 h-10 bg-gray-800 border border-gray-700 rounded cursor-pointer"
                        />
                        <Input
                          value={settings.primaryColor}
                          onChange={(e) => handleInputChange("primaryColor", e.target.value)}
                          className="bg-gray-800/50 border-gray-700 text-white"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">辅助色</label>
                      <div className="flex items-center gap-3">
                        <input
                          type="color"
                          value={settings.secondaryColor}
                          onChange={(e) => handleInputChange("secondaryColor", e.target.value)}
                          className="w-12 h-10 bg-gray-800 border border-gray-700 rounded cursor-pointer"
                        />
                        <Input
                          value={settings.secondaryColor}
                          onChange={(e) => handleInputChange("secondaryColor", e.target.value)}
                          className="bg-gray-800/50 border-gray-700 text-white"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-gray-800/30 rounded-lg border border-gray-700">
                    <div>
                      <h4 className="text-white font-medium">深色模式</h4>
                      <p className="text-gray-400 text-sm">使用深色主题界面</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.darkMode}
                      onChange={(e) => handleInputChange("darkMode", e.target.checked)}
                      className="w-4 h-4 text-fuchsia-400 bg-gray-800 border-gray-600 rounded focus:ring-fuchsia-400"
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === "security" && (
              <Card className="bg-gray-900/30 border-gray-800/50">
                <CardHeader>
                  <CardTitle className="text-white font-serif flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    安全设置
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertCircle className="w-5 h-5 text-yellow-400" />
                      <h4 className="text-yellow-400 font-medium">安全提醒</h4>
                    </div>
                    <p className="text-yellow-300 text-sm">
                      安全设置功能正在开发中，将包括用户权限管理、访问控制、数据加密等功能。
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700">
                      <h4 className="text-white font-medium mb-2">访问日志</h4>
                      <p className="text-gray-400 text-sm mb-3">记录系统访问和操作日志</p>
                      <Button
                        variant="outline"
                        className="border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
                      >
                        查看日志
                      </Button>
                    </div>

                    <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700">
                      <h4 className="text-white font-medium mb-2">数据备份</h4>
                      <p className="text-gray-400 text-sm mb-3">定期备份重要数据</p>
                      <Button
                        variant="outline"
                        className="border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
                      >
                        立即备份
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
