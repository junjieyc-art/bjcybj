"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Plus, Search, Edit, Trash2, Eye, Filter, Calendar, User, Tag, CheckSquare, Square } from "lucide-react"
import casesData, { type CaseData } from "@/data/casesData"

export default function CasesAdminPage() {
  const [cases, setCases] = useState<CaseData[]>(casesData)
  const [filteredCases, setFilteredCases] = useState<CaseData[]>(casesData)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("全部")
  const [selectedCases, setSelectedCases] = useState<string[]>([])
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")

  const categories = [
    "全部",
    "时尚品牌",
    "科技创新",
    "餐饮服务",
    "教育培训",
    "金融服务",
    "电商平台",
    "医疗健康",
    "文化娱乐",
    "汽车行业",
    "体育运动",
    "美妆护肤",
    "酒店旅游",
  ]

  useEffect(() => {
    let filtered = cases

    // 搜索过滤
    if (searchTerm) {
      filtered = filtered.filter(
        (caseItem) =>
          caseItem.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          caseItem.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          caseItem.client?.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // 分类过滤
    if (selectedCategory !== "全部") {
      filtered = filtered.filter((caseItem) => caseItem.category === selectedCategory)
    }

    setFilteredCases(filtered)
  }, [cases, searchTerm, selectedCategory])

  const handleSelectCase = (caseId: string) => {
    setSelectedCases((prev) => (prev.includes(caseId) ? prev.filter((id) => id !== caseId) : [...prev, caseId]))
  }

  const handleSelectAll = () => {
    if (selectedCases.length === filteredCases.length) {
      setSelectedCases([])
    } else {
      setSelectedCases(filteredCases.map((c) => c.id))
    }
  }

  const handleBatchDelete = () => {
    if (selectedCases.length === 0) return

    const confirmed = window.confirm(`确定要删除选中的 ${selectedCases.length} 个案例吗？`)
    if (confirmed) {
      setCases((prev) => prev.filter((c) => !selectedCases.includes(c.id)))
      setSelectedCases([])
    }
  }

  const handleDeleteCase = (caseId: string) => {
    const confirmed = window.confirm("确定要删除这个案例吗？")
    if (confirmed) {
      setCases((prev) => prev.filter((c) => c.id !== caseId))
    }
  }

  const handleCreateNew = () => {
    window.location.href = "/admin/cases/new"
  }

  return (
    <div className="min-h-screen bg-gray-950 relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-500/5 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-cyan-500/4 rounded-full blur-3xl"></div>
      </div>

      <nav className="sticky top-0 z-50 bg-gray-950/90 backdrop-blur-xl border-b border-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-6">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
              <div className="flex items-center gap-2 px-3 py-1 bg-orange-500/20 border border-orange-400/30 rounded-full">
                <Edit className="w-4 h-4 text-orange-400" />
                <span className="text-sm text-orange-400 font-medium">管理后台</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Button
                onClick={handleCreateNew}
                className="border-2 border-green-400 text-green-400 hover:bg-green-400 hover:text-white bg-transparent transition-all duration-300"
              >
                <Plus className="w-4 h-4 mr-2" />
                新建案例
              </Button>
              <Button
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
                onClick={() => (window.location.href = "/cases")}
              >
                <Eye className="w-4 h-4 mr-2" />
                预览网站
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">案例管理</h1>
          <div className="flex items-center gap-6 text-sm text-gray-400">
            <span>总计 {cases.length} 个案例</span>
            <span>已筛选 {filteredCases.length} 个</span>
            {selectedCases.length > 0 && <span className="text-fuchsia-400">已选择 {selectedCases.length} 个</span>}
          </div>
        </div>

        <div className="mb-8 space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="搜索案例标题、描述或客户..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-900/50 border-gray-700 text-white placeholder-gray-400 focus:border-fuchsia-400"
              />
            </div>
            <div className="flex gap-2">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 bg-gray-900/50 border border-gray-700 rounded-md text-white focus:border-fuchsia-400 focus:outline-none"
              >
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
              <Button
                variant="outline"
                size="sm"
                className="border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
                onClick={() => setViewMode(viewMode === "grid" ? "list" : "grid")}
              >
                <Filter className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {selectedCases.length > 0 && (
            <div className="flex items-center justify-between p-4 bg-gray-900/50 border border-gray-700 rounded-lg">
              <div className="flex items-center gap-4">
                <Button size="sm" variant="ghost" onClick={handleSelectAll} className="text-gray-300 hover:text-white">
                  {selectedCases.length === filteredCases.length ? (
                    <CheckSquare className="w-4 h-4 mr-2" />
                  ) : (
                    <Square className="w-4 h-4 mr-2" />
                  )}
                  {selectedCases.length === filteredCases.length ? "取消全选" : "全选"}
                </Button>
                <span className="text-sm text-gray-400">已选择 {selectedCases.length} 个案例</span>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white bg-transparent"
                  onClick={handleBatchDelete}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  批量删除
                </Button>
              </div>
            </div>
          )}
        </div>

        {viewMode === "grid" ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCases.map((caseItem) => (
              <Card
                key={caseItem.id}
                className={`bg-gray-900/30 border-gray-800/50 hover:border-fuchsia-400/30 transition-all duration-300 ${
                  selectedCases.includes(caseItem.id) ? "ring-2 ring-fuchsia-400/50 border-fuchsia-400/50" : ""
                }`}
              >
                <div className="relative">
                  <div
                    className="h-48 bg-cover bg-center rounded-t-lg"
                    style={{ backgroundImage: `url(${caseItem.image})` }}
                  />
                  <div className="absolute top-3 left-3">
                    <Badge className={`${caseItem.categoryColor} text-white`}>{caseItem.category}</Badge>
                  </div>
                  <div className="absolute top-3 right-3">
                    <input
                      type="checkbox"
                      checked={selectedCases.includes(caseItem.id)}
                      onChange={() => handleSelectCase(caseItem.id)}
                      className="w-4 h-4 text-fuchsia-400 bg-gray-800 border-gray-600 rounded focus:ring-fuchsia-400"
                    />
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-lg font-bold text-white mb-2 font-serif">{caseItem.title}</h3>
                  <p className="text-gray-400 text-sm mb-4 line-clamp-2">{caseItem.description}</p>
                  <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                    <div className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {caseItem.client}
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {caseItem.year}
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 p-2"
                        onClick={() => (window.location.href = `/cases/${caseItem.id}`)}
                        title="查看详情"
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-green-400 hover:text-green-300 hover:bg-green-400/10 p-2"
                        onClick={() => (window.location.href = `/admin/cases/${caseItem.id}/edit`)}
                        title="编辑"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-red-400 hover:text-red-300 hover:bg-red-400/10 p-2"
                        onClick={() => handleDeleteCase(caseItem.id)}
                        title="删除"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                    <Badge variant="outline" className="border-gray-600 text-gray-400 text-xs">
                      {caseItem.duration}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredCases.map((caseItem) => (
              <Card
                key={caseItem.id}
                className={`bg-gray-900/30 border-gray-800/50 hover:border-fuchsia-400/30 transition-all duration-300 ${
                  selectedCases.includes(caseItem.id) ? "ring-2 ring-fuchsia-400/50 border-fuchsia-400/50" : ""
                }`}
              >
                <CardContent className="p-6">
                  <div className="flex items-center gap-6">
                    <input
                      type="checkbox"
                      checked={selectedCases.includes(caseItem.id)}
                      onChange={() => handleSelectCase(caseItem.id)}
                      className="w-4 h-4 text-fuchsia-400 bg-gray-800 border-gray-600 rounded focus:ring-fuchsia-400"
                    />
                    <div
                      className="w-20 h-20 bg-cover bg-center rounded-lg flex-shrink-0"
                      style={{ backgroundImage: `url(${caseItem.image})` }}
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="text-lg font-bold text-white mb-1 font-serif">{caseItem.title}</h3>
                          <p className="text-gray-400 text-sm mb-2">{caseItem.description}</p>
                          <div className="flex items-center gap-4 text-xs text-gray-500">
                            <div className="flex items-center gap-1">
                              <Tag className="w-3 h-3" />
                              {caseItem.category}
                            </div>
                            <div className="flex items-center gap-1">
                              <User className="w-3 h-3" />
                              {caseItem.client}
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {caseItem.year}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
                            onClick={() => (window.location.href = `/cases/${caseItem.id}`)}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-green-400 hover:text-green-300 hover:bg-green-400/10"
                            onClick={() => (window.location.href = `/admin/cases/${caseItem.id}/edit`)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-red-400 hover:text-red-300 hover:bg-red-400/10"
                            onClick={() => handleDeleteCase(caseItem.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {filteredCases.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p className="text-lg">没有找到匹配的案例</p>
              <p className="text-sm">尝试调整搜索条件或创建新案例</p>
            </div>
            <Button
              onClick={handleCreateNew}
              className="border-2 border-green-400 text-green-400 hover:bg-green-400 hover:text-white bg-transparent transition-all duration-300 mt-4"
            >
              <Plus className="w-4 h-4 mr-2" />
              创建第一个案例
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
