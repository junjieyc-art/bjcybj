"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { RichTextEditor } from "@/components/rich-text-editor"
import { MediaUpload } from "@/components/media-upload"
import { Save, X, ArrowLeft, Plus, Loader2, Check, AlertCircle } from "lucide-react"
import type { CaseData } from "@/data/casesData"

interface MediaFile {
  id: string
  name: string
  size: number
  type: string
  url: string
  preview?: string
  thumbnail?: string
  duration?: number
  dimensions?: { width: number; height: number }
  compressed?: boolean
  metadata?: {
    [key: string]: any
  }
}

type SaveStatus = "idle" | "saving" | "success" | "error"

export default function NewCasePage() {
  const [caseData, setCaseData] = useState<Partial<CaseData>>({
    title: "",
    category: "时尚品牌",
    categoryColor: "bg-blue-500/90",
    description: "",
    fullDescription: "",
    image: "",
    services: [],
    results: [],
    duration: "",
    year: new Date().getFullYear().toString(),
    client: "",
    challenge: "",
    solution: "",
  })

  const [caseFiles, setCaseFiles] = useState<MediaFile[]>([])
  const [saveStatus, setSaveStatus] = useState<SaveStatus>("idle")
  const [saveMessage, setSaveMessage] = useState("")
  const [currentService, setCurrentService] = useState("")
  const [currentResult, setCurrentResult] = useState("")

  const categories = [
    { name: "时尚品牌", color: "bg-blue-500/90" },
    { name: "科技创新", color: "bg-purple-500/90" },
    { name: "餐饮服务", color: "bg-green-500/90" },
    { name: "教育培训", color: "bg-yellow-500/90" },
    { name: "金融服务", color: "bg-indigo-500/90" },
    { name: "电商平台", color: "bg-red-500/90" },
    { name: "医疗健康", color: "bg-teal-500/90" },
    { name: "文化娱乐", color: "bg-pink-500/90" },
    { name: "汽车行业", color: "bg-slate-500/90" },
    { name: "体育运动", color: "bg-orange-500/90" },
    { name: "美妆护肤", color: "bg-rose-500/90" },
    { name: "酒店旅游", color: "bg-emerald-500/90" },
  ]

  const handleInputChange = (field: keyof CaseData, value: string) => {
    setCaseData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleCategoryChange = (categoryName: string) => {
    const category = categories.find((c) => c.name === categoryName)
    if (category) {
      setCaseData((prev) => ({
        ...prev,
        category: category.name,
        categoryColor: category.color,
      }))
    }
  }

  const addService = () => {
    if (currentService.trim() && !caseData.services?.includes(currentService.trim())) {
      setCaseData((prev) => ({
        ...prev,
        services: [...(prev.services || []), currentService.trim()],
      }))
      setCurrentService("")
    }
  }

  const removeService = (service: string) => {
    setCaseData((prev) => ({
      ...prev,
      services: prev.services?.filter((s) => s !== service) || [],
    }))
  }

  const addResult = () => {
    if (currentResult.trim() && !caseData.results?.includes(currentResult.trim())) {
      setCaseData((prev) => ({
        ...prev,
        results: [...(prev.results || []), currentResult.trim()],
      }))
      setCurrentResult("")
    }
  }

  const removeResult = (result: string) => {
    setCaseData((prev) => ({
      ...prev,
      results: prev.results?.filter((r) => r !== result) || [],
    }))
  }

  const handleSave = async () => {
    // 验证必填字段
    if (!caseData.title?.trim()) {
      setSaveStatus("error")
      setSaveMessage("请输入案例标题")
      return
    }

    if (!caseData.description?.trim()) {
      setSaveStatus("error")
      setSaveMessage("请输入案例描述")
      return
    }

    try {
      setSaveStatus("saving")
      setSaveMessage("正在保存...")

      // 生成案例ID
      const caseId = caseData.title
        .toLowerCase()
        .replace(/[^a-z0-9\u4e00-\u9fa5]/g, "-")
        .replace(/-+/g, "-")
        .replace(/^-|-$/g, "")

      const newCase: CaseData = {
        id: caseId,
        title: caseData.title!,
        category: caseData.category!,
        categoryColor: caseData.categoryColor!,
        description: caseData.description!,
        fullDescription: caseData.fullDescription || caseData.description!,
        image: caseData.image || "/placeholder.svg",
        services: caseData.services || [],
        results: caseData.results || [],
        duration: caseData.duration || "待定",
        year: caseData.year!,
        client: caseData.client,
        challenge: caseData.challenge,
        solution: caseData.solution,
      }

      // 模拟API调用
      await new Promise((resolve) => setTimeout(resolve, 1500))

      const response = await fetch(`/api/cases/${caseId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          caseData: newCase,
          files: caseFiles,
        }),
      })

      if (response.ok) {
        setSaveStatus("success")
        setSaveMessage("案例创建成功！")

        // 3秒后跳转到案例详情页
        setTimeout(() => {
          window.location.href = `/cases/${caseId}`
        }, 2000)
      } else {
        throw new Error("保存失败")
      }
    } catch (error) {
      setSaveStatus("error")
      setSaveMessage("保存失败，请重试")
    }

    // 清除状态消息
    setTimeout(() => {
      if (saveStatus !== "success") {
        setSaveStatus("idle")
        setSaveMessage("")
      }
    }, 3000)
  }

  const getSaveStatusIcon = () => {
    switch (saveStatus) {
      case "saving":
        return <Loader2 className="w-4 h-4 animate-spin" />
      case "success":
        return <Check className="w-4 h-4" />
      case "error":
        return <AlertCircle className="w-4 h-4" />
      default:
        return <Save className="w-4 h-4" />
    }
  }

  const getSaveStatusColor = () => {
    switch (saveStatus) {
      case "saving":
        return "border-blue-400 text-blue-400 hover:bg-blue-400"
      case "success":
        return "border-green-400 text-green-400 hover:bg-green-400"
      case "error":
        return "border-red-400 text-red-400 hover:bg-red-400"
      default:
        return "border-green-400 text-green-400 hover:bg-green-400"
    }
  }

  return (
    <div className="min-h-screen bg-gray-950 relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-green-500/5 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-blue-500/4 rounded-full blur-3xl"></div>
      </div>

      <nav className="sticky top-0 z-50 bg-gray-950/90 backdrop-blur-xl border-b border-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-6">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
              <div className="flex items-center gap-2 px-3 py-1 bg-green-500/20 border border-green-400/30 rounded-full">
                <Plus className="w-4 h-4 text-green-400" />
                <span className="text-sm text-green-400 font-medium">新建案例</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {saveMessage && (
                <div className="flex items-center gap-2 text-sm animate-in fade-in-0 duration-300">
                  {getSaveStatusIcon()}
                  <span
                    className={`${saveStatus === "success" ? "text-green-400" : saveStatus === "error" ? "text-red-400" : "text-blue-400"}`}
                  >
                    {saveMessage}
                  </span>
                </div>
              )}
              <Button
                onClick={handleSave}
                disabled={saveStatus === "saving"}
                className={`border-2 ${getSaveStatusColor()} hover:text-white bg-transparent transition-all duration-300 ${saveStatus === "saving" ? "animate-pulse" : ""}`}
              >
                {getSaveStatusIcon()}
                <span className="ml-2">{saveStatus === "saving" ? "保存中..." : "保存案例"}</span>
              </Button>
              <Button
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
                onClick={() => (window.location.href = "/admin/cases")}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                返回列表
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        <div className="space-y-8">
          {/* ... existing basic info card ... */}
          <Card className="bg-gray-900/30 border-gray-800/50">
            <CardHeader>
              <CardTitle className="text-white font-serif">基本信息</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">案例标题 *</label>
                <Input
                  value={caseData.title}
                  onChange={(e) => handleInputChange("title", e.target.value)}
                  placeholder="输入案例标题..."
                  className="bg-gray-800/50 border-gray-700 text-white placeholder-gray-400 focus:border-fuchsia-400"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">案例分类</label>
                  <select
                    value={caseData.category}
                    onChange={(e) => handleCategoryChange(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-800/50 border border-gray-700 rounded-md text-white focus:border-fuchsia-400 focus:outline-none"
                  >
                    {categories.map((category) => (
                      <option key={category.name} value={category.name}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">项目年份</label>
                  <Input
                    value={caseData.year}
                    onChange={(e) => handleInputChange("year", e.target.value)}
                    placeholder="2024"
                    className="bg-gray-800/50 border-gray-700 text-white placeholder-gray-400 focus:border-fuchsia-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">客户名称</label>
                  <Input
                    value={caseData.client}
                    onChange={(e) => handleInputChange("client", e.target.value)}
                    placeholder="客户名称..."
                    className="bg-gray-800/50 border-gray-700 text-white placeholder-gray-400 focus:border-fuchsia-400"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">项目周期</label>
                  <Input
                    value={caseData.duration}
                    onChange={(e) => handleInputChange("duration", e.target.value)}
                    placeholder="6个月"
                    className="bg-gray-800/50 border-gray-700 text-white placeholder-gray-400 focus:border-fuchsia-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">案例简介 *</label>
                <textarea
                  value={caseData.description}
                  onChange={(e) => handleInputChange("description", e.target.value)}
                  placeholder="简要描述这个案例..."
                  rows={3}
                  className="w-full px-3 py-2 bg-gray-800/50 border border-gray-700 rounded-md text-white placeholder-gray-400 focus:border-fuchsia-400 focus:outline-none resize-none"
                />
              </div>
            </CardContent>
          </Card>

          {/* ... existing detailed description card ... */}
          <Card className="bg-gray-900/30 border-gray-800/50">
            <CardHeader>
              <CardTitle className="text-white font-serif">详细描述</CardTitle>
            </CardHeader>
            <CardContent>
              <RichTextEditor
                value={caseData.fullDescription || ""}
                onChange={(value) => handleInputChange("fullDescription", value)}
                placeholder="详细描述项目背景、执行过程、解决方案等..."
              />
            </CardContent>
          </Card>

          {/* ... existing challenge and solution cards ... */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="bg-gray-900/30 border-gray-800/50">
              <CardHeader>
                <CardTitle className="text-white font-serif">项目挑战</CardTitle>
              </CardHeader>
              <CardContent>
                <RichTextEditor
                  value={caseData.challenge || ""}
                  onChange={(value) => handleInputChange("challenge", value)}
                  placeholder="描述项目面临的主要挑战..."
                />
              </CardContent>
            </Card>

            <Card className="bg-gray-900/30 border-gray-800/50">
              <CardHeader>
                <CardTitle className="text-white font-serif">解决方案</CardTitle>
              </CardHeader>
              <CardContent>
                <RichTextEditor
                  value={caseData.solution || ""}
                  onChange={(value) => handleInputChange("solution", value)}
                  placeholder="描述项目的解决方案..."
                />
              </CardContent>
            </Card>
          </div>

          {/* ... existing services and results cards ... */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="bg-gray-900/30 border-gray-800/50">
              <CardHeader>
                <CardTitle className="text-white font-serif">服务内容</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={currentService}
                    onChange={(e) => setCurrentService(e.target.value)}
                    placeholder="添加服务内容..."
                    className="bg-gray-800/50 border-gray-700 text-white placeholder-gray-400 focus:border-fuchsia-400"
                    onKeyPress={(e) => e.key === "Enter" && addService()}
                  />
                  <Button
                    onClick={addService}
                    className="border-2 border-blue-400 text-blue-400 hover:bg-blue-400 hover:text-white bg-transparent"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {caseData.services?.map((service, index) => (
                    <Badge key={index} variant="outline" className="border-gray-600 text-gray-300 pr-1">
                      {service}
                      <Button
                        size="sm"
                        variant="ghost"
                        className="ml-1 h-4 w-4 p-0 text-gray-400 hover:text-red-400"
                        onClick={() => removeService(service)}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-900/30 border-gray-800/50">
              <CardHeader>
                <CardTitle className="text-white font-serif">项目成果</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={currentResult}
                    onChange={(e) => setCurrentResult(e.target.value)}
                    placeholder="添加项目成果..."
                    className="bg-gray-800/50 border-gray-700 text-white placeholder-gray-400 focus:border-fuchsia-400"
                    onKeyPress={(e) => e.key === "Enter" && addResult()}
                  />
                  <Button
                    onClick={addResult}
                    className="border-2 border-green-400 text-green-400 hover:bg-green-400 hover:text-white bg-transparent"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="space-y-2">
                  {caseData.results?.map((result, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-2 bg-gray-800/30 rounded border border-gray-700"
                    >
                      <span className="text-gray-300 text-sm">{result}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-red-400 hover:text-red-300 hover:bg-red-400/10 p-1"
                        onClick={() => removeResult(result)}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gray-900/30 border-gray-800/50">
            <CardHeader>
              <CardTitle className="text-white font-serif">案例媒体文件</CardTitle>
            </CardHeader>
            <CardContent>
              <MediaUpload
                onFilesChange={setCaseFiles}
                existingFiles={caseFiles}
                maxFiles={30}
                maxSize={200}
                enableCompression={true}
                enableCropping={true}
                quality={0.85}
                acceptedTypes={[
                  "image/*",
                  "video/*",
                  "audio/*",
                  ".pdf",
                  ".doc",
                  ".docx",
                  ".ppt",
                  ".pptx",
                  ".zip",
                  ".rar",
                ]}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
