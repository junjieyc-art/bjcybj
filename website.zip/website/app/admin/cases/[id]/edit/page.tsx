"use client"

import { useState, useEffect } from "react"
import { Loader2 } from "lucide-react"
import { notFound } from "next/navigation"
import casesData from "@/data/casesData"

interface EditCasePageProps {
  params: {
    id: string
  }
}

export default function EditCasePage({ params }: EditCasePageProps) {
  const [isLoading, setIsLoading] = useState(true)

  const caseData = casesData.find((c) => c.id === params.id)

  useEffect(() => {
    // 模拟加载延迟
    setTimeout(() => {
      setIsLoading(false)
    }, 1000)
  }, [])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-fuchsia-400 mx-auto mb-4" />
          <p className="text-gray-300">正在加载案例编辑器...</p>
        </div>
      </div>
    )
  }

  if (!caseData) {
    notFound()
  }

  // 重定向到案例详情页的编辑模式
  if (typeof window !== "undefined") {
    window.location.href = `/cases/${params.id}?edit=true`
  }

  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center">
      <div className="text-center">
        <Loader2 className="w-8 h-8 animate-spin text-fuchsia-400 mx-auto mb-4" />
        <p className="text-gray-300">正在跳转到编辑模式...</p>
      </div>
    </div>
  )
}
