"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BarChart3, TrendingUp, TrendingDown, Users, Eye, Calendar, ArrowLeft, Download, RefreshCw } from "lucide-react"
import casesData from "@/data/casesData"

export default function AdminAnalyticsPage() {
  const [timeRange, setTimeRange] = useState("30d")
  const [analytics, setAnalytics] = useState({
    totalViews: 0,
    uniqueVisitors: 0,
    avgSessionDuration: 0,
    bounceRate: 0,
    topCases: [] as { name: string; views: number; category: string }[],
    categoryStats: [] as { name: string; count: number; percentage: number; color: string }[],
    monthlyTrend: [] as { month: string; cases: number; views: number }[],
  })

  useEffect(() => {
    // 模拟分析数据
    const totalViews = Math.floor(Math.random() * 50000) + 10000
    const uniqueVisitors = Math.floor(totalViews * 0.7)
    const avgSessionDuration = Math.floor(Math.random() * 300) + 120
    const bounceRate = Math.floor(Math.random() * 30) + 20

    // 热门案例
    const topCases = casesData
      .slice(0, 5)
      .map((c) => ({
        name: c.title,
        views: Math.floor(Math.random() * 5000) + 1000,
        category: c.category,
      }))
      .sort((a, b) => b.views - a.views)

    // 分类统计
    const categoryCount = casesData.reduce(
      (acc, c) => {
        acc[c.category] = (acc[c.category] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    )

    const categoryStats = Object.entries(categoryCount).map(([name, count]) => {
      const caseItem = casesData.find((c) => c.category === name)
      return {
        name,
        count,
        percentage: Math.round((count / casesData.length) * 100),
        color: caseItem?.categoryColor || "bg-gray-500/90",
      }
    })

    // 月度趋势
    const monthlyTrend = [
      { month: "1月", cases: 8, views: 12000 },
      { month: "2月", cases: 6, views: 9500 },
      { month: "3月", cases: 10, views: 15000 },
      { month: "4月", cases: 12, views: 18000 },
      { month: "5月", cases: 9, views: 14000 },
      { month: "6月", cases: 15, views: 22000 },
    ]

    setAnalytics({
      totalViews,
      uniqueVisitors,
      avgSessionDuration,
      bounceRate,
      topCases,
      categoryStats,
      monthlyTrend,
    })
  }, [timeRange])

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}分${secs}秒`
  }

  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + "K"
    }
    return num.toString()
  }

  return (
    <div className="min-h-screen bg-gray-950 relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-blue-500/4 rounded-full blur-3xl"></div>
      </div>

      <nav className="sticky top-0 z-50 bg-gray-950/90 backdrop-blur-xl border-b border-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-6">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
              <div className="flex items-center gap-2 px-3 py-1 bg-purple-500/20 border border-purple-400/30 rounded-full">
                <BarChart3 className="w-4 h-4 text-purple-400" />
                <span className="text-sm text-purple-400 font-medium">数据分析</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <select
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value)}
                className="px-3 py-2 bg-gray-800/50 border border-gray-700 rounded-md text-white text-sm focus:border-fuchsia-400 focus:outline-none"
              >
                <option value="7d">最近7天</option>
                <option value="30d">最近30天</option>
                <option value="90d">最近90天</option>
                <option value="1y">最近1年</option>
              </select>
              <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent">
                <Download className="w-4 h-4 mr-2" />
                导出报告
              </Button>
              <Button
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
                onClick={() => (window.location.href = "/admin")}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                返回仪表板
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">数据分析</h1>
          <p className="text-gray-400">深入了解网站表现和用户行为</p>
        </div>

        {/* 核心指标 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gray-900/30 border-gray-800/50 hover:border-blue-400/30 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">总浏览量</p>
                  <p className="text-3xl font-bold text-white">{formatNumber(analytics.totalViews)}</p>
                  <div className="flex items-center mt-2 text-green-400 text-sm">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    <span>+15.3%</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <Eye className="w-6 h-6 text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/30 border-gray-800/50 hover:border-green-400/30 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">独立访客</p>
                  <p className="text-3xl font-bold text-white">{formatNumber(analytics.uniqueVisitors)}</p>
                  <div className="flex items-center mt-2 text-green-400 text-sm">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    <span>+8.7%</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/30 border-gray-800/50 hover:border-purple-400/30 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">平均停留时间</p>
                  <p className="text-3xl font-bold text-white">{formatDuration(analytics.avgSessionDuration)}</p>
                  <div className="flex items-center mt-2 text-purple-400 text-sm">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    <span>+12.1%</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-purple-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/30 border-gray-800/50 hover:border-red-400/30 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">跳出率</p>
                  <p className="text-3xl font-bold text-white">{analytics.bounceRate}%</p>
                  <div className="flex items-center mt-2 text-red-400 text-sm">
                    <TrendingDown className="w-4 h-4 mr-1" />
                    <span>-3.2%</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center">
                  <RefreshCw className="w-6 h-6 text-red-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* 热门案例 */}
          <Card className="bg-gray-900/30 border-gray-800/50">
            <CardHeader>
              <CardTitle className="text-white font-serif flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                热门案例
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analytics.topCases.map((caseItem, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                    <div className="flex items-center gap-3">
                      <span className="text-gray-400 text-sm w-6">#{index + 1}</span>
                      <div>
                        <h4 className="text-white font-medium text-sm truncate max-w-48">{caseItem.name}</h4>
                        <p className="text-gray-400 text-xs">{caseItem.category}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-medium">{formatNumber(caseItem.views)}</p>
                      <p className="text-gray-400 text-xs">浏览量</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 分类统计 */}
          <Card className="bg-gray-900/30 border-gray-800/50">
            <CardHeader>
              <CardTitle className="text-white font-serif flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                分类统计
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analytics.categoryStats.slice(0, 6).map((category, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Badge className={`${category.color} text-white text-xs`}>{category.name}</Badge>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-24 bg-gray-700 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-fuchsia-400 to-violet-400 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${category.percentage}%` }}
                        />
                      </div>
                      <span className="text-white font-medium w-8 text-right text-sm">{category.count}</span>
                      <span className="text-gray-400 text-xs w-10 text-right">{category.percentage}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 月度趋势 */}
        <Card className="bg-gray-900/30 border-gray-800/50">
          <CardHeader>
            <CardTitle className="text-white font-serif flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              月度趋势
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {analytics.monthlyTrend.map((month, index) => (
                <div key={index} className="text-center p-4 bg-gray-800/30 rounded-lg border border-gray-700">
                  <p className="text-gray-400 text-sm mb-2">{month.month}</p>
                  <p className="text-2xl font-bold text-white mb-1">{month.cases}</p>
                  <p className="text-xs text-gray-400 mb-2">新增案例</p>
                  <p className="text-sm text-fuchsia-400">{formatNumber(month.views)} 浏览</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
