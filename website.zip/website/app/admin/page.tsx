"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  BarChart3,
  Users,
  FileText,
  TrendingUp,
  Calendar,
  Eye,
  Edit,
  Plus,
  Settings,
  Activity,
  Clock,
  ArrowUpRight,
} from "lucide-react"
import casesData from "@/data/casesData"

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalCases: 0,
    totalClients: 0,
    thisMonthCases: 0,
    avgProjectDuration: 0,
    topCategories: [] as { name: string; count: number; color: string }[],
    recentActivity: [] as { type: string; title: string; time: string; status: string }[],
  })

  useEffect(() => {
    // 计算统计数据
    const totalCases = casesData.length
    const clients = new Set(casesData.map((c) => c.client).filter(Boolean))
    const totalClients = clients.size

    // 计算本月新增案例（模拟数据）
    const thisMonthCases = Math.floor(totalCases * 0.2)

    // 计算平均项目周期
    const durations = casesData.map((c) => Number.parseInt(c.duration.replace(/[^0-9]/g, ""))).filter((d) => !isNaN(d))
    const avgProjectDuration =
      durations.length > 0 ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length) : 0

    // 统计分类
    const categoryCount = casesData.reduce(
      (acc, c) => {
        acc[c.category] = (acc[c.category] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    )

    const topCategories = Object.entries(categoryCount)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5)
      .map(([name, count]) => {
        const caseItem = casesData.find((c) => c.category === name)
        return {
          name,
          count,
          color: caseItem?.categoryColor || "bg-gray-500/90",
        }
      })

    // 模拟最近活动
    const recentActivity = [
      { type: "create", title: "创建新案例：高端时尚品牌设计", time: "2小时前", status: "success" },
      { type: "edit", title: "编辑案例：科技创新企业品牌升级", time: "4小时前", status: "info" },
      { type: "view", title: "查看案例：餐饮品牌策划", time: "6小时前", status: "default" },
      { type: "create", title: "上传媒体文件到教育平台案例", time: "1天前", status: "success" },
      { type: "edit", title: "更新金融科技品牌重塑案例", time: "2天前", status: "info" },
    ]

    setStats({
      totalCases,
      totalClients,
      thisMonthCases,
      avgProjectDuration,
      topCategories,
      recentActivity,
    })
  }, [])

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "create":
        return <Plus className="w-4 h-4" />
      case "edit":
        return <Edit className="w-4 h-4" />
      case "view":
        return <Eye className="w-4 h-4" />
      default:
        return <Activity className="w-4 h-4" />
    }
  }

  const getActivityColor = (status: string) => {
    switch (status) {
      case "success":
        return "text-green-400"
      case "info":
        return "text-blue-400"
      case "warning":
        return "text-yellow-400"
      case "error":
        return "text-red-400"
      default:
        return "text-gray-400"
    }
  }

  return (
    <div className="min-h-screen bg-gray-950 relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-500/5 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-cyan-500/4 rounded-full blur-3xl"></div>
      </div>

      <nav className="sticky top-0 z-50 bg-gray-950/90 backdrop-blur-xl border-b border-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-6">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
              <div className="flex items-center gap-2 px-3 py-1 bg-blue-500/20 border border-blue-400/30 rounded-full">
                <BarChart3 className="w-4 h-4 text-blue-400" />
                <span className="text-sm text-blue-400 font-medium">管理仪表板</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
                onClick={() => (window.location.href = "/admin/cases")}
              >
                <FileText className="w-4 h-4 mr-2" />
                案例管理
              </Button>
              <Button
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
                onClick={() => (window.location.href = "/admin/settings")}
              >
                <Settings className="w-4 h-4 mr-2" />
                系统设置
              </Button>
              <Button
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
                onClick={() => (window.location.href = "/cases")}
              >
                <Eye className="w-4 h-4 mr-2" />
                预览网站
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">管理仪表板</h1>
          <p className="text-gray-400">欢迎回来！这里是您的项目管理中心</p>
        </div>

        {/* 统计卡片 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gray-900/30 border-gray-800/50 hover:border-blue-400/30 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">总案例数</p>
                  <p className="text-3xl font-bold text-white">{stats.totalCases}</p>
                  <div className="flex items-center mt-2 text-green-400 text-sm">
                    <ArrowUpRight className="w-4 h-4 mr-1" />
                    <span>+12% 较上月</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <FileText className="w-6 h-6 text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/30 border-gray-800/50 hover:border-green-400/30 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">合作客户</p>
                  <p className="text-3xl font-bold text-white">{stats.totalClients}</p>
                  <div className="flex items-center mt-2 text-green-400 text-sm">
                    <ArrowUpRight className="w-4 h-4 mr-1" />
                    <span>+8% 较上月</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/30 border-gray-800/50 hover:border-purple-400/30 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">本月新增</p>
                  <p className="text-3xl font-bold text-white">{stats.thisMonthCases}</p>
                  <div className="flex items-center mt-2 text-purple-400 text-sm">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    <span>活跃增长</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-purple-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/30 border-gray-800/50 hover:border-orange-400/30 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">平均周期</p>
                  <p className="text-3xl font-bold text-white">{stats.avgProjectDuration}月</p>
                  <div className="flex items-center mt-2 text-orange-400 text-sm">
                    <Clock className="w-4 h-4 mr-1" />
                    <span>项目周期</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-orange-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* 热门分类 */}
          <Card className="lg:col-span-2 bg-gray-900/30 border-gray-800/50">
            <CardHeader>
              <CardTitle className="text-white font-serif flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                热门案例分类
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {stats.topCategories.map((category, index) => (
                  <div key={category.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2">
                        <span className="text-gray-400 text-sm w-4">#{index + 1}</span>
                        <Badge className={`${category.color} text-white`}>{category.name}</Badge>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-32 bg-gray-700 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-fuchsia-400 to-violet-400 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${(category.count / stats.totalCases) * 100}%` }}
                        />
                      </div>
                      <span className="text-white font-medium w-8 text-right">{category.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 最近活动 */}
          <Card className="bg-gray-900/30 border-gray-800/50">
            <CardHeader>
              <CardTitle className="text-white font-serif flex items-center gap-2">
                <Activity className="w-5 h-5" />
                最近活动
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {stats.recentActivity.map((activity, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-3 p-3 bg-gray-800/30 rounded-lg border border-gray-700/50"
                  >
                    <div className={`${getActivityColor(activity.status)} mt-0.5`}>
                      {getActivityIcon(activity.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm font-medium truncate">{activity.title}</p>
                      <p className="text-gray-400 text-xs mt-1">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 快速操作 */}
        <Card className="mt-8 bg-gray-900/30 border-gray-800/50">
          <CardHeader>
            <CardTitle className="text-white font-serif">快速操作</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button
                className="border-2 border-green-400 text-green-400 hover:bg-green-400 hover:text-white bg-transparent transition-all duration-300 h-20 flex-col gap-2"
                onClick={() => (window.location.href = "/admin/cases/new")}
              >
                <Plus className="w-6 h-6" />
                <span>新建案例</span>
              </Button>

              <Button
                className="border-2 border-blue-400 text-blue-400 hover:bg-blue-400 hover:text-white bg-transparent transition-all duration-300 h-20 flex-col gap-2"
                onClick={() => (window.location.href = "/admin/cases")}
              >
                <FileText className="w-6 h-6" />
                <span>管理案例</span>
              </Button>

              <Button
                className="border-2 border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white bg-transparent transition-all duration-300 h-20 flex-col gap-2"
                onClick={() => (window.location.href = "/admin/analytics")}
              >
                <BarChart3 className="w-6 h-6" />
                <span>数据分析</span>
              </Button>

              <Button
                className="border-2 border-orange-400 text-orange-400 hover:bg-orange-400 hover:text-white bg-transparent transition-all duration-300 h-20 flex-col gap-2"
                onClick={() => (window.location.href = "/admin/settings")}
              >
                <Settings className="w-6 h-6" />
                <span>系统设置</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
