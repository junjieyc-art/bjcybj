import { type NextRequest, NextResponse } from "next/server"

interface CaseData {
  id: string
  title: string
  category: string
  categoryColor: string
  description: string
  fullDescription: string
  image: string
  services: string[]
  results: string[]
  duration: string
  year: string
  client: string
  challenge: string
  solution: string
  process?: Array<{
    step: string
    description: string
  }>
}

interface UploadedFile {
  id: string
  name: string
  size: number
  type: string
  url: string
  preview?: string
}

interface SaveRequest {
  caseData: CaseData
  files: UploadedFile[]
}

// 模拟数据库存储
const casesStorage = new Map<string, CaseData>()
const filesStorage = new Map<string, UploadedFile[]>()

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params
    const body: SaveRequest = await request.json()

    // 验证数据
    if (!body.caseData || !body.caseData.title) {
      return NextResponse.json({ error: "案例标题不能为空" }, { status: 400 })
    }

    if (!body.caseData.fullDescription) {
      return NextResponse.json({ error: "案例描述不能为空" }, { status: 400 })
    }

    // 模拟保存延迟
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // 保存案例数据
    casesStorage.set(id, {
      ...body.caseData,
      id,
    })

    // 保存文件数据
    if (body.files) {
      filesStorage.set(id, body.files)
    }

    console.log(`[API] Saved case ${id}:`, body.caseData)
    console.log(`[API] Saved files for case ${id}:`, body.files?.length || 0, "files")

    return NextResponse.json({
      success: true,
      message: "案例保存成功",
      data: {
        caseData: body.caseData,
        files: body.files || [],
      },
    })
  } catch (error) {
    console.error("[API] Error saving case:", error)
    return NextResponse.json({ error: "保存失败，请重试" }, { status: 500 })
  }
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params

    const caseData = casesStorage.get(id)
    const files = filesStorage.get(id) || []

    if (!caseData) {
      return NextResponse.json({ error: "案例不存在" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      data: {
        caseData,
        files,
      },
    })
  } catch (error) {
    console.error("[API] Error fetching case:", error)
    return NextResponse.json({ error: "获取案例失败" }, { status: 500 })
  }
}
