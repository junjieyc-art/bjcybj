import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const files = formData.getAll("files") as File[]

    if (!files || files.length === 0) {
      return NextResponse.json({ error: "No files provided" }, { status: 400 })
    }

    const uploadResults = []
    const allowedTypes = [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/webp",
      "video/mp4",
      "video/webm",
      "application/pdf",
    ]
    const maxSize = 10 * 1024 * 1024 // 10MB

    for (const file of files) {
      try {
        // Validate each file
        if (!allowedTypes.includes(file.type)) {
          uploadResults.push({
            name: file.name,
            success: false,
            error: "File type not allowed",
          })
          continue
        }

        if (file.size > maxSize) {
          uploadResults.push({
            name: file.name,
            success: false,
            error: "File too large",
          })
          continue
        }

        // Generate unique filename
        const timestamp = Date.now()
        const randomString = Math.random().toString(36).substring(2, 15)
        const extension = file.name.split(".").pop()
        const filename = `${timestamp}-${randomString}.${extension}`
        const mockUrl = `/uploads/${filename}`

        // Extract file metadata
        const metadata = {
          name: file.name,
          size: file.size,
          type: file.type,
          lastModified: file.lastModified,
          url: mockUrl,
          filename: filename,
        }

        uploadResults.push({
          name: file.name,
          success: true,
          url: mockUrl,
          metadata: metadata,
        })
      } catch (error) {
        uploadResults.push({
          name: file.name,
          success: false,
          error: "Upload failed",
        })
      }
    }

    // Simulate batch upload delay
    await new Promise((resolve) => setTimeout(resolve, 2000))

    return NextResponse.json({
      success: true,
      results: uploadResults,
    })
  } catch (error) {
    console.error("Batch upload error:", error)
    return NextResponse.json({ error: "Batch upload failed" }, { status: 500 })
  }
}
