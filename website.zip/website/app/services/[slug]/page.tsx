"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { notFound } from "next/navigation"

// 服务数据
const servicesData = {
  "brand-strategy": {
    title: "品牌策略",
    subtitle: "深度洞察市场，制定精准的品牌定位",
    description:
      "通过深入的市场调研和品牌分析，为企业制定全面的品牌战略规划，确保品牌在竞争激烈的市场中脱颖而出。我们运用专业的品牌诊断工具和方法论，帮助企业发现品牌价值，构建差异化竞争优势。",
    color: "slate",
    icon: "strategy",
    services: ["品牌定位分析", "市场竞争研究", "目标受众画像", "品牌价值主张", "品牌架构规划", "品牌传播策略"],
    process: [
      { step: "市场调研", description: "深入了解行业现状和竞争环境，分析市场机会与挑战" },
      { step: "品牌诊断", description: "全面分析现有品牌资产和问题，识别品牌发展瓶颈" },
      { step: "策略制定", description: "制定差异化的品牌定位策略，构建独特品牌价值" },
      { step: "执行规划", description: "制定详细的品牌实施路径，确保策略有效落地" },
    ],
    benefits: ["提升品牌认知度", "增强市场竞争力", "优化品牌资产配置", "提高品牌价值"],
    features: [
      { title: "专业调研", description: "运用科学的市场调研方法，获取准确的市场洞察" },
      { title: "数据驱动", description: "基于大数据分析，制定精准的品牌策略方案" },
      { title: "全程跟踪", description: "提供品牌策略实施的全程指导和效果监测" },
    ],
    caseStudies: [
      { title: "知名时尚品牌重塑", result: "品牌认知度提升65%", industry: "时尚零售" },
      { title: "科技企业品牌升级", result: "市场份额增长40%", industry: "科技创新" },
    ],
  },
  "visual-design": {
    title: "视觉设计",
    subtitle: "创造独特的视觉识别系统",
    description:
      "打造具有强烈视觉冲击力和品牌识别度的设计作品，从logo设计到完整的视觉识别系统，全方位提升品牌形象。我们的设计团队拥有丰富的国际化设计经验，能够为不同行业的客户提供专业的视觉解决方案。",
    color: "violet",
    icon: "design",
    services: ["Logo设计", "VI视觉识别系统", "包装设计", "宣传物料设计", "网站界面设计", "移动端设计"],
    process: [
      { step: "需求分析", description: "深入了解品牌特性和设计需求，明确设计目标" },
      { step: "创意构思", description: "多方案创意设计和概念提案，探索最佳设计方向" },
      { step: "设计执行", description: "精细化设计制作和优化调整，确保设计质量" },
      { step: "应用拓展", description: "设计系统化应用和标准制定，保证品牌一致性" },
    ],
    benefits: ["建立独特品牌形象", "提升视觉传达效果", "增强品牌记忆度", "统一品牌视觉表现"],
    features: [
      { title: "原创设计", description: "100%原创设计作品，确保品牌独特性和版权安全" },
      { title: "系统化应用", description: "完整的视觉识别系统，涵盖所有品牌接触点" },
      { title: "国际标准", description: "符合国际设计标准，适应全球化品牌发展需求" },
    ],
    caseStudies: [
      { title: "高端餐饮品牌设计", result: "客户满意度98%", industry: "餐饮服务" },
      { title: "科技公司VI系统", result: "品牌识别度提升80%", industry: "科技创新" },
    ],
  },
  "digital-marketing": {
    title: "数字营销",
    subtitle: "多渠道整合营销，精准触达目标用户",
    description:
      "运用数字化营销工具和策略，通过多平台整合营销，实现品牌曝光最大化和精准用户转化。我们拥有专业的数字营销团队和先进的营销技术，能够为客户提供全方位的数字营销解决方案。",
    color: "cyan",
    icon: "marketing",
    services: ["搜索引擎营销", "社交媒体营销", "内容营销策略", "电商平台推广", "数据分析优化", "营销自动化"],
    process: [
      { step: "目标设定", description: "明确营销目标和KPI指标，制定可衡量的营销计划" },
      { step: "渠道选择", description: "选择最适合的数字营销渠道，优化营销资源配置" },
      { step: "内容制作", description: "创作高质量的营销内容，提升用户参与度" },
      { step: "效果优化", description: "持续监测和优化营销效果，提高投资回报率" },
    ],
    benefits: ["提高品牌曝光度", "增加潜在客户", "提升转化率", "降低获客成本"],
    features: [
      { title: "精准投放", description: "基于大数据分析的精准用户定向和投放策略" },
      { title: "全渠道覆盖", description: "整合多个数字营销渠道，实现营销效果最大化" },
      { title: "实时优化", description: "实时监测营销数据，快速调整优化营销策略" },
    ],
    caseStudies: [
      { title: "电商品牌推广", result: "销售额增长150%", industry: "电商零售" },
      { title: "B2B企业获客", result: "线索质量提升200%", industry: "企业服务" },
    ],
  },
  "event-planning": {
    title: "活动策划",
    subtitle: "创意活动策划执行，打造难忘品牌体验",
    description:
      "从概念策划到现场执行，为品牌打造具有影响力的活动体验，增强品牌与用户的情感连接。我们拥有丰富的活动策划经验和专业的执行团队，能够为客户提供一站式的活动解决方案。",
    color: "fuchsia",
    icon: "event",
    services: ["发布会策划", "品牌活动策划", "展会活动设计", "线上活动策划", "公关活动执行", "活动效果评估"],
    process: [
      { step: "活动策划", description: "制定创意活动方案和执行计划，确保活动目标达成" },
      { step: "资源整合", description: "协调各方资源和供应商合作，保证活动顺利进行" },
      { step: "现场执行", description: "专业团队现场活动执行管理，确保活动完美呈现" },
      { step: "效果评估", description: "活动效果数据分析和总结，为后续活动提供参考" },
    ],
    benefits: ["增强品牌影响力", "提升用户参与度", "创造话题热度", "建立品牌口碑"],
    features: [
      { title: "创意策划", description: "独特的活动创意和主题设计，打造令人印象深刻的品牌体验" },
      { title: "专业执行", description: "经验丰富的执行团队，确保活动的专业性和成功率" },
      { title: "全程服务", description: "从策划到执行的一站式服务，让客户省心省力" },
    ],
    caseStudies: [
      { title: "科技产品发布会", result: "媒体曝光量500万+", industry: "科技创新" },
      { title: "时尚品牌活动", result: "用户参与度提升300%", industry: "时尚零售" },
    ],
  },
  "content-marketing": {
    title: "内容营销",
    subtitle: "优质内容创作，建立品牌权威性",
    description:
      "通过高质量的内容创作和传播，建立品牌在行业内的专业形象和权威地位，吸引并留住目标用户。我们的内容团队具备深厚的行业知识和创作能力，能够为客户提供专业的内容营销服务。",
    color: "teal",
    icon: "content",
    services: ["内容策略规划", "原创文章撰写", "视频内容制作", "图文设计制作", "SEO内容优化", "内容分发推广"],
    process: [
      { step: "内容规划", description: "制定内容营销策略和内容日历，确保内容输出的连续性" },
      { step: "内容创作", description: "专业团队创作高质量内容，提升品牌专业形象" },
      { step: "内容发布", description: "多平台内容分发和推广，扩大内容影响力" },
      { step: "效果监测", description: "内容表现数据分析和优化，提高内容营销效果" },
    ],
    benefits: ["建立行业权威性", "提升搜索排名", "增加用户粘性", "降低营销成本"],
    features: [
      { title: "专业创作", description: "资深内容创作团队，具备丰富的行业知识和创作经验" },
      { title: "SEO优化", description: "内容SEO优化，提升搜索引擎排名和自然流量" },
      { title: "多元化内容", description: "涵盖文字、图片、视频等多种内容形式，满足不同用户需求" },
    ],
    caseStudies: [
      { title: "B2B企业内容营销", result: "官网流量增长180%", industry: "企业服务" },
      { title: "教育机构内容推广", result: "用户转化率提升120%", industry: "教育培训" },
    ],
  },
  "social-media": {
    title: "社交媒体",
    subtitle: "全平台社交媒体运营，构建品牌社群",
    description:
      "专业的社交媒体运营服务，通过精准的内容策略和社群运营，建立品牌与用户的深度连接。我们熟悉各大社交媒体平台的运营规则和用户特点，能够为客户制定个性化的社媒运营方案。",
    color: "rose",
    icon: "social",
    services: ["社媒策略制定", "内容创作发布", "社群运营管理", "KOL合作推广", "粉丝互动维护", "数据分析报告"],
    process: [
      { step: "平台分析", description: "分析目标用户在各平台的行为特点和偏好" },
      { step: "内容策略", description: "制定符合平台特性的内容策略和发布计划" },
      { step: "日常运营", description: "持续的内容发布和用户互动，维护品牌形象" },
      { step: "效果优化", description: "基于数据反馈优化运营策略，提升运营效果" },
    ],
    benefits: ["扩大品牌影响力", "建立忠实粉丝群", "提高用户参与度", "增加品牌曝光"],
    features: [
      { title: "多平台运营", description: "覆盖微信、微博、抖音、小红书等主流社交媒体平台" },
      { title: "内容定制", description: "根据不同平台特性定制内容，提升用户参与度" },
      { title: "数据驱动", description: "基于数据分析优化运营策略，提高运营效果" },
    ],
    caseStudies: [
      { title: "美妆品牌社媒运营", result: "粉丝增长500%", industry: "美妆护肤" },
      { title: "餐饮品牌推广", result: "门店客流增长200%", industry: "餐饮服务" },
    ],
  },
  "video-production": {
    title: "影视制作",
    subtitle: "专业影视内容制作，传递品牌故事",
    description:
      "从创意策划到后期制作，提供一站式影视制作服务，用视觉语言讲述品牌故事，传递品牌价值。我们拥有专业的影视制作团队和先进的制作设备，能够为客户提供高质量的影视作品。",
    color: "indigo",
    icon: "video",
    services: ["品牌宣传片", "产品介绍视频", "企业形象片", "广告创意视频", "直播活动拍摄", "后期剪辑制作"],
    process: [
      { step: "创意策划", description: "制定视频创意方案和拍摄脚本，确保内容质量" },
      { step: "前期准备", description: "场地选择、演员选角、设备准备等前期工作" },
      { step: "拍摄制作", description: "专业团队现场拍摄执行，确保拍摄质量" },
      { step: "后期制作", description: "剪辑、调色、特效、配音制作，完善视频效果" },
    ],
    benefits: ["提升品牌形象", "增强传播效果", "提高用户记忆度", "扩大品牌影响力"],
    features: [
      { title: "专业团队", description: "经验丰富的导演、摄影师和后期制作团队" },
      { title: "高端设备", description: "使用专业的拍摄和后期制作设备，确保作品质量" },
      { title: "创意策划", description: "独特的创意策划和故事叙述，打造有影响力的视频内容" },
    ],
    caseStudies: [
      { title: "科技企业宣传片", result: "播放量突破100万", industry: "科技创新" },
      { title: "汽车品牌广告", result: "品牌认知度提升60%", industry: "汽车行业" },
    ],
  },
  "public-relations": {
    title: "公关传播",
    subtitle: "专业公关策略，塑造品牌声誉",
    description:
      "通过专业的公关策略和媒体关系管理，为品牌建立良好的公众形象，有效应对危机和挑战。我们拥有丰富的媒体资源和公关经验，能够为客户提供全方位的公关服务。",
    color: "purple",
    icon: "pr",
    services: ["公关策略制定", "媒体关系维护", "新闻稿撰写发布", "危机公关处理", "行业活动参与", "舆情监测分析"],
    process: [
      { step: "现状分析", description: "分析品牌当前的公众形象状况和潜在风险" },
      { step: "策略制定", description: "制定针对性的公关传播策略和应对方案" },
      { step: "执行推进", description: "实施公关活动和媒体沟通，建立良好关系" },
      { step: "效果评估", description: "监测公关效果和舆论反馈，持续优化策略" },
    ],
    benefits: ["提升品牌声誉", "建立媒体关系", "增强公信力", "有效危机应对"],
    features: [
      { title: "媒体资源", description: "丰富的媒体资源和良好的媒体关系网络" },
      { title: "危机应对", description: "专业的危机公关处理能力，快速有效应对负面事件" },
      { title: "舆情监测", description: "实时舆情监测和分析，及时发现和处理潜在问题" },
    ],
    caseStudies: [
      { title: "上市公司公关", result: "负面舆情降低80%", industry: "金融服务" },
      { title: "消费品牌危机处理", result: "品牌信任度恢复95%", industry: "消费品" },
    ],
  },
}

interface ServiceDetailPageProps {
  params: {
    slug: string
  }
}

export default function ServiceDetailPage({ params }: ServiceDetailPageProps) {
  const service = servicesData[params.slug as keyof typeof servicesData]

  if (!service) {
    notFound()
  }

  const getColorClasses = (color: string) => {
    const colorMap = {
      slate: {
        gradient: "from-slate-900/90 via-slate-700/60 to-slate-500/30",
        badge: "bg-slate-500/20 text-slate-300 border-slate-500/30",
        button: "border-slate-400 text-slate-400 hover:bg-slate-400",
        accent: "text-slate-400",
      },
      violet: {
        gradient: "from-violet-900/90 via-violet-700/60 to-violet-500/30",
        badge: "bg-violet-500/20 text-violet-300 border-violet-500/30",
        button: "border-violet-400 text-violet-400 hover:bg-violet-400",
        accent: "text-violet-400",
      },
      cyan: {
        gradient: "from-cyan-900/90 via-cyan-700/60 to-cyan-500/30",
        badge: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
        button: "border-cyan-400 text-cyan-400 hover:bg-cyan-400",
        accent: "text-cyan-400",
      },
      fuchsia: {
        gradient: "from-fuchsia-900/90 via-fuchsia-700/60 to-fuchsia-500/30",
        badge: "bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-500/30",
        button: "border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400",
        accent: "text-fuchsia-400",
      },
      teal: {
        gradient: "from-teal-900/90 via-teal-700/60 to-teal-500/30",
        badge: "bg-teal-500/20 text-teal-300 border-teal-500/30",
        button: "border-teal-400 text-teal-400 hover:bg-teal-400",
        accent: "text-teal-400",
      },
      rose: {
        gradient: "from-rose-900/90 via-rose-700/60 to-rose-500/30",
        badge: "bg-rose-500/20 text-rose-300 border-rose-500/30",
        button: "border-rose-400 text-rose-400 hover:bg-rose-400",
        accent: "text-rose-400",
      },
      indigo: {
        gradient: "from-indigo-900/90 via-indigo-700/60 to-indigo-500/30",
        badge: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30",
        button: "border-indigo-400 text-indigo-400 hover:bg-indigo-400",
        accent: "text-indigo-400",
      },
      purple: {
        gradient: "from-purple-900/90 via-purple-700/60 to-purple-500/30",
        badge: "bg-purple-500/20 text-purple-300 border-purple-500/30",
        button: "border-purple-400 text-purple-400 hover:bg-purple-400",
        accent: "text-purple-400",
      },
    }
    return colorMap[color as keyof typeof colorMap] || colorMap.violet
  }

  const colorClasses = getColorClasses(service.color)

  return (
    <div className="min-h-screen bg-gray-950 relative">
      {/* 背景装饰效果 */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-500/8 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-cyan-500/6 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-fuchsia-500/4 rounded-full blur-3xl"></div>
      </div>

      {/* 导航栏 */}
      <nav className="sticky top-0 z-50 bg-gray-950/70 backdrop-blur-xl supports-[backdrop-filter]:bg-gray-950/60 border-b border-gray-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="/services" className="text-gray-200 hover:text-white transition-colors">
                核心服务
              </a>
              <a href="/cases" className="text-gray-200 hover:text-white transition-colors">
                精选案例
              </a>
              <a href="/team" className="text-gray-200 hover:text-white transition-colors">
                专业团队
              </a>
              <a href="/about" className="text-gray-200 hover:text-white transition-colors">
                关于我们
              </a>
              <a href="/contact" className="text-gray-200 hover:text-white transition-colors">
                联系我们
              </a>
            </div>
            <Button className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300">
              免费咨询
            </Button>
          </div>
        </div>
      </nav>

      {/* 英雄区域 */}
      <section className="relative bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-[url('/abstract-geometric-pattern.png')] opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <Badge className={`mb-6 ${colorClasses.badge} text-lg px-4 py-2`}>{service.title}</Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 font-serif text-white">{service.subtitle}</h1>
            <p className="text-xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed">{service.description}</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className={`border-2 ${colorClasses.button} hover:text-white bg-transparent transition-all duration-300 px-8 py-4 text-lg`}
              >
                立即咨询
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-gray-500 text-gray-300 hover:bg-gray-500 hover:text-white px-8 py-4 text-lg bg-transparent transition-all duration-300"
                onClick={() => window.history.back()}
              >
                返回服务
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* 服务特色 */}
      <section className="py-20 bg-gray-950/30 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">服务特色</h2>
            <p className="text-lg text-gray-300">专业团队，先进技术，为您提供卓越服务</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {service.features.map((feature, index) => (
              <Card
                key={index}
                className="text-center group hover:shadow-lg transition-all duration-300 bg-gray-900/30 border-gray-800/50 relative overflow-hidden"
              >
                <div
                  className={`absolute inset-0 bg-gradient-to-t ${colorClasses.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}
                ></div>
                <CardContent className="p-8 relative z-10">
                  <div
                    className={`w-16 h-16 rounded-full bg-gradient-to-r ${colorClasses.gradient} mx-auto mb-6 flex items-center justify-center`}
                  >
                    <span className="text-white font-bold text-xl">{index + 1}</span>
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-4">{feature.title}</h3>
                  <p className="text-gray-400 group-hover:text-gray-200 transition-colors duration-300">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* 服务内容 */}
      <section className="py-20 bg-gray-950/50 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* 服务项目 */}
            <div>
              <h2 className="text-3xl font-bold text-white mb-8 font-serif">服务内容</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {service.services.map((item, index) => (
                  <Card
                    key={index}
                    className="bg-gray-900/30 border-gray-800/50 hover:bg-gray-900/50 transition-all duration-300"
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-3">
                        <div
                          className={`w-2 h-2 rounded-full bg-gradient-to-r ${colorClasses.gradient.replace("from-", "from-").replace("via-", "to-").split(" ")[0]} ${colorClasses.gradient.replace("from-", "from-").replace("via-", "to-").split(" ")[2]}`}
                        ></div>
                        <span className="text-gray-200 font-medium">{item}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* 服务优势 */}
            <div>
              <h2 className="text-3xl font-bold text-white mb-8 font-serif">服务优势</h2>
              <div className="space-y-4">
                {service.benefits.map((benefit, index) => (
                  <Card
                    key={index}
                    className="bg-gray-900/30 border-gray-800/50 hover:bg-gray-900/50 transition-all duration-300"
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div
                          className={`w-8 h-8 rounded-full bg-gradient-to-r ${colorClasses.gradient} flex items-center justify-center flex-shrink-0 mt-1`}
                        >
                          <span className="text-white font-bold text-sm">{index + 1}</span>
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-white mb-2">{benefit}</h3>
                          <p className="text-gray-400 text-sm">
                            通过专业的服务流程和丰富的行业经验，为您提供高质量的解决方案。
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 服务流程 */}
      <section className="py-20 bg-gray-950 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">服务流程</h2>
            <p className="text-lg text-gray-300">专业化的服务流程，确保项目高质量交付</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {service.process.map((step, index) => (
              <Card
                key={index}
                className="text-center group hover:shadow-lg transition-all duration-300 bg-gray-900/30 border-gray-800/50 relative overflow-hidden"
              >
                <div
                  className={`absolute inset-0 bg-gradient-to-t ${colorClasses.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}
                ></div>
                <CardContent className="p-8 relative z-10">
                  <div
                    className={`w-16 h-16 rounded-full bg-gradient-to-r ${colorClasses.gradient} mx-auto mb-6 flex items-center justify-center`}
                  >
                    <span className="text-white font-bold text-xl">{index + 1}</span>
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-4">{step.step}</h3>
                  <p className="text-gray-400 group-hover:text-gray-200 transition-colors duration-300">
                    {step.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950/30 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">成功案例</h2>
            <p className="text-lg text-gray-300">真实案例见证我们的专业实力</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {service.caseStudies.map((caseStudy, index) => (
              <Card
                key={index}
                className="group hover:shadow-xl transition-all duration-300 bg-gray-900/30 border-gray-800/50 overflow-hidden relative"
              >
                <div
                  className="absolute inset-0 bg-cover bg-center group-hover:scale-105 transition-transform duration-300"
                  style={{
                    backgroundImage: `url(/placeholder.svg?height=300&width=500&query=${caseStudy.title} case study)`,
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <CardContent className="relative p-8 text-white h-64 flex flex-col justify-end">
                  <Badge className={`mb-4 ${colorClasses.badge} w-fit`}>{caseStudy.industry}</Badge>
                  <h3 className="text-xl font-semibold mb-3">{caseStudy.title}</h3>
                  <p className={`text-lg font-bold ${colorClasses.accent} mb-4`}>{caseStudy.result}</p>
                  <Button
                    variant="ghost"
                    className="text-white hover:text-white/80 hover:bg-white/10 p-0 text-sm w-fit"
                    onClick={() => (window.location.href = "/cases")}
                  >
                    查看详情 →
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button
              variant="outline"
              size="lg"
              className={`border-2 ${colorClasses.button} hover:text-white bg-transparent transition-all duration-300`}
              onClick={() => (window.location.href = "/cases")}
            >
              查看更多案例
            </Button>
          </div>
        </div>
      </section>

      {/* CTA区域 */}
      <section className="py-20 bg-gradient-to-br from-gray-800 via-gray-700 to-gray-800 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-violet-500/20 rounded-full blur-3xl"></div>
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-cyan-500/20 rounded-full blur-3xl"></div>
        </div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 font-serif">准备开始您的{service.title}项目？</h2>
          <p className="text-xl mb-8 opacity-90">让我们的专业团队为您提供定制化的解决方案</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className={`border-2 ${colorClasses.button} hover:text-white bg-transparent transition-all duration-300`}
              onClick={() => (window.location.href = "/contact")}
            >
              立即咨询
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-white text-white hover:bg-white hover:text-gray-800 bg-transparent transition-all duration-300"
              onClick={() => (window.location.href = "/cases")}
            >
              查看案例
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-950 text-gray-300 py-12 border-t border-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <div className="text-2xl font-bold font-serif bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">
                创意传媒
              </div>
            </div>
            <div className="text-gray-500 text-sm">Copyright © 2024 创意传媒, All rights reserved.</div>
          </div>
        </div>
      </footer>
    </div>
  )
}
