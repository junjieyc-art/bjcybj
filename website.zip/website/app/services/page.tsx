import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function ServicesPage() {
  const services = [
    {
      id: "brand-strategy",
      title: "品牌策略",
      subtitle: "Brand Strategy",
      description: "深度洞察市场，制定精准的品牌定位和发展战略",
      icon: "🎯",
      features: ["市场调研分析", "品牌定位策略", "竞争对手分析", "品牌架构规划", "品牌价值主张"],
      process: ["市场洞察", "策略制定", "方案验证", "执行指导"],
      image: "url(/placeholder.svg?height=400&width=600&query=brand strategy planning meeting)",
    },
    {
      id: "visual-design",
      title: "视觉设计",
      subtitle: "Visual Design",
      description: "创造独特的视觉识别系统，提升品牌形象和认知度",
      icon: "🎨",
      features: ["LOGO设计", "VI视觉识别", "包装设计", "宣传物料", "数字界面设计"],
      process: ["创意构思", "设计执行", "方案优化", "标准制定"],
      image: "url(/placeholder.svg?height=400&width=600&query=creative visual design workspace)",
    },
    {
      id: "digital-marketing",
      title: "数字营销",
      subtitle: "Digital Marketing",
      description: "多渠道整合营销，精准触达目标用户群体",
      icon: "📱",
      features: ["社交媒体营销", "搜索引擎优化", "内容营销", "数据分析", "广告投放"],
      process: ["策略规划", "内容制作", "渠道投放", "效果优化"],
      image: "url(/placeholder.svg?height=400&width=600&query=digital marketing analytics dashboard)",
    },
    {
      id: "event-planning",
      title: "活动策划",
      subtitle: "Event Planning",
      description: "创意活动策划执行，打造品牌传播热点",
      icon: "🎪",
      features: ["活动策划", "现场执行", "媒体传播", "效果评估", "危机公关"],
      process: ["需求分析", "方案策划", "活动执行", "后期传播"],
      image: "url(/placeholder.svg?height=400&width=600&query=event planning creative meeting)",
    },
    {
      id: "content-marketing",
      title: "内容营销",
      subtitle: "Content Marketing",
      description: "优质内容创作，建立品牌与用户的深度连接",
      icon: "📝",
      features: ["内容策略", "文案创作", "视频制作", "图文设计", "传播推广"],
      process: ["内容规划", "创作执行", "发布推广", "效果监测"],
      image: "url(/placeholder.svg?height=400&width=600&query=content marketing creation process)",
    },
    {
      id: "social-media",
      title: "社交媒体",
      subtitle: "Social Media",
      description: "全平台社交媒体运营，构建品牌社群生态",
      icon: "💬",
      features: ["平台运营", "社群管理", "KOL合作", "话题营销", "粉丝互动"],
      process: ["平台分析", "内容规划", "日常运营", "数据优化"],
      image: "url(/placeholder.svg?height=400&width=600&query=social media management dashboard)",
    },
    {
      id: "video-production",
      title: "影视制作",
      subtitle: "Video Production",
      description: "专业影视内容制作，传递品牌核心价值",
      icon: "🎬",
      features: ["品牌宣传片", "产品展示", "企业形象片", "短视频制作", "直播策划"],
      process: ["脚本策划", "拍摄制作", "后期剪辑", "发布推广"],
      image: "url(/placeholder.svg?height=400&width=600&query=video production studio equipment)",
    },
    {
      id: "public-relations",
      title: "公关传播",
      subtitle: "Public Relations",
      description: "专业公关策略，塑造良好品牌形象和声誉",
      icon: "📢",
      features: ["媒体关系", "危机公关", "新闻发布", "舆情监测", "声誉管理"],
      process: ["策略制定", "媒体沟通", "内容发布", "效果监测"],
      image: "url(/placeholder.svg?height=400&width=600&query=public relations press conference)",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-950 relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-500/8 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-cyan-500/6 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-fuchsia-500/4 rounded-full blur-3xl"></div>
      </div>

      <nav className="sticky top-0 z-50 bg-gray-950/70 backdrop-blur-xl supports-[backdrop-filter]:bg-gray-950/60 border-b border-gray-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-gray-200 hover:text-white transition-colors">
                首页
              </a>
              <a href="/services" className="text-white font-medium">
                核心服务
              </a>
              <a href="/cases" className="text-gray-200 hover:text-white transition-colors">
                精选案例
              </a>
              <a href="/team" className="text-gray-200 hover:text-white transition-colors">
                专业团队
              </a>
              <a href="/about" className="text-gray-200 hover:text-white transition-colors">
                关于我们
              </a>
              <a href="/contact" className="text-gray-200 hover:text-white transition-colors">
                联系我们
              </a>
            </div>
            <Button className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300">
              免费咨询
            </Button>
          </div>
        </div>
      </nav>

      <section className="relative bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 py-20 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <div className="text-sm text-violet-300 mb-4 tracking-wider uppercase">Professional Services</div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 font-serif">
              <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">
                核心服务
              </span>
            </h1>
            <p className="text-xl text-gray-200 mb-12 max-w-3xl mx-auto leading-relaxed">
              从品牌策略到创意执行，我们提供全链路的专业服务，助力您的品牌在竞争中脱颖而出
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950/50 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {services.map((service, index) => (
              <Card
                key={service.id}
                className="group hover:shadow-xl transition-all duration-300 border-gray-800/50 overflow-hidden bg-gray-900/30"
              >
                <div className="relative h-64 overflow-hidden">
                  <div
                    className="absolute inset-0 bg-cover bg-center group-hover:scale-105 transition-transform duration-300"
                    style={{ backgroundImage: service.image }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900/90 via-gray-900/50 to-transparent" />
                  <div className="absolute top-4 left-4">
                    <div className="text-4xl mb-2">{service.icon}</div>
                    <Badge className="bg-violet-500/20 text-violet-300 border-violet-500/30">{service.subtitle}</Badge>
                  </div>
                </div>

                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold text-white mb-4 font-serif">{service.title}</h3>
                  <p className="text-gray-300 mb-6 leading-relaxed">{service.description}</p>

                  <div className="mb-6">
                    <h4 className="text-lg font-semibold text-white mb-3">服务内容</h4>
                    <div className="flex flex-wrap gap-2">
                      {service.features.map((feature, idx) => (
                        <Badge key={idx} variant="outline" className="border-gray-600 text-gray-300">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="mb-6">
                    <h4 className="text-lg font-semibold text-white mb-3">服务流程</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {service.process.map((step, idx) => (
                        <div key={idx} className="flex items-center text-gray-300 text-sm">
                          <div className="w-6 h-6 bg-fuchsia-500/20 rounded-full flex items-center justify-center mr-2 text-fuchsia-400 text-xs font-bold">
                            {idx + 1}
                          </div>
                          {step}
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950 relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 font-serif">准备开始您的品牌升级之旅？</h2>
          <p className="text-xl text-gray-300 mb-8">让我们的专业团队为您量身定制最适合的服务方案</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/contact"
              className="inline-flex items-center justify-center px-8 py-4 text-lg border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300 rounded-md font-medium"
            >
              免费咨询
            </a>
            <a
              href="/cases"
              className="inline-flex items-center justify-center px-8 py-4 text-lg border-2 border-violet-400 text-violet-400 hover:bg-violet-400 hover:text-white bg-transparent transition-all duration-300 rounded-md font-medium"
            >
              查看案例
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
