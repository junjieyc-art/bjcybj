import { Button } from "@/components/ui/button"

export default function BrandRebrandingPage() {
  return (
    <div className="min-h-screen bg-gray-950 relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-500/8 rounded-full blur-3xl"></div>
        <div className="absolute top-3/4 right-1/4 w-80 h-80 bg-cyan-500/6 rounded-full blur-3xl"></div>
      </div>

      <nav className="sticky top-0 z-50 bg-gray-950/70 backdrop-blur-xl supports-[backdrop-filter]:bg-gray-950/60 border-b border-gray-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent font-serif"
              >
                创意传媒
              </a>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-gray-200 hover:text-white transition-colors">
                首页
              </a>
              <a href="/services" className="text-gray-200 hover:text-white transition-colors">
                核心服务
              </a>
              <a href="/cases" className="text-gray-200 hover:text-white transition-colors">
                精选案例
              </a>
              <a href="/team" className="text-gray-200 hover:text-white transition-colors">
                专业团队
              </a>
              <a href="/about" className="text-gray-200 hover:text-white transition-colors">
                关于我们
              </a>
              <a href="/contact" className="text-gray-200 hover:text-white transition-colors">
                联系我们
              </a>
            </div>
            <Button className="border-2 border-fuchsia-400 text-fuchsia-400 hover:bg-fuchsia-400 hover:text-white bg-transparent transition-all duration-300">
              免费咨询
            </Button>
          </div>
        </div>
      </nav>

      <section className="relative bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 py-20 overflow-hidden">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <div className="text-sm text-violet-300 mb-4 tracking-wider uppercase">Brand Rebranding</div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 font-serif">
              <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">
                品牌重塑
              </span>
            </h1>
            <p className="text-xl text-gray-200 mb-12 max-w-3xl mx-auto leading-relaxed">
              全面重新定义品牌形象，焕发品牌新活力，在市场中重新建立竞争优势
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-950/50 relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-3xl font-bold text-white mb-6 font-serif">为什么需要品牌重塑？</h2>
              <div className="space-y-4 text-gray-300">
                <p>• 市场环境变化，原有品牌形象不再适应</p>
                <p>• 目标受众群体发生转变</p>
                <p>• 业务范围扩展，需要更广泛的品牌定位</p>
                <p>• 竞争加剧，需要差异化的品牌形象</p>
                <p>• 品牌老化，需要注入新的活力</p>
              </div>
            </div>
            <div
              className="h-80 bg-cover bg-center rounded-lg"
              style={{ backgroundImage: "url(/brand-rebranding-transformation.png)" }}
            />
          </div>
        </div>
      </section>
    </div>
  )
}
