"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function SolutionsPage() {
  return (
    <div className="min-h-screen bg-gray-950">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 py-32 lg:py-48 min-h-[60vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-[url('/abstract-geometric-pattern.png')] opacity-5"></div>
        <div className="absolute top-1/3 left-1/2 w-96 h-96 bg-fuchsia-600/12 rounded-full blur-3xl transform -translate-x-1/2"></div>
        <div className="absolute bottom-1/3 right-1/3 w-80 h-80 bg-violet-600/10 rounded-full blur-3xl"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <div className="text-sm text-fuchsia-300 mb-4 tracking-wider uppercase">Solutions</div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6 font-serif">
              <span className="bg-gradient-to-r from-fuchsia-400 via-violet-400 to-cyan-400 bg-clip-text text-transparent">
                解决方案
              </span>
            </h1>
            <p className="text-xl text-gray-200 mb-12 max-w-3xl mx-auto leading-relaxed">
              针对不同行业和企业需求，提供定制化的品牌解决方案，助力企业实现数字化转型和品牌升级
            </p>
          </div>
        </div>
      </section>

      {/* Solutions Grid */}
      <section className="py-20 bg-gray-950/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* 品牌重塑 */}
            <Card className="group hover:shadow-xl transition-all duration-300 border-gray-800/50 bg-gray-900/30 overflow-hidden">
              <div className="h-64 bg-gradient-to-br from-violet-600/20 to-fuchsia-600/20 relative">
                <div className="absolute inset-0 bg-[url('/brand-rebranding-transformation.png')] bg-cover bg-center opacity-30"></div>
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent"></div>
                <div className="absolute bottom-4 left-6">
                  <Badge className="bg-violet-500/90 text-white">品牌重塑</Badge>
                </div>
              </div>
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-white mb-4">品牌重塑解决方案</h3>
                <p className="text-gray-400 mb-6 leading-relaxed">
                  为成熟企业提供全面的品牌重塑服务，重新定义品牌价值，提升市场竞争力，适应新时代的市场需求。
                </p>
                <ul className="space-y-3 text-gray-300 mb-6">
                  <li className="flex items-start">
                    <span className="text-violet-400 mr-2">•</span>
                    品牌诊断与分析
                  </li>
                  <li className="flex items-start">
                    <span className="text-violet-400 mr-2">•</span>
                    品牌战略重新规划
                  </li>
                  <li className="flex items-start">
                    <span className="text-violet-400 mr-2">•</span>
                    视觉形象全面升级
                  </li>
                  <li className="flex items-start">
                    <span className="text-violet-400 mr-2">•</span>
                    品牌传播策略制定
                  </li>
                </ul>
                <Button className="w-full bg-violet-600 hover:bg-violet-700 text-white">了解详情</Button>
              </CardContent>
            </Card>

            {/* 数字化转型 */}
            <Card className="group hover:shadow-xl transition-all duration-300 border-gray-800/50 bg-gray-900/30 overflow-hidden">
              <div className="h-64 bg-gradient-to-br from-cyan-600/20 to-blue-600/20 relative">
                <div className="absolute inset-0 bg-[url('/digital-transformation.png')] bg-cover bg-center opacity-30"></div>
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent"></div>
                <div className="absolute bottom-4 left-6">
                  <Badge className="bg-cyan-500/90 text-white">数字化转型</Badge>
                </div>
              </div>
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-white mb-4">数字化转型方案</h3>
                <p className="text-gray-400 mb-6 leading-relaxed">
                  帮助传统企业实现数字化转型，建立完整的数字化品牌体系，提升线上线下一体化的品牌体验。
                </p>
                <ul className="space-y-3 text-gray-300 mb-6">
                  <li className="flex items-start">
                    <span className="text-cyan-400 mr-2">•</span>
                    数字化品牌策略
                  </li>
                  <li className="flex items-start">
                    <span className="text-cyan-400 mr-2">•</span>
                    线上平台建设
                  </li>
                  <li className="flex items-start">
                    <span className="text-cyan-400 mr-2">•</span>
                    数字营销体系
                  </li>
                  <li className="flex items-start">
                    <span className="text-cyan-400 mr-2">•</span>
                    数据分析与优化
                  </li>
                </ul>
                <Button className="w-full bg-cyan-600 hover:bg-cyan-700 text-white">了解详情</Button>
              </CardContent>
            </Card>

            {/* 营销自动化 */}
            <Card className="group hover:shadow-xl transition-all duration-300 border-gray-800/50 bg-gray-900/30 overflow-hidden">
              <div className="h-64 bg-gradient-to-br from-fuchsia-600/20 to-pink-600/20 relative">
                <div className="absolute inset-0 bg-[url('/marketing-automation-dashboard.png')] bg-cover bg-center opacity-30"></div>
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent"></div>
                <div className="absolute bottom-4 left-6">
                  <Badge className="bg-fuchsia-500/90 text-white">营销自动化</Badge>
                </div>
              </div>
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-white mb-4">营销自动化系统</h3>
                <p className="text-gray-400 mb-6 leading-relaxed">
                  构建智能化营销系统，通过自动化工具提升营销效率，实现精准营销和客户关系管理。
                </p>
                <ul className="space-y-3 text-gray-300 mb-6">
                  <li className="flex items-start">
                    <span className="text-fuchsia-400 mr-2">•</span>
                    客户旅程设计
                  </li>
                  <li className="flex items-start">
                    <span className="text-fuchsia-400 mr-2">•</span>
                    自动化营销流程
                  </li>
                  <li className="flex items-start">
                    <span className="text-fuchsia-400 mr-2">•</span>
                    个性化内容推送
                  </li>
                  <li className="flex items-start">
                    <span className="text-fuchsia-400 mr-2">•</span>
                    效果监测与优化
                  </li>
                </ul>
                <Button className="w-full bg-fuchsia-600 hover:bg-fuchsia-700 text-white">了解详情</Button>
              </CardContent>
            </Card>

            {/* 用户体验优化 */}
            <Card className="group hover:shadow-xl transition-all duration-300 border-gray-800/50 bg-gray-900/30 overflow-hidden">
              <div className="h-64 bg-gradient-to-br from-orange-600/20 to-red-600/20 relative">
                <div className="absolute inset-0 bg-[url('/user-experience-design-interface.png')] bg-cover bg-center opacity-30"></div>
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent"></div>
                <div className="absolute bottom-4 left-6">
                  <Badge className="bg-orange-500/90 text-white">用户体验</Badge>
                </div>
              </div>
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-white mb-4">用户体验优化</h3>
                <p className="text-gray-400 mb-6 leading-relaxed">
                  以用户为中心的设计理念，优化用户接触点体验，提升用户满意度和品牌忠诚度。
                </p>
                <ul className="space-y-3 text-gray-300 mb-6">
                  <li className="flex items-start">
                    <span className="text-orange-400 mr-2">•</span>
                    用户研究与分析
                  </li>
                  <li className="flex items-start">
                    <span className="text-orange-400 mr-2">•</span>
                    交互设计优化
                  </li>
                  <li className="flex items-start">
                    <span className="text-orange-400 mr-2">•</span>
                    界面视觉升级
                  </li>
                  <li className="flex items-start">
                    <span className="text-orange-400 mr-2">•</span>
                    可用性测试
                  </li>
                </ul>
                <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white">了解详情</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Industry Solutions */}
      <section className="py-20 bg-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 font-serif">行业解决方案</h2>
            <p className="text-lg text-gray-300">针对不同行业特点，提供专业化的品牌解决方案</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center hover:shadow-lg transition-all duration-300 bg-gray-900/30 border-gray-800/50">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M4 4a2 2 0 00-2 2v4a2 2 0 002 2V6h10a2 2 0 00-2-2H4zm2 6a2 2 0 012-2h8a2 2 0 012 2v4a2 2 0 01-2 2H8a2 2 0 01-2-2v-4zm6 4a2 2 0 100-4 2 2 0 000 4z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">金融科技</h3>
                <p className="text-gray-400 text-sm">专业可信的品牌形象</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-all duration-300 bg-gray-900/30 border-gray-800/50">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M3 3a1 1 0 000 2v8a2 2 0 002 2h2.586l-1.293 1.293a1 1 0 101.414 1.414L10 15.414l2.293 2.293a1 1 0 001.414-1.414L12.414 15H15a2 2 0 002-2V5a1 1 0 100-2H3zm11.707 4.707a1 1 0 00-1.414-1.414L10 9.586 8.707 8.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">医疗健康</h3>
                <p className="text-gray-400 text-sm">关怀专业的医疗品牌</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-all duration-300 bg-gray-900/30 border-gray-800/50">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">教育培训</h3>
                <p className="text-gray-400 text-sm">启发成长的教育品牌</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-all duration-300 bg-gray-900/30 border-gray-800/50">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M6 6V5a3 3 0 013-3h2a3 3 0 013 3v1h2a2 2 0 012 2v3.57A22.952 22.952 0 0110 13a22.95 22.95 0 01-8-1.43V8a2 2 0 012-2h2zm2-1a1 1 0 011-1h2a1 1 0 011 1v1H8V5zm1 5a1 1 0 011-1h.01a1 1 0 110 2H10a1 1 0 01-1-1z"
                      clipRule="evenodd"
                    />
                    <path d="M2 13.692V16a2 2 0 002 2h12a2 2 0 002-2v-2.308A24.974 24.974 0 0110 15c-2.796 0-5.487-.46-8-1.308z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">电商零售</h3>
                <p className="text-gray-400 text-sm">吸引转化的零售品牌</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-950/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">找到适合您的解决方案</h2>
          <p className="text-xl text-gray-300 mb-8">每个企业都有独特的需求，让我们为您量身定制最适合的品牌解决方案</p>
          <Button
            size="lg"
            className="bg-gradient-to-r from-fuchsia-600 to-violet-600 hover:from-fuchsia-700 hover:to-violet-700 text-white px-8 py-4"
            onClick={() => (window.location.href = "/contact")}
          >
            获取定制方案
          </Button>
        </div>
      </section>
    </div>
  )
}
