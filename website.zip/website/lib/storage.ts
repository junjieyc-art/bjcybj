// File storage utility functions

export interface UploadResult {
  success: boolean
  url?: string
  metadata?: FileMetadata
  error?: string
}

export interface FileMetadata {
  name: string
  size: number
  type: string
  lastModified: number
  url: string
  filename: string
}

export class StorageService {
  private static instance: StorageService
  private baseUrl = "/api/upload"

  static getInstance(): StorageService {
    if (!StorageService.instance) {
      StorageService.instance = new StorageService()
    }
    return StorageService.instance
  }

  async uploadFile(file: File): Promise<UploadResult> {
    try {
      const formData = new FormData()
      formData.append("file", file)

      const response = await fetch(this.baseUrl, {
        method: "POST",
        body: formData,
      })

      const result = await response.json()

      if (!response.ok) {
        return {
          success: false,
          error: result.error || "Upload failed",
        }
      }

      return {
        success: true,
        url: result.url,
        metadata: result.metadata,
      }
    } catch (error) {
      return {
        success: false,
        error: "Network error",
      }
    }
  }

  async uploadFiles(files: File[]): Promise<UploadResult[]> {
    try {
      const formData = new FormData()
      files.forEach((file) => {
        formData.append("files", file)
      })

      const response = await fetch(`${this.baseUrl}/batch`, {
        method: "POST",
        body: formData,
      })

      const result = await response.json()

      if (!response.ok) {
        return files.map((file) => ({
          success: false,
          error: result.error || "Upload failed",
        }))
      }

      return result.results
    } catch (error) {
      return files.map((file) => ({
        success: false,
        error: "Network error",
      }))
    }
  }

  async deleteFile(filename: string): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}?filename=${encodeURIComponent(filename)}`, {
        method: "DELETE",
      })

      const result = await response.json()
      return result.success
    } catch (error) {
      console.error("Delete error:", error)
      return false
    }
  }

  // Utility functions for file validation
  static isValidFileType(file: File): boolean {
    const allowedTypes = [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/webp",
      "video/mp4",
      "video/webm",
      "video/quicktime",
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ]
    return allowedTypes.includes(file.type)
  }

  static isValidFileSize(file: File, maxSizeMB = 10): boolean {
    const maxSizeBytes = maxSizeMB * 1024 * 1024
    return file.size <= maxSizeBytes
  }

  static formatFileSize(bytes: number): string {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  static getFileIcon(fileType: string): string {
    if (fileType.startsWith("image/")) return "🖼️"
    if (fileType.startsWith("video/")) return "🎥"
    if (fileType.includes("pdf")) return "📄"
    if (fileType.includes("word")) return "📝"
    return "📁"
  }
}

export const storage = StorageService.getInstance()
